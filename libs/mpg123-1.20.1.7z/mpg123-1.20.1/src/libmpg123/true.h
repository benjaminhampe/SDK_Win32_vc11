/*
	true: a trivial truth

	copyright ?-2007 by the mpg123 project - free software under the terms of the LGPL 2.1
	see COPYING and AUTHORS files in distribution or http:#mpg123.org
*/

#ifndef MPG123_H_TRUE
#define MPG123_H_TRUE

#define FALSE 0
#define TRUE  1

#endif
