=================================================
The VSTGUI Toolkit source code ist available @

	http://sourceforge.net/projects/vstgui/

or in VST SDK 2.3 @

	http://ygrabit.steinberg.de

Note: For the Mac you need the CVS Version
	  from Sourceforge!!
=================================================
- You need to adjust the references to vstgui.cpp
and vstcontrols.cpp in the project according to
your local folder organization!

- Additional include directories are likely to be
required in project settings, too.

- To compile VSTGUI for Plug-Ins based on
Steinberg Module Architecture, the PLUGGUI macro
must be set.
=================================================
