/*************************************************************************
** Mac Prefix for MachO 
**************************************************************************/

#define __CF_USE_FRAMEWORK_INCLUDES__ 1

#if __MWERKS__
#define __DEBUGGING__
#define __NOEXTENSIONS__
#endif