// [!output PROJECT_NAME].idl : IDL source for [!output PROJECT_NAME].exe
//

// Add interface and coclass declarations in this file
