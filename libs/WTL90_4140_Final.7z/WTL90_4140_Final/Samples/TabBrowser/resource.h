//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TabBrowser.RC
//

#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDS_OPEN_ERROR                  129
#define IDD_OPEN                        201
#define IDD_WINDOWS                     202
#define IDR_TABTOOLBAR                  203
#define IDB_PAGEIMAGE                   204
#define IDR_MAINFRAME_BIG               205
#define IDR_GO                          207
#define IDR_TOOLBAR_MENU                210
#define IDC_EDIT_URL                    1000
#define IDC_LIST1                       1001
#define IDC_ACTIVATE                    1002
#define IDC_CLOSEWINDOWS                1003
#define IDC_NEW_TAB                     1004
#define ID_LINKS_FIRST                  31000
#define ID_LINKS_MICROSOFT              31000
#define ID_LINKS_MSDN                   31001
#define ID_LINKS_LIVE                   31002
#define ID_LINKS_UPDATE                 31003
#define ID_LINKS_WTL                    31004
#define ID_LINKS_LAST                   31099
#define ID_LINKS_URL_FIRST              31100
#define ID_LINKS_URL_MICROSOFT          31100
#define ID_LINKS_URL_MSDN               31101
#define ID_LINKS_URL_LIVE               31102
#define ID_LINKS_URL_UPDATE             31103
#define ID_LINKS_URL_WTL                31104
#define ID_LINKS_URL_LAST               31199
#define ID_WINDOW_CLOSE                 32773
#define ID_WINDOW_CLOSE_ALL             32776
#define ID_BROWSER_BACK                 32777
#define ID_BROWSER_FORWARD              32778
#define ID_BROWSER_REFRESH              32779
#define ID_BROWSER_STOP                 32782
#define ID_WINDOW_SHOW_VIEWS            32783
#define ID_BROWSER_HOME                 32791
#define ID_BROWSER_SEARCH               32795
#define ID_VIEW_ADDRESS_BAR             32796
#define ID_GO                           32797
#define IDS_LOADING                     32798
#define IDS_ADDRESS                     32799
#define IDS_LINKS                       32800
#define IDS_BLANK_URL                   32801
#define IDS_BLANK_TITLE                 32802
#define ID_VIEW_LOCK_TOOLBARS           32807
#define ID_VIEW_LINKS_BAR               32808

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        211
#define _APS_NEXT_COMMAND_VALUE         32810
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
