/** @file paex_mono_asio_channel_select.c
	@ingroup examples_src
	@brief Play a monophonic sine wave on a specific ASIO channel.
	@author Ross Bencina <rossb@audiomulch.com>
	@author Phil Burk <philburk@softsynth.com>
*/

#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <irrlicht.h>

#include "portaudio.h"
#include "pa_asio.h"

#define NUM_SECONDS   (5)
#define SAMPLE_RATE   (44100)
#define AMPLITUDE     (0.8)
#define FRAMES_PER_BUFFER  (2*64)
#define OUTPUT_DEVICE Pa_GetDefaultOutputDevice()

#ifndef M_PI
#define M_PI  (3.14159265)
#endif

typedef struct
{
    float sine[SAMPLE_RATE];
    int phase;
}
paTestData;


void Check( PaError err, const char* msg )
{
	if ( err == paNoError )
	{
		fprintf( stdout, "%s -> OK\n", msg );
	}
	else
	{
		Pa_Terminate();
		fprintf( stderr, "%s -> ERROR\n", msg );
		fprintf( stderr, "Error number: %d\n", err );
		fprintf( stderr, "Error message: %s\n", Pa_GetErrorText( err ) );

		system("PAUSE");
		exit(err);
	}
}

void Error( const char* msg, PaError err)
{
}

/* This routine will be called by the PortAudio engine when audio is needed.
** It may called at interrupt level on some machines so don't do anything
** that could mess up the system like calling malloc() or free().
*/
static int patestCallback( const void *inputBuffer, void *outputBuffer,
                            unsigned long framesPerBuffer,
                            const PaStreamCallbackTimeInfo* timeInfo,
                            PaStreamCallbackFlags statusFlags,
                            void *userData )
{
    paTestData *data = (paTestData*)userData;
    float *out = (float*)outputBuffer;
    unsigned long i;
    int finished = 0;
    /* avoid unused variable warnings */
    (void) inputBuffer;
    (void) timeInfo;
    (void) statusFlags;
    for( i=0; i<framesPerBuffer; i++ )
    {
        *out++ = data->sine[data->phase];  /* left */
        data->phase += 1;
        if( data->phase >= SAMPLE_RATE ) 
			data->phase -= SAMPLE_RATE;
    }
    return finished;
}

/*******************************************************************/
int main(void);
int main(void)
{
    PaStreamParameters outputParameters;
    PaStreamInfo outStreamInfo;
	//PaAsioStreamInfo asioOutputInfo;
    PaStream *stream;
    PaError err;
    paTestData data;
    int outputChannelSelectors[1];
    int i;

    printf("PortAudio Test: output MONO sine wave. SR = %d, BufSize = %d\n", SAMPLE_RATE, FRAMES_PER_BUFFER);
    
	// initialise sinusoidal wavetable
	// Kammerton
	
	const double BASE_FREQ = 55.0;
	
	double v;
	double n = 1.0/8.0;

    for( i=0; i<SAMPLE_RATE; i++ )
    {
		v = sin( ((double)i/(double)SAMPLE_RATE) * BASE_FREQ * M_PI * 2. );
		v += sin( ((double)i/(double)SAMPLE_RATE) * BASE_FREQ * M_PI * 4. );
		v += sin( ((double)i/(double)SAMPLE_RATE) * BASE_FREQ * M_PI * 8. );
		v += sin( ((double)i/(double)SAMPLE_RATE) * BASE_FREQ * M_PI * 16. );
		v += sin( ((double)i/(double)SAMPLE_RATE) * BASE_FREQ * M_PI * 32. );
		v += sin( ((double)i/(double)SAMPLE_RATE) * BASE_FREQ * M_PI * 64. );
		v += sin( ((double)i/(double)SAMPLE_RATE) * BASE_FREQ * M_PI * 128. );
		v += sin( ((double)i/(double)SAMPLE_RATE) * BASE_FREQ * M_PI * 256. );
        v *= AMPLITUDE*n;

		v = irr::core::clamp( v, -1.0,1.0);

		data.sine[i] += (float)v;
    }

    data.phase = 0;
    
    err = Pa_Initialize();
    Check( err, "Pa_Initialize" );

    outputParameters.device = OUTPUT_DEVICE;
    outputParameters.channelCount = 1;       /* MONO output */
    outputParameters.sampleFormat = paFloat32; /* 32 bit floating point output */
    outputParameters.suggestedLatency = Pa_GetDeviceInfo( outputParameters.device )->defaultLowOutputLatency;
	outputParameters.hostApiSpecificStreamInfo = NULL;

	/* Use an ASIO specific structure. WARNING - this is not portable. */
	//outStreamInfo.size = sizeof(PaStreamInfo);
    //asioOutputInfo.size = sizeof(PaAsioStreamInfo);
	//asioOutputInfo.hostApiType = paWASAPI;
    //asioOutputInfo.version = 1;
    //asioOutputInfo.flags = paAsioUseChannelSelectors;
    outputChannelSelectors[0] = 1; // skip channel 0 and use the second (right) ASIO device channel
    //asioOutputInfo.channelSelectors = outputChannelSelectors;
    //outputParameters.hostApiSpecificStreamInfo = &asioOutputInfo;

    err = Pa_OpenStream(
              &stream,
              NULL, /* no input */
              &outputParameters,
              SAMPLE_RATE,
              FRAMES_PER_BUFFER,
              paClipOff,      /* we won't output out of range samples so don't bother clipping them */
              patestCallback,
              &data );
	Check( err, "Pa_OpenStream" );

    err = Pa_StartStream( stream );
    Check( err, "Pa_StartStream" );
    
    printf("Play for %d seconds.\n", NUM_SECONDS ); 
	fflush(stdout);
    Pa_Sleep( NUM_SECONDS * 1000 );

    err = Pa_StopStream( stream );
    Check( err, "Pa_StopStream" );
    
    err = Pa_CloseStream( stream );
    Check( err, "Pa_CloseStream" );
    
    Pa_Terminate();
    printf("Test finished.\n");

	system("PAUSE");
	return 0;
}
