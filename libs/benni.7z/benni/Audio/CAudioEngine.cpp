#include "CAudioEngine.h"


namespace bpm
{

/// =========================================================================================
/// @class SAudioAPI
/// =========================================================================================

	// Value Constructor
	SAudioAPI :: SAudioAPI(	const irr::core::stringc& name, s32 apiIndex, u32 devCount )
		: mName(name), mIndex(apiIndex), mDeviceCount(devCount)
	{
	}

	// Destructor
	SAudioAPI :: ~SAudioAPI()
	{
	}

	//[GETTER] Get a self description
	irr::core::stringc SAudioAPI::toString() const
	{
		irr::core::stringc txt("SAudioAPI{ ");
		txt += mName;
		txt += ", ";
		txt += mIndex;
		txt += ", ";
		txt += mDeviceCount;
		txt += "}";
		return txt;
	}

/// =========================================================================================
/// @class SAudioDevice
/// =========================================================================================

	// Default Constructor
	SAudioDevice :: SAudioDevice()
		: mName(""), mSampleRate(0), mType(EADT_COUNT)						// name, sample-rate and type
		, mOutChannelCount(0), mMinOutLatencyMs(0.0), mMaxOutLatencyMs(0.0)	// input channels
		, mInChannelCount(0), mMinInLatencyMs(0.0), mMaxInLatencyMs(0.0)	// output channels
	{
	}

	// Value Constructor
	SAudioDevice :: SAudioDevice(	
			const irr::core::stringc& name, u32 sampleRate, E_AUDIO_DEVICE_TYPE type,
			u32 outChannelCount, double minOutLatencyMs, double maxOutLatencyMs,
			u32 inChannelCount, double minInLatencyMs, double maxInLatencyMs)
		: mName(name), mSampleRate(sampleRate), mType(type)
		, mOutChannelCount(outChannelCount), mMinOutLatencyMs(minOutLatencyMs), mMaxOutLatencyMs(maxOutLatencyMs)
		, mInChannelCount(inChannelCount), mMinInLatencyMs(minInLatencyMs), mMaxInLatencyMs(maxInLatencyMs)
	{
	}

	// Destructor
	SAudioDevice :: ~SAudioDevice()
	{
	}

	//[GETTER] Get a self description
	irr::core::stringc SAudioDevice::toString() const
	{
		irr::core::stringc txt("SAudioDevice{ ");

		// Print Type
		if (mType == EADT_NONE)
			txt += "None";
		else if (mType == EADT_OUTPUT)
			txt += "Output";
		else if (mType == EADT_INPUT)
			txt += "Input";
		else if (mType == EADT_FULLDUPLEX)
			txt += "Duplex";
		else
			txt += "Invalid";
		txt += ", ";

		// Print Name
		txt += mName;
		txt += ", ";
		
		// Print SampleRate
		txt += mSampleRate;
		txt += " Hz";

		// Print Channels
		if ((mType == EADT_OUTPUT) || (mType == EADT_FULLDUPLEX))
		{
			txt += ", O:(";
			txt += mOutChannelCount;
			txt += ",";
			txt += mMinOutLatencyMs;
			txt += ",";
			txt += mMaxOutLatencyMs;
			txt += ")";
		}

		if ((mType == EADT_INPUT) || (mType == EADT_FULLDUPLEX))
		{
			txt += ", I:(";
			txt += mInChannelCount;
			txt += ",";
			txt += mMinInLatencyMs;
			txt += ",";
			txt += mMaxInLatencyMs;
			txt += ")";
		}

		txt += " }";
		return txt;
	}

/// =========================================================================================
/// @class CAudioEngine
/// =========================================================================================
	
	// Default Constructor
	CAudioEngine :: CAudioEngine()
	{
		dbPRINT( "CAudioEngine::CAudioEngine()\n" );
		
		mAPIs.clear();
		mDevices.clear();

		PaError e = Pa_Initialize();
		
		if( e == paNoError )
		{
			// do stuff
			update();
		}

	}

	CAudioEngine :: ~CAudioEngine()
	{
		//dbPRINT( "CAudioEngine::~CAudioEngine()\n" );

		Pa_Terminate();
	}

	void CAudioEngine :: update()
	{
		dbPRINT( "CAudioEngine::update()\n" );

		mAPIs.clear();
		mDevices.clear();
		
		/// -------------------------------------------------------------------------------------------------------------
		/// Collect APIs
		/// -------------------------------------------------------------------------------------------------------------

		const PaHostApiIndex apiCount = Pa_GetHostApiCount();
		//const PaHostApiIndex defaultApi = Pa_GetDefaultHostApi();
		
		for ( PaHostApiIndex i = 0; i < apiCount; i++ )
		{
			const PaHostApiInfo* info = Pa_GetHostApiInfo( i );
			if ( info )
			{
				SAudioAPI api( info->name, info->type, info->deviceCount );

				//for ( s32 i = 0; i < nfo->deviceCount; i++ )
				//{
				//	PaDeviceIndex devIndex = Pa_HostApiDeviceIndexToDeviceIndex( apiIndex, i );
				//
				//	dbPRINT( " [%d]", i);
				//}
				//
				//dbPRINT( "\n" );

				mAPIs.push_back(api);
			}
		}

		/// -------------------------------------------------------------------------------------------------------------
		/// Collect Devices
		/// -------------------------------------------------------------------------------------------------------------

		// find number of AudioDevices
		const PaDeviceIndex devCount = Pa_GetDeviceCount();

		// iterate all AudioDevices
		for ( PaDeviceIndex i = 0; i < devCount; i++ )
		{
			// get pointer to info-struct
			const PaDeviceInfo* info = Pa_GetDeviceInfo( i );

			// if pointer ok
			if (info)
			{
				PaHostApiIndex apiIndex = info->hostApi;
				irr::core::stringc devName = info->name;
				u32 sampleRate = info->defaultSampleRate;
				u32 outChCount = info->maxOutputChannels;
				f64 outMinLatency = 1000.0*(f64)info->defaultLowOutputLatency;	// from seconds to milliseconds
				f64 outMaxLatency = 1000.0*(f64)info->defaultHighOutputLatency;	// from seconds to milliseconds
				u32 inChCount = info->maxInputChannels;
				f64 inMinLatency = 1000.0*(f64)info->defaultLowInputLatency;	// from seconds to milliseconds
				f64 inMaxLatency = 1000.0*(f64)info->defaultHighInputLatency;	// from seconds to milliseconds
				
				// determine Type of AudioDevice 
				// by validating number of input- and output-channels
				E_AUDIO_DEVICE_TYPE devType = EADT_COUNT;
				if (inChCount > 0)
					if (outChCount > 0)
						devType = EADT_FULLDUPLEX;	// Duplex
					else
						devType = EADT_INPUT;	// Input
				else
					if (outChCount > 0)
						devType = EADT_OUTPUT;	// Output
					else
						devType = EADT_NONE;	// NoValidDevice						

				SAudioDevice dev( devName, sampleRate, devType, outChCount, outMinLatency, outMaxLatency, inChCount, inMinLatency, inMaxLatency );

				mDevices.push_back( dev );
			}
		}
	}

	u32 CAudioEngine :: getNumAPIs() const
	{
		return mAPIs.size();
	}
	
	u32 CAudioEngine :: getNumDevices() const
	{
		return mDevices.size();
	}

	u32 CAudioEngine :: getNumInputDevices() const
	{
		u32 result = 0;
		const u32 devCount = mDevices.size();
		for (u32 i=0; i<devCount; i++)
		{
			const SAudioDevice& dev = mDevices[i];
			const E_AUDIO_DEVICE_TYPE& typ = dev.getType();
			if (typ == EADT_INPUT)
			{
				result++;
			}
		}

		return result;
	}

	u32 CAudioEngine :: getNumOutputDevices() const
	{
		u32 result = 0;
		const u32 devCount = mDevices.size();
		for (u32 i=0; i<devCount; i++)
		{
			const SAudioDevice& dev = mDevices[i];
			const E_AUDIO_DEVICE_TYPE& typ = dev.getType();
			if (typ == EADT_OUTPUT)
			{
				result++;
			}
		}

		return result;
	}

	u32 CAudioEngine :: getNumDuplexDevices() const
	{
		u32 result = 0;
		const u32 devCount = mDevices.size();
		for (u32 i=0; i<devCount; i++)
		{
			const SAudioDevice& dev = mDevices[i];
			const E_AUDIO_DEVICE_TYPE& typ = dev.getType();
			if (typ == EADT_FULLDUPLEX)
			{
				result++;
			}
		}

		return result;
	}

	SAudioDevice* CAudioEngine :: getDefaultInputDevice()
	{
		const PaDeviceIndex defaultInput = Pa_GetDefaultInputDevice();

		// missing something

		return NULL;

	}

	SAudioDevice* CAudioEngine :: getDefaultOutputDevice()
	{
		const PaDeviceIndex defaultOutput = Pa_GetDefaultOutputDevice();
		
		// missing something

		return NULL;
	}

	SAudioDevice* CAudioEngine :: getInputDevice( u32 index )
	{
		/// validate index
		if (index >= getNumInputDevices())
			return NULL;

		const u32 devCount = getNumDevices();

		u32 c = 0;
		for ( u32 i = 0; i < devCount; i++)
		{
			if ( mDevices[i].getType() == EADT_INPUT )
			{
				if (index == c)
					return &mDevices[i];

				c++;
			}
		}

		return NULL;
	}

	SAudioDevice* CAudioEngine :: getOutputDevice( u32 index )
	{
		/// validate index
		if (index >= getNumOutputDevices())
			return NULL;

		const u32 devCount = getNumDevices();

		u32 c = 0;
		for ( u32 i = 0; i < devCount; i++)
		{
			if ( mDevices[i].getType() == EADT_OUTPUT )
			{
				if (index == c)
					return &mDevices[i];

				c++;
			}
		}

		return NULL;
	}

	SAudioDevice* CAudioEngine :: getDuplexDevice( u32 index )
	{
		/// validate index
		if (index >= getNumDuplexDevices())
			return NULL;

		const u32 devCount = getNumDevices();

		u32 c = 0;
		for ( u32 i = 0; i < devCount; i++)
		{
			if ( mDevices[i].getType() == EADT_FULLDUPLEX )
			{
				if (index == c)
					return &mDevices[i];

				c++;
			}
		}

		return NULL;
	}

	//[GETTER] Get a self description
	irr::core::stringc CAudioEngine::toString()
	{
		irr::core::stringc txt("CAudioEngine{\n");
		txt += "DeviceCount = "; txt += getNumDevices(); txt += "\n"; 

		const u32 numInDev = getNumInputDevices();
		const u32 numOutDev = getNumOutputDevices();
		const u32 numDuplexDev = getNumDuplexDevices();

		txt += "OutputDeviceCount = "; txt += numOutDev; txt += "\n"; 
		txt += "InputDeviceCount = "; txt += numInDev; txt += "\n";
		txt += "DuplexDeviceCount = "; txt += numDuplexDev; txt += "\n";

		// Print Output Devices
		for ( u32 i = 0; i < numOutDev; i++ )
		{
			SAudioDevice* dev = getOutputDevice( i );
			if (dev)
			{
				txt += dev->toString();
				txt += "\n";
			}
		}

		// Print Input Devices
		for ( u32 i = 0; i < numInDev; i++ )
		{
			SAudioDevice* dev = getInputDevice( i );
			if (dev)
			{
				txt += dev->toString();
				txt += "\n";
			}
		}

		// Print Duplex Devices
		for ( u32 i = 0; i < numDuplexDev; i++ )
		{
			SAudioDevice* dev = getDuplexDevice( i );
			if (dev)
			{
				txt += dev->toString();
				txt += "\n";
			}
		}

		return txt;
	}

} // end namespace irr