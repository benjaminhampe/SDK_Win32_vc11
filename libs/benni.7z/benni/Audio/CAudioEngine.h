// Copyright (C) 2002-2014 Benjamin Hampe
// This file is part of the program "BPM Studio 6.0"
// For conditions of distribution and use, see copyright notice in license.txt

#ifndef BPM6_C_AUDIO_ENGINE_H_INCLUDED
#define BPM6_C_AUDIO_ENGINE_H_INCLUDED

#include <bpm6/Config.h>
#include <bpm6/audio/loader/IAudioLoader.h>
#include <bpm6/audio/writer/IAudioWriter.h>

#include <bpm6/debugPrint.h>

#include <portaudio.h>

namespace bpm
{
	/// =========================================================================================
	/// @class E_AUDIO_DEVICE_TYPE
	/// =========================================================================================

	enum E_AUDIO_DEVICE_TYPE
	{
		EADT_NONE=0,	// should never exist
		EADT_INPUT,
		EADT_OUTPUT,
		EADT_FULLDUPLEX,
		EADT_COUNT
	};

	/// =========================================================================================
	/// @class SAudioAPI
	/// =========================================================================================

	class SAudioAPI
	{
		irr::core::stringc mName;
		s32 mIndex;
		u32 mDeviceCount;
		s32 mDefaultInDevice;
		s32 mDefaultOutDevice;

	public:

		// Value Constructor
		SAudioAPI( const irr::core::stringc& apiName, s32 index = 0, u32 devCount = 0 );

		// Destructor
		~SAudioAPI();

		//[GETTER] Get name of device
		const irr::core::stringc& getName() const { return mName; }

		//[GETTER] Get portaudio API-index of device
		s32 getIndex() const { return mIndex; }

		//[GETTER] Get number of devices that can use this API
		u32 getDeviceCount() const { return mDeviceCount; }

		//[GETTER] Get a self description
		irr::core::stringc toString() const;
	};

	/// =========================================================================================
	/// @class SAudioDevice
	/// =========================================================================================

	class SAudioDevice
	{
		// Name
		irr::core::stringc mName;
		
		// SampleRate
		u32 mSampleRate;
		
		// Type
		E_AUDIO_DEVICE_TYPE mType;
		
		// Output Channels
		u32 mOutChannelCount;
		double mMinOutLatencyMs;
		double mMaxOutLatencyMs;
		
		// Input Channels
		u32 mInChannelCount;
		double mMinInLatencyMs;
		double mMaxInLatencyMs;

	public:

		// Default Constructor	
		SAudioDevice();

		// Value Constructor
		SAudioDevice(
			const irr::core::stringc& name,	u32 sampleRate = 0,	E_AUDIO_DEVICE_TYPE type = EADT_COUNT,
			u32 outChannelCount = 0, double minOutLatencyMs = 0.0, double maxOutLatencyMs = 0.0,
			u32 inChannelCount = 0,	double minInLatencyMs = 0.0, double maxInLatencyMs = 0.0 );

		// Destructor
		~SAudioDevice();

		//[GETTER] Get name of device
		const irr::core::stringc& getName() const { return mName; }

		//[GETTER] Get Type of device
		const E_AUDIO_DEVICE_TYPE& getType() const { return mType; }

		//[GETTER] Get Number of Output Channels
		const u32& getNumOutputChannel() const { return mOutChannelCount; }

		//[GETTER] Get Number of Input Channels
		const u32& getNumInputChannel() const { return mInChannelCount; }

		//[GETTER] Get a self description
		irr::core::stringc toString() const;
	};

	/// =========================================================================================
	/// @class CAudioEngine
	/// =========================================================================================

	class CAudioEngine
	{
	public: 


	private:
		irr::core::array<SAudioAPI> mAPIs;
		irr::core::array<SAudioDevice> mDevices;

	public:
		CAudioEngine();

		~CAudioEngine();

		u32 getNumAPIs() const;
	
		u32 getNumDevices() const;

		u32 getNumInputDevices() const;

		u32 getNumOutputDevices() const;

		u32 getNumDuplexDevices() const;

		SAudioDevice* getDefaultInputDevice();

		SAudioDevice* getDefaultOutputDevice();

		SAudioDevice* getInputDevice( u32 index );

		SAudioDevice* getOutputDevice( u32 index );

		SAudioDevice* getDuplexDevice( u32 index );

		void update(); // update from outside world

		//[GETTER] Get a self description
		irr::core::stringc toString();
	};

	/// =========================================================================================
	/// 
	/// =========================================================================================

} // end namespace bpm

#endif // BPM6_C_AUDIO_ENGINE_H_INCLUDED
