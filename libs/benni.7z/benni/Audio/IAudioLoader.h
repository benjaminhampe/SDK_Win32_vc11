// Copyright (C) 2002-2014 Benjamin Hampe
// This file is part of the "irrlicht-engine"
// For conditions of distribution and use, see copyright notice in irrlicht.h

#ifndef BPM6_I_AUDIO_LOADER_H_INCLUDED
#define BPM6_I_AUDIO_LOADER_H_INCLUDED

#include <BMEngine.h>

#include <IAudioSource.h>

namespace bpm
{
	class IAudioLoader : public irr::IReferenceCounted
	{
		virtual AnsiString getName() const = 0;

		virtual bool isFileSupported( const SPath& uri) const = 0;

		virtual IAudioSource* load( const SPath& uri ) const = 0;
	};

} // end namespace bpm

#endif // BPM6_I_AUDIO_LOADER_H_INCLUDED
