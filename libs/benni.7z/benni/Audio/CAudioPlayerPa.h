#pragma once

#include <bpm6/Config.h>

namespace bpm {

class CAudioPlayerPa
{
public:
	CAudioPlayerPa(void);
	~CAudioPlayerPa(void);
};

} // end namespace bpm