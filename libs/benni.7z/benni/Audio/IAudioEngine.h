// Copyright (C) 2002-2014 Benjamin Hampe
// This file is part of the program "BPM Studio 6.0"
// For conditions of distribution and use, see copyright notice in license.txt

#ifndef BPM6_I_AUDIO_ENGINE_H_INCLUDED
#define BPM6_I_AUDIO_ENGINE_H_INCLUDED

#include <bpm6/Config.h>

// #include "IAudioSource.h"
#include <bpm6/audio/loader/IAudioLoader.h>
#include <bpm6/audio/writer/IAudioWriter.h>

namespace bpm
{


	class IAudioEngine : public irr::IReferenceCounted // public IWorkerThread
	{
	public:

		/// Constructor

		IAudioEngine()
		{

		}

		/// Constructor

		virtual ~IAudioEngine() = 0;
		
		/// Get Engine Infos

		virtual AnsiString getName() const = 0;

		virtual WideString getDescription() const = 0;

		virtual u32 getVersion() const = 0;

		/// Get Inputs

		// virtual u32 getInputCount() const;
		
		// virtual IAudioSource* getInput( u32 index );

		/// Get Outputs

		// virtual u32 getOutputCount() const;
		
		// virtual IAudioSource* getOutput( u32 index );

		/// Get Loader

		virtual u32 getLoaderCount() const;
		
		virtual IAudioLoader* getLoader( u32 index );

		/// Get Writer

		virtual u32 getWriterCount() const;
		
		virtual IAudioWriter* getWriter( u32 index );

		/// Setter

		virtual void run() = 0;
		
		virtual void OnInit() = 0;
		
		virtual void OnFinish() = 0;

	};


} // end namespace bpm

#endif // BPM6_I_AUDIO_ENGINE_H_INCLUDED
