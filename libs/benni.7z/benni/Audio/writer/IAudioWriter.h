// Copyright (C) 2002-2014 Benjamin Hampe
// This file is part of the "irrlicht-engine"
// For conditions of distribution and use, see copyright notice in irrlicht.h

#ifndef BPM6_I_AUDIO_WRITER_H_INCLUDED
#define BPM6_I_AUDIO_WRITER_H_INCLUDED

#include "IAudioSource.h"



namespace bpm
{
	class IAudioWriter : public irr::IReferenceCounted
	{
		irr::core::stringc mName;
		irr::core::stringc mDescription;

		irr::core::array<irr::core::stringc> mSupportedFileExtensions;

	public:

		static const char* getErrorText( irr::u32 err );

		virtual irr::core::stringc getName() const = 0;

		virtual  isFileExtSupported( const irr::core::stringc& filename ) const = 0;

		virtual bool isFileExtSupported( const irr::core::stringc& filename ) const = 0;

		virtual bool writeFile( const irr::core::stringc& filename, IAudioSource* source ) const = 0;

		virtual irr::u32 getError() const;

	};

} // end namespace irr

#endif // BPM6_I_AUDIO_WRITER_H_INCLUDED