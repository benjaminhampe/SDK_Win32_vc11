// Copyright (C) 2002-2014 Benjamin Hampe
// This file is part of the "irrlicht-engine"
// For conditions of distribution and use, see copyright notice in irrlicht.h

#ifndef BPM6_I_AUDIO_SOURCE_H_INCLUDED
#define BPM6_I_AUDIO_SOURCE_H_INCLUDED

#include <IReferenceCounted.h>
#include <irrTypes.h>

namespace bpm
{
	/// @class IAudioSource / IAudioTrack
	class IAudioSource : public irr::IReferenceCounted
	{
	public:
		virtual SPath getFileName() const = 0;

		/// @brief Get Number # of Samples in this Track
		virtual size_t getSampleCount() const = 0;

		/// @brief Get Number # of Samples in this Track
		virtual E_AUDIO_SAMPLE_TYPE getSampleType() const = 0;

		/// @brief Get Sample-Rate per seconds
		virtual u32 getSampleRate() const = 0;

		/// @brief Get Number # of Channel in this track
		virtual u32 getChannelCount( ) const = 0;

		/// @brief Get Duration of this track in multiple of milliseconds
		virtual u32 getDuration() const = 0;

		/// @brief Get Duration of this track in fractions of seconds
		virtual Real getDurationAsSeconds() const = 0;

		/// @brief Get Position in this track in multiple of milliseconds
		virtual u32 getPosition() = 0;

		/// @brief Get Position in this track in fractions of seconds
		virtual Real getPositionAsSeconds() = 0;

		/// @brief Set Position in this track in multiple of milliseconds
		virtual void setPosition( const u32& time_index_in_ms ) = 0;

		/// @brief Set Position in this track in fractions of seconds
		virtual void setPositionAsSeconds( const Real& seconds ) = 0;

		virtual void seek( s32 timeInMillis ) = 0;

		virtual void getSamples( SampleBuffer& container, u32 numSamples, u32 timeStart, u32 channelIndex ) const = 0;

		virtual bool getSamples( SampleBuffer& container, u32 numSamples, u32 channel_index, f32 time_start, f32 time_end ) const = 0;

		virtual void getSamples( SampleBufferf& container, u32 numSamples, u32 timeStart, u32 channelIndex ) const = 0;
	};		

} // end namespace bpm

#endif // BPM6_I_AUDIO_SOURCE_H_INCLUDED
