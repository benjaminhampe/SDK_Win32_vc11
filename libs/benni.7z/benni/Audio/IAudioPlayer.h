// Copyright (C) 2002-2014 Benjamin Hampe
// This file is part of the "irrlicht-engine"
// For conditions of distribution and use, see copyright notice in irrlicht.h

#ifndef BPM6_I_AUDIO_PLAYER_H_INCLUDED
#define BPM6_I_AUDIO_PLAYER_H_INCLUDED

#include <bpm6/Config.h>

#include <irrlicht.h>

namespace bpm
{

enum E_AUDIO_PLAY_STATUS
{
	EAPS_ERROR=0,
	EAPS_STOPPED,
	EAPS_PAUSED,
	EAPS_PLAYING
};

class IAudioPlayer : public irr::IReferenceCounted
{
//private:
//protected:
//	IAudioEngine* mEngine;
//	IAudioPlayList* mPlayList;
//	f32 mVolume;
//	f32 mPitch;
//	f32 mPan;
//	bool mIsLoaded;
//	bool mIsPlaying;
//	bool mIsShuffled;
//	bool mIsLooped;
//	// s32 mLoops; // -1 = inf loop, 0 = no looping, >0 number of loops
//
//	irr::core::array<IAudioSource*> mSources;
//	irr::core::array<IAudioLoader*> mSourceLoader;
//	irr::core::array<IAudioWriter*> mSourceWriter;
//
//public:
//	IAudioPlayer()
//	: mVolume(0.5f), mPitch(1.0f), mPan(0.0f)
//	, mIsLoaded(false), mIsPlaying(false), mIsShuffled(false), mIsLooped(false)
//	{
//
//	}
//
//	virtual IAudioEngine* getEngine( ) { return mEngine; }
//
//	virtual IAudioPlayList* getPlayList( ) { return mPlayList; }
//
//	virtual SPath getPlayListItemFileName( s32 index = -1 )
//	{ 
//		if (!mPlayList)
//			return SPath( _IRR_TEXT("") );
//
//		return mPlayList->getItemFileName(index);
//	}
//
//	virtual u32 getPlayListItemCount( ) const
//	{ 
//		if (!mPlayList)
//			return 0;
//
//		return mPlayList->getItemCount();
//	}
//
//	virtual IAudioSource* getPlayListItem( s32 index ) 
//	{ 
//		if (!mPlayList)
//			return NULL;
//
//		return mPlayList->getItem( index );
//	}
//
//	virtual f32 getVolume() const 
//	{ 
//		return mVolume; 
//	}
//
//	virtual f32 getPitch() const 
//	{ 
//		return mPitch; 
//	}
//
//	virtual f32 getPan() const 
//	{ 
//		return mPan; 
//	}
//
//	/// Player Control
//	virtual void stop() = 0;
//	virtual void panic() = 0;
//	virtual void mute() = 0;
//	virtual void play() = 0;
//	virtual void pause() = 0;
//	virtual void resume() = 0;
//
//	virtual void setPlayerPitch( f32 value ) = 0;
//	virtual void setPlayerVolume( f32 value ) = 0;
//	virtual void setPlayerPan( f32 value ) = 0;
//
//	virtual bool loadPlayList( const SPath& filename ) = 0;
//	virtual bool savePlayList( const SPath& filename ) = 0;
//
//	virtual E_AUDIO_PLAY_STATUS getStatus() const = 0;
//
//	virtual bool setLooped( bool looped )
//	{
//		mIsLooped = looped;
//	}
//
//	virtual void setShuffled( bool shuffled )
//	{
//		mIsShuffled = shuffled;
//	}
//
//	virtual bool isLoaded() const
//	{
//		return mIsLoaded;
//	}
//
//	virtual bool isPlaying() const = 0;
//
//	virtual bool isLooped() const
//	{
//		return mIsLooped;
//	}
//
//	virtual bool isShuffled() const
//	{
//		return mIsShuffled;
//	}
//
//
//	virtual u32 getOutputDeviceCount( ) const = 0;
//	virtual bool setOutputDevice( u32 card = 0, u32 sub_device = 0 ) = 0;
//	virtual SPath getOutputDeviceName( u32 card = 0, u32 sub_device = 0) const = 0;
//	virtual s32 getDefaultOutputDevice( ) const = 0;
//
//	virtual core::FourierTransformRtoC* getFourierTransform() = 0;

/// Direct Access to SoundBuffer
//	virtual void* getSoundBuffer() = 0;

//	virtual const s16* getSamples() = 0;


};

} // end namespace irr

#endif // BPM6_I_AUDIO_PLAYER_H_INCLUDED
