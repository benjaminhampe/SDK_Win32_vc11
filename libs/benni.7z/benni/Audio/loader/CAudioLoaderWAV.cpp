#include "CAudioLoaderWAV.h"

namespace bpm {

} // end namespace bpm