////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include "ALListener.h"
#include "ALCheck.h"


namespace bpm
{
////////////////////////////////////////////////////////////
void Listener::setGlobalVolume(float volume)
{
    priv::ensureALInit();

    alCheck(alListenerf(AL_GAIN, volume * 0.01f));
}


////////////////////////////////////////////////////////////
float Listener::getGlobalVolume()
{
    priv::ensureALInit();

    float volume = 0.f;
    alCheck(alGetListenerf(AL_GAIN, &volume));

    return volume * 100;
}


////////////////////////////////////////////////////////////
void Listener::setPosition(float x, float y, float z)
{
    priv::ensureALInit();

    alCheck(alListener3f(AL_POSITION, x, y, z));
}


////////////////////////////////////////////////////////////
void Listener::setPosition(const Vector3f& position)
{
    setPosition(position.x, position.y, position.z);
}


////////////////////////////////////////////////////////////
Vector3f Listener::getPosition()
{
    priv::ensureALInit();

    Vector3f position;
    alCheck(alGetListener3f(AL_POSITION, &position.x, &position.y, &position.z));

    return position;
}


////////////////////////////////////////////////////////////
void Listener::setDirection(float x, float y, float z)
{
    priv::ensureALInit();

    float orientation[] = {x, y, z, 0.f, 1.f, 0.f};
    alCheck(alListenerfv(AL_ORIENTATION, orientation));
}


////////////////////////////////////////////////////////////
void Listener::setDirection(const Vector3f& direction)
{
    setDirection(direction.x, direction.y, direction.z);
}


////////////////////////////////////////////////////////////
Vector3f Listener::getDirection()
{
    priv::ensureALInit();

    float orientation[6];
    alCheck(alGetListenerfv(AL_ORIENTATION, orientation));

    return Vector3f(orientation[0], orientation[1], orientation[2]);
}

} // end namespace bpm
