// Copyright (C) 2002-2014 Benjamin Hampe
// This file is part of the "irrlicht-engine"
// For conditions of distribution and use, see copyright notice in irrlicht.h

#ifndef BPM6_I_PLAYLIST_H_INCLUDED
#define BPM6_I_PLAYLIST_H_INCLUDED

#include <bpm6/Config.h>

#include <irrlicht.h>

namespace bpm
{

class SPlayListItem
{
};

class IPlayList : public irr::IReferenceCounted
{

private:

protected:
	s32 mSelected;
	irr::core::array<SPlayListItem> mTracks;

public:
	IPlayList( u32 l_count = 32 ) : mSelected(-1)
	{
		mTracks.clear();
		if (l_count>0)
			mTracks.reallocate( l_count );
		mTracks.set_used( 0 );
	}

	virtual ~IPlayList()
	{
		/// @todo: each audiosource should have been grabbed and dropped before this
		mTracks.clear();
	}

	virtual u32 getItemCount() const
	{
		return mTracks.size();
	}

	virtual s32 getSelectedItemIndex() const 
	{ 
		return mSelected; 
	}

	virtual SPlayListItem& getSelectedItem()
	{ 
		IRR_DEBUG_BREAK_IF( mSelected <= -1 )
		return mTracks[mSelected];
	}

	virtual const SPlayListItem& getSelectedItem() const
	{ 
		IRR_DEBUG_BREAK_IF( mSelected <= -1 )
		return mTracks[mSelected];
	}
	
	virtual SPlayListItem& getItem( s32 index = -1 )
	{
		if (index<0)
		{
			return getSelectedItem();
		}
		else
		{
			u32 i = (u32)index;
			IRR_DEBUG_BREAK_IF( i >= getItemCount() )
			return mTracks[i];
		}
	}

	virtual const SPlayListItem& getItem( s32 index = -1 ) const
	{
		if (index<0)
		{
			return getSelectedItem();
		}
		else
		{
			u32 i = (u32)index;
			IRR_DEBUG_BREAK_IF( i >= getItemCount() )
			return mTracks[i];
		}
	}

	virtual bool load( const SPath& filename ) = 0;

	virtual bool save( const SPath& filename ) const = 0;

};

} // end namespace bpm

#endif // __BPM6_I_AUDIO_PLAYLIST_H__
