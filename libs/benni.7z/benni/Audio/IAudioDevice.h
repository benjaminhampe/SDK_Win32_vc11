// Copyright (C) 2002-2014 Benjamin Hampe
// This file is part of the program "BPM Studio 6.0"
// For conditions of distribution and use, see copyright notice in license.txt

#ifndef __BPM_I_AUDIO_DEVICE_H__
#define __BPM_I_AUDIO_DEVICE_H__

#include <bpm6/Config.h>

namespace bpm
{


} // end namespace bpm

#endif // __BPM_C_AUDIO_DEVICE_H__
