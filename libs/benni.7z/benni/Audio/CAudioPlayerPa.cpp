#include "CAudioPlayerPa.h"

namespace bpm {

CAudioPlayerPa::CAudioPlayerPa(void)
{
}


CAudioPlayerPa::~CAudioPlayerPa(void)
{
}

} // end namespace bpm