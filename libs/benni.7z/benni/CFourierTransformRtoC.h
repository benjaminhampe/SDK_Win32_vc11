// Copyright (C) 2002-2014 Benjamin Hampe
// This file is part of the "irrlicht-engine"
// For conditions of distribution and use, see copyright notice in irrlicht.h

#ifndef BPM6_C_FOURIER_TRANSFORM_REAL_TO_COMPLEX_H_INCLUDED
#define BPM6_C_FOURIER_TRANSFORM_REAL_TO_COMPLEX_H_INCLUDED

#include <fftw3.h>
#include <irrTypes.h>
#include <irrArray.h>
#include <irrMath.h>
#include <irrString.h>
#include <IReferenceCounted.h>

namespace irr
{
namespace core
{
	template <class T> struct TRange
	{
		T Min;
		T Max;

		TRange() : Min(T(0)), Max(T(1))
		{}

		TRange( const T& min, const T& max ) : Min(min), Max(max)
		{}

		T d() const
		{
			return Max - Min;
		}
	};

	/// @class DISCRETE FOURIER_TRANSFORM real x[n] to complex F[s]

	//          N-1
	//          ---
	//          \            -( 2pi * i * n * m / N)
	//   F[m] = /    x[n] * e
	//          ---
	//          n=1
	//

	/// @class FOURIER_TRANSFORM real to complex
	/** @brief Umwandlung von Zeitbereich A(t) in Frequenzbereich F(s), s ist komplex
	 *	y = A(x), mit x = 0...N-1 numbers
	 *	in den Frequenzraum F[index] = a + b*i
	 *	z = F(s) = a + b*i, mit s = 0...N-1 numbers
	 *  f_step = SampleRate/FFT-Size, z.B. SampleRate = 44100 Hz und FFT-Size = 1024
	 *  f[n] = n * f_step -> f[0] = 43.066 Hz, f[N/2-1] = 22006.9 Hz,
	 *  f[n>=N/2] ist symmetrisch bezüglich X-Achse, also konjugiert komplexe Einheitswurzeln
	 *  enthält also keine neue Information und ist damit unwichtig/redundant
	 *
	 */
	template<class T>
	class TComplex
	{
	private:
		T re;
		T im;

	public:
		TComplex() : re((T)0), im((T)0) {}

		TComplex( T realPart, T imagPart ) : re(realPart), im(imagPart) {}

		~TComplex() {}

		REALINLINE T getSquared() const
		{
			return re*re + im*im;
		}

		REALINLINE T getLength() const
		{
			return core::squareroot( getSquared() );
		}

		REALINLINE T getRadians() const
		{
			return atan2(im,re);
		}

		REALINLINE T getDegrees() const
		{
			return 2.0*core::PI64*getRadians();
		}

		core::stringc toString() const
		{
			core::stringc txt("{ ");
			txt += re;
			txt += ", ";
			txt += im;
			txt += "}";
			return txt;
		}
	};


	/*
	 *	FourierTransform is orthogonal and symmetric
	 *
	 *  Ermöglicht eine rein geometrische Deutung des Interferenzmuster des Doppelspalt-Experimentes
	 *  der Physik ( Quantenmechanik )als Fouriertransformierte des Doppelspaltes selbst,
	 *  das setzt voraus dass Licht eine Welle sein muss.
	 *
	 *  Spalt = Deltadistribution auf X-Achse --> Interferenzmuster == Sinc Funktion
	 *
	 *  denn FT(delta(t)) = sinc(s)
	 *
	 *  Einfachstes diskretes Signal ( Peak ) wird zu einer Sincfunktion mit kontinuierlichem Spektrum.
	 */

	template<class T>
	class TComplexArray : public IReferenceCounted
	{
	private:
		core::array<TComplex<T>> Data;
	public:

	};

	class CFourierTransformRtoC : public IReferenceCounted
	{
	private:
		u32  			Size;
		f64*			InputData;	// real input-vector
		fftw_complex*	OutputData; // complex output-vector
		fftw_plan 		Plan;
		core::stringc   WisdomFile;

	public:
		CFourierTransformRtoC( u32 fft_size = 1024, const c8* wisdomFile = "CFourierTransformRtoC.wisdom" );
		~CFourierTransformRtoC();

		u32 size() const;
		void clear();
		bool resize( u32 fft_size );
		void fft();

		void loadWisdom( const c8* wisdomFile );
		void saveWisdom( const c8* wisdomFile ) const;

		core::stringc getPlanInfo() const;

		// methods for generic types

		template<class T>
		core::TRange<T> getMinMax( const core::array<T>& _in, T min_init, T max_init ) const
		{
			core::TRange<T> result( min_init, max_init );

			for (u32 i=0; i<_in.size(); i++)
			{
				const T value = _in[i];

				if (result.Min > value)
					result.Min = value;

				if (result.Max < value)
					result.Max = value;
			}

			return result;
		}

		template<class T>
		void setInputData( const core::array<T>& _in )
		{
			u32 i_max = core::min_<u32>( _in.size(), Size );

			for (u32 i=0; i<i_max; i++)
			{
				InputData[i] = (f64)_in[i];
			}

			if (i_max < Size)
			{
				for (u32 i=i_max; i<Size; i++)
				{
					InputData[i] = 0.0;
				}
			}
		}

//		template<class T>
//		void getPowerSpectrum( core::array<T>& _out )
//		{
//			const u32 i_max = core::min_<u32>( _out.size(), Size );
//
//			_out.set_used( 0 );
//
//			for (u32 i=0; i<i_max; i++)
//			{
//				const fftw_complex& z = OutputData[i];		// Lesezugriff auf komplexe Zahl
//
//				f64 z_abs = sqrt( z[0]*z[0] + z[1]*z[1] );	// Betrag der komplexen Zahl z
//
//				_out.push_back( ((T)z_abs) );
//			}
//
//			const core::vector2d<T> z_minmax = getMinMax<T>( _out, (T)FLT_MAX, (T)FLT_MIN );
//			const f64 z_range_inv = core::reciprocal( (f64)z_minmax.Y - (f64)z_minmax.X );
//
//			for (u32 i=0; i<i_max; i++)
//			{
//				T value = (T)(z_range_inv*((f64)_out[i]-(f64)z_minmax.X));
//				_out[i] = value;
//			}
//		}

		fftw_complex* getFrequencySpectrum()
		{
			return OutputData;
		}

		template <class T>
		void getPowerSpectrum( core::array<T>& _out, T dB_min, T dB_max, T dB_threshold )
		{
			const u32 i_max = core::min_<u32>( _out.size(), Size );

			_out.set_used( 0 );

			const T dB_range = dB_max - dB_min;
			const T dB_range_inv = (dB_range>(T)0) ? core::reciprocal( dB_range ) : (T)0;
			const T dB_correct = (T)4 / ( (T)Size * (T)Size ); // make independant from fft_size

			f32 re, im, zm;

			for (u32 i=0; i<i_max; i++)
			{
				const fftw_complex& z = OutputData[i];		// hole komplexe Zahl z
				re = (T)z[0];
				im = (T)z[1];
				zm = re*re + im*im;			// |z|^2 == abs(z)^2
				zm *= dB_correct;			// make z^2 independant of FFT-Size by dividing by FFT-Size/2
				zm = log10( zm )*40;	// convert to decibels == 20*log(|z|) = 40*log(|z|^(1/2)) --> saves rootcalc
				zm -= dB_min;				// set user minimum as new origin
				if (zm < dB_threshold ) 	// threshold
				{
					zm = dB_threshold;
				}
				zm *= dB_range_inv;			// scale to range [0,1]
				// zm = core::clamp<f32>( zm, 0.0f, 1.0f );
				_out.push_back( zm );
			}
		}


		void getPowerSpectrumThreshold32(
			core::array<f32>& _out, f32 min, f32 max, f32 threshold )
		{
			const u32 i_max = core::min_<u32>( _out.size(), Size );

			_out.set_used( 0 );

			const f32 db_range = max - min;

			const f32 db_range_inv = (db_range>0.0f) ? core::reciprocal( db_range ) : 0.0f;

			const f32 f_correct = 2.0f / (f32)Size; // make independant from fft_size

			f32 re, im, zm;

			for (u32 i=0; i<i_max; i++)
			{
				const fftw_complex& z = OutputData[i];		// hole komplexe Zahl z
				re = (f32)z[0];
				im = (f32)z[1];
				zm = f_correct*sqrtf( re*re + im*im );	// |z| == abs(z)
				zm = 20.0f*log10f( zm );				// convert to decibels == 10*log(|z|)
				//zm *= f_correct;				// make independant of FFT-Size by dividing by FFT-Size/2
				zm -= min;						// set user minimum as new origin

				if (zm < threshold )		// threshold
					zm = 0.0f;

				zm *= db_range_inv;				// scale to range [0,1]

				// zm = core::clamp<f32>( zm, 0.0f, 1.0f );

				_out.push_back( zm );
			}
		}
		/*
		void getPowerSpectrumThreshold32( core::array<f32>& _out, f32 dB_min, f32 dB_max, f32 dB_threshold )
		{
			const u32 i_max = core::min_<u32>( _out.size(), Size );

			_out.set_used( 0 );

			const f32 dB_range = dB_max - dB_min;
			const f32 dB_range_inv = (dB_range>0.0f) ? core::reciprocal( dB_range ) : 0.0f;
			const f32 dB_correct = 4.0f / ( (f32)Size * (f32)Size ); // make independant from fft_size

			f32 re, im, zm;
			for (u32 i=0; i<i_max; i++)
			{
				const fftw_complex& z = OutputData[i];		// hole komplexe Zahl z
				re = (f32)z[0];
				im = (f32)z[1];
				zm = re*re + im*im;			// |z|^2 == abs(z)^2
				zm *= dB_correct;			// make z^2 independant of FFT-Size by dividing by FFT-Size/2
				zm = 40.0f*log10f( zm );	// convert to decibels == 20*log(|z|) = 40*log(|z|^(1/2)) --> saves rootcalc
				zm -= dB_min;				// set user minimum as new origin
				if (zm < dB_threshold ) 	// threshold
				{
					zm = dB_threshold;
				}
				zm *= dB_range_inv;			// scale to range [0,1]
				// zm = core::clamp<f32>( zm, 0.0f, 1.0f );
				_out.push_back( zm );
			}
		}
		*/
	};

} // end namespace core
} // end namespace irr

#endif // BPM6_C_FOURIER_TRANSFORM_REAL_TO_COMPLEX_H_INCLUDED
