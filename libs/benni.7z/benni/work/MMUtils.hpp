// Borland C++ Builder
// Copyright (c) 1995, 1998 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'MMUtils.pas' rev: 3.00

#ifndef MMUtilsHPP
#define MMUtilsHPP
#include <Graphics.hpp>
#include <Dialogs.hpp>
#include <FileCtrl.hpp>
#include <Forms.hpp>
#include <Classes.hpp>
#include <Controls.hpp>
#include <SysUtils.hpp>
#include <Messages.hpp>
#include <Registry.hpp>
#include <Windows.hpp>
#include <SysInit.hpp>
#include <System.hpp>

//-- user supplied -----------------------------------------------------------
#pragma -w-

namespace Mmutils
{
//-- type declarations -------------------------------------------------------
typedef System::Comp Int64;

typedef System::Comp *PInt64;

typedef _LARGE_INTEGER  MMLARGE_INTEGER;

typedef int MM_int64;

typedef int *PLong;

typedef int Long;

typedef Shortint *PShortint;

typedef short *PSmallInt;

typedef Cardinal *PCardinal;

typedef bool *PBoolean;

typedef float *PFloat;

typedef float Float;

typedef float TFloatArray[4097];

typedef TFloatArray *PFloatArray;

typedef double *PDouble;

typedef double TDoubleArray[4097];

typedef TDoubleArray *PDoubleArray;

typedef Windows::TRect TRectArray[4097];

typedef TRectArray *PRectArray;

typedef tagPOINT TPointArray[4097];

typedef TPointArray *PPointArray;

typedef int TLongArray[4097];

typedef TLongArray *PLongArray;

typedef int TIntArray[4097];

typedef TIntArray *PIntArray;

typedef Cardinal TCardinalArray[4097];

typedef TCardinalArray *PCardinalArray;

typedef Word TWordArray[4097];

typedef TWordArray *PWordArray;

typedef short TSmallArray[4097];

typedef TSmallArray *PSmallArray;

typedef Byte TByteArray[4097];

typedef TByteArray *PByteArray;

typedef bool TBooleanArray[4097];

typedef TBooleanArray *PBooleanArray;

typedef int TMMDeviceId;

enum TMMBits { b8Bit, b16Bit };

enum TMMMode { mMono, mStereo, mMultiChannel };

enum TMMChannel { chBoth, chLeft, chRight };

enum TMMSampleRate { sr11025, sr22050, sr44100 };

enum TMMDecayMode { dmNone, dmStepUp, dmExponential, dmUniform };

enum TMMTimeFormats { tfMillisecond, tfByte, tfSample };

typedef Word TMMVolumeRange;

typedef short TMMEffectVolume;

typedef Shortint TMMFeedBack;

enum TMMCBMode { cmWindow, cmCallback, cmThread };

enum TMMFFTWindow { fwRectangular, fwHamming, fwHanning, fwBlackman, fwGaussian, fwWelch, fwParzen }
	;

//-- var, const, procedure ---------------------------------------------------
#define VOLUMEBASE (Word)(16384)
#define clMdGray (Graphics::TColor)(10789024)
#define clCream (Graphics::TColor)(15793151)
#define clMoneyGreen (Graphics::TColor)(12639424)
#define clSkyBlue (Graphics::TColor)(15780518)
#define InvalidId (Shortint)(-2)
#define MapperId (Shortint)(-1)
#define MaxSmallInt (Word)(32767)
extern PACKAGE System::AnsiString InstalledUser;
extern PACKAGE int InitCode;
extern PACKAGE int ErrorCode;
extern PACKAGE int SHandle;
extern PACKAGE int IValue;
extern PACKAGE int DValue;
extern PACKAGE char *SBuf;
extern PACKAGE int MMUTILDLLHandle;
extern PACKAGE System::AnsiString SValue;
extern PACKAGE bool _Win95_;
extern PACKAGE bool _Win98_;
extern PACKAGE bool _WinME_;
extern PACKAGE bool _Win9x_;
extern PACKAGE bool _WinNT3_;
extern PACKAGE bool _WinNT4_;
extern PACKAGE bool _Win2K_;
extern PACKAGE bool _WinXP_;
extern PACKAGE bool _WinNT_;
extern PACKAGE bool _WinNT_NEW_;
extern PACKAGE int _CPU_;
extern PACKAGE bool _MMX_;
extern PACKAGE bool _USECPUEXT_;
#define PENTIUM (Byte)(1)
#define PENTIUMPRO (Byte)(2)
#define PENTIUMPRO2 (Byte)(3)
#define MMAXLONG (int)(2000000000)
#define MM_USER (int)(32768)
#define MM_TIMER (int)(32778)
extern PACKAGE void __fastcall (*SwapSmall)(short &a, short &b);
extern PACKAGE void __fastcall (*SwapInt)(int &a, int &b);
extern PACKAGE void __fastcall (*SwapLong)(int &a, int &b);
extern PACKAGE int __fastcall (*Min)(int a, int b);
extern PACKAGE int __fastcall (*Max)(int a, int b);
extern PACKAGE int __fastcall (*MinMax)(int X, int Min, int Max);
extern PACKAGE int __fastcall (*Limit)(int X, int Min, int Max);
extern PACKAGE bool __fastcall (*InMinMax)(int X, int Min, int Max);
extern PACKAGE bool __fastcall (*InRange)(int X, int Min, int Max);
extern PACKAGE void __fastcall (*incHuge)(void *Pointer, int nBytes);
extern PACKAGE void __fastcall (*GlobalFillMem)(void *X, int Cnt, Byte Value);
extern PACKAGE void __fastcall (*GlobalFillLong)(void *X, int Cnt, int Value);
extern PACKAGE void __fastcall (*GlobalMoveMem)(const void *Source, void *Dest, int Cnt);
extern PACKAGE bool __fastcall (*GlobalCmpMem)(const void *p1, const void *p2, int Cnt);
extern PACKAGE bool __fastcall MMSetThreadPriority(int hThread, int nPriority);
extern PACKAGE bool __fastcall MMSetPriorityClass(int hProcess, int fdwPriority);
extern PACKAGE void __fastcall SaveInRegistry(HKEY _RootKey, System::AnsiString _Localkey, System::AnsiString 
	_Field, const System::Variant &Value);
extern PACKAGE void __fastcall SaveInRegistryBinary(HKEY _RootKey, System::AnsiString _Localkey, System::AnsiString 
	_Field, void *Buffer, int BufSize);
extern PACKAGE System::Variant __fastcall GetFromRegistry(HKEY _RootKey, System::AnsiString _Localkey
	, System::AnsiString _Field, const System::Variant &Value);
extern PACKAGE int __fastcall GetFromRegistryBinary(HKEY _RootKey, System::AnsiString _Localkey, System::AnsiString 
	_Field, void *Buffer, int BufSize);
extern PACKAGE int __fastcall GetCPUUsage(void);
extern PACKAGE System::AnsiString __fastcall GetShortFileName(System::AnsiString Name);
extern PACKAGE int __fastcall GetCPUType(void);
extern PACKAGE System::Comp __fastcall Min64(System::Comp a, System::Comp b);
extern PACKAGE System::Comp __fastcall Max64(System::Comp a, System::Comp b);
extern PACKAGE System::Comp __fastcall MinMax64(System::Comp X, System::Comp Min, System::Comp Max);
	
extern PACKAGE bool __fastcall InMinMax64(System::Comp X, System::Comp Min, System::Comp Max);
extern PACKAGE int __fastcall Sign(int Value);
extern PACKAGE int __fastcall GetCPUFeatures(void);
extern PACKAGE int __fastcall GetCPUMode(void);
extern PACKAGE System::Comp __fastcall GetCPUCycles(void);
extern PACKAGE void __fastcall InitTimeMeasure(void);
extern PACKAGE void __fastcall StartTimeMeasure(void);
extern PACKAGE System::AnsiString __fastcall StopTimeMeasure(int Scale);
extern PACKAGE void __fastcall InitCyclesMeasure(void);
extern PACKAGE void __fastcall StartCyclesMeasure(void);
extern PACKAGE System::AnsiString __fastcall StopCyclesMeasure(int Scale);
extern PACKAGE System::Comp __fastcall TimeGetExactTime(void);
extern PACKAGE bool __fastcall HaveWin95(void);
extern PACKAGE bool __fastcall HaveWin98(void);
extern PACKAGE bool __fastcall HaveWinME(void);
extern PACKAGE bool __fastcall HaveWinNT(void);
extern PACKAGE bool __fastcall HaveWinNT4(void);
extern PACKAGE bool __fastcall HaveWin2K(void);
extern PACKAGE bool __fastcall HaveWinXP(void);
extern PACKAGE void __fastcall Delay(int ms, bool ProcessMessages);
extern PACKAGE tagPOINT __fastcall ClientToClient(Controls::TControl* Destination, Controls::TControl* 
	Source, const tagPOINT &P);
extern PACKAGE int __fastcall NonClientHeight(void);
extern PACKAGE int __fastcall MenuHeight(void);
extern PACKAGE int __fastcall BitsPerPixel(void);
extern PACKAGE System::AnsiString __fastcall CheckPath(System::AnsiString Path, bool Flag);
extern PACKAGE System::AnsiString __fastcall CheckFileName(System::AnsiString S);
extern PACKAGE _LARGE_INTEGER __fastcall int64shl32(System::Comp V, Byte Shift);
extern PACKAGE System::AnsiString __fastcall GetTempFile();
extern PACKAGE bool __fastcall CreateFullDir(System::AnsiString Dir);
extern PACKAGE void __fastcall DeleteDir(System::AnsiString Dir);
extern PACKAGE int __fastcall GetFileSize(System::AnsiString Name);
extern PACKAGE bool __fastcall GetDiskStats(const System::AnsiString Directory, System::Comp &nFree, 
	System::Comp &nSize);
extern PACKAGE bool __fastcall GetDiskFree(const System::AnsiString Directory, int nBytes);
extern PACKAGE void __fastcall ChangeColors(Graphics::TBitmap* Bitmap, bool DrawInactive, Graphics::TColor 
	ForeColor, Graphics::TColor InactiveColor, Graphics::TColor BackColor);
extern PACKAGE void __fastcall GetBitmapSize(HBITMAP Bitmap, int &W, int &H);
extern PACKAGE int __fastcall GetTransparentColorEx(HBITMAP Bitmap, const tagPOINT &Point);
extern PACKAGE int __fastcall GetTransparentColor(HBITMAP Bitmap);
extern PACKAGE void __fastcall DrawTransparentBitmapEx(HDC DC, HBITMAP Bitmap, int X, int Y, const Windows::TRect 
	&Src, int Transparent);
extern PACKAGE void __fastcall DrawTransparentBitmap(HDC DC, HBITMAP Bitmap, int X, int Y, int Transparent
	);
extern PACKAGE void __fastcall TileBlt(HDC DC, HBITMAP Bitmap, const Windows::TRect &aRect, int ROP)
	;
extern PACKAGE void __fastcall FillGradient(HDC DC, Graphics::TColor BeginColor, Graphics::TColor EndColor
	, int nColors, const Windows::TRect &aRect);
extern PACKAGE void __fastcall FillSolid(HDC DC, Graphics::TColor Color, const Windows::TRect &aRect
	);
extern PACKAGE bool __fastcall WinExecAndWaitEx(System::AnsiString FileName, int TimeOut);
extern PACKAGE bool __fastcall WinExecAndWait(System::AnsiString FileName);
extern PACKAGE void __fastcall TimeDecode(int Time, Word &Hour, Word &Min, Word &Sec, Word &MSec);
extern PACKAGE System::AnsiString __fastcall TimeToMask(int Time);
extern PACKAGE int __fastcall MaskToTime(System::AnsiString Mask);
extern PACKAGE System::AnsiString __fastcall CheckFloat(const System::AnsiString S);
extern PACKAGE System::AnsiString __fastcall TimeToString64Ex(System::Comp Time, bool MSec);
extern PACKAGE System::AnsiString __fastcall TimeToString64(Cardinal LowTime, Cardinal HighTime, bool 
	MSec);
extern PACKAGE System::AnsiString __fastcall TimeToStringEx(int Time, bool MSec);
extern PACKAGE System::AnsiString __fastcall TimeToString(int Time);
extern PACKAGE Extended __fastcall StrToFloatEx(System::AnsiString S, char Limiter);
extern PACKAGE float __fastcall DBToLin(float DB);
extern PACKAGE float __fastcall LinToDB(float lin);
extern PACKAGE int __fastcall DBToVolume(float DB, int Base);
extern PACKAGE float __fastcall VolumeToDB(int Volume, int Base);
extern PACKAGE System::AnsiString __fastcall VolumeToStringShort(int Volume, int Base, int Precision
	);
extern PACKAGE System::AnsiString __fastcall VolumeToString(int Volume, int Base, int Precision);
extern PACKAGE System::AnsiString __fastcall PanningToString(int Panning, int Range);
extern PACKAGE void __fastcall CalcVolume(int Base, int Volume, int Panning, int &Left, int &Right);
	
extern PACKAGE int __fastcall CombineVolume(int Vol1, int Vol2, int Base);
extern PACKAGE System::AnsiString __fastcall FormatBigNumber(int dw);
extern PACKAGE System::AnsiString __fastcall BytesToString(System::Comp Bytes);
extern PACKAGE void __fastcall DrawRubberband(System::TObject* Sender, const Windows::TRect &aRect);
	
extern PACKAGE void __fastcall DrawRubberLineEx(System::TObject* Sender, const Windows::TRect &aRect
	, HPEN Pen, int ROP);
extern PACKAGE void __fastcall DrawRubberLine(System::TObject* Sender, const Windows::TRect &aRect);
	
extern PACKAGE void __fastcall TextOutAligned(Graphics::TCanvas* Canvas, int X, int Y, System::AnsiString 
	Text, char * FontName, int FontSize, Byte Align);
extern PACKAGE void * __fastcall GlobalAllocMem(int Size);
extern PACKAGE void __fastcall GlobalReAllocMem(void * &p, int Size);
extern PACKAGE void __fastcall GlobalFreeMem(void * &p);
extern PACKAGE int __fastcall GlobalMemSize(const void * p);
extern PACKAGE bool __fastcall SearchParamStr(System::AnsiString Switch);
extern PACKAGE System::AnsiString __fastcall GetVersionNumber(System::AnsiString FileName);
extern PACKAGE int __fastcall GetWindowsLanguage(void);
extern PACKAGE System::AnsiString __fastcall GetCountryCode();
extern PACKAGE int __fastcall VersionToInt(System::AnsiString sVersion);
extern PACKAGE void __fastcall WinYield(int Wnd);
extern PACKAGE bool __fastcall DesignMode(void);
extern PACKAGE void __fastcall RegisterPackage(const System::AnsiString Pack);
extern PACKAGE void __fastcall RegisterComponent(int Code, Classes::TComponent* Control, System::AnsiString 
	Text);
extern PACKAGE int __fastcall ComponentRegistered(int Code, Classes::TComponent* Control, System::AnsiString 
	Text);
extern PACKAGE int __fastcall PackageRegistered(System::AnsiString Pack);
extern PACKAGE void __fastcall RegisterFailed(int Code, Classes::TComponent* Control, System::AnsiString 
	Text);
extern PACKAGE bool __fastcall FindIDERunning(void);

}	/* namespace Mmutils */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Mmutils;
#endif
//-- end unit ----------------------------------------------------------------
#endif	// MMUtils
