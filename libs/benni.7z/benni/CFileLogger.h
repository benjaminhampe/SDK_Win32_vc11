#ifndef BPM_C_FILE_LOGGER_H
#define BPM_C_FILE_LOGGER_H

#include <cstdlib>
#include <cstdio>
#include <irrArray.h>
#include <irrString.h>

class CFileLogger
{
	irr::core::stringc mFilename;
	FILE* mStream;
	// irr::core::array<irr::core::stringc> mLines;
	irr::core::stringc mData;

public:

	static CFileLogger& getInstance()
	{
		static CFileLogger* p = NULL;
		if (!p)
			p = new CFileLogger();

		return *p;
	}

	CFileLogger( const char* filename = "CFileLogger.log" );

	~CFileLogger();

	// typedef void (*PaUtilLogCallback ) (const char *log);

	void cb_portaudio_logger(const char *log);

	// void PaUtil_SetDebugPrintFunction(PaUtilLogCallback  cb);

	/// Stream all to this
	template <class T> 
	CFileLogger& operator<< ( const T& element )
	{
		mData += element;
		return *this;
	}


};


#endif