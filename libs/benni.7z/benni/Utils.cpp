#include "Utils.h"

#include <bpm6/debugPrint.h>

#ifdef BPM_OS_WINDOWS
#include <windows.h>
#endif

namespace bpm
{
//===============================================================================================
//
// Benni's wxHelper
//
//===============================================================================================
#ifdef BPM_USE_WX_GUI
bool isPointInsideRect( const wxPoint& p, const wxRect& r )
{
	bool result(false);
	if (p.x >= r.GetLeft())
		if (p.x <= r.GetRight())
			if (p.y >= r.GetTop())
				if (p.y <= r.GetBottom())
					result = true;
	return result;
}
#endif

//===============================================================================================
//
// Implementation of class: CRAM
//
//===============================================================================================

bool CRAM::getSystemMemory( u32* Total, u32* Avail )
{
#if defined(_IRR_WINDOWS_API_) && !defined (_IRR_XBOX_PLATFORM_)
	MEMORYSTATUS MemoryStatus;
	MemoryStatus.dwLength = sizeof(MEMORYSTATUS);

	// cannot fail
	GlobalMemoryStatus(&MemoryStatus);

	if (Total)
		*Total = (u32)(MemoryStatus.dwTotalPhys>>10);
	if (Avail)
		*Avail = (u32)(MemoryStatus.dwAvailPhys>>10);

	return true;

#elif defined(_IRR_POSIX_API_) && !defined(__FreeBSD__)
#if defined(_SC_PHYS_PAGES) && defined(_SC_AVPHYS_PAGES)
        long ps = sysconf(_SC_PAGESIZE);
        long pp = sysconf(_SC_PHYS_PAGES);
        long ap = sysconf(_SC_AVPHYS_PAGES);

	if ((ps==-1)||(pp==-1)||(ap==-1))
		return false;

	if (Total)
		*Total = (u32)((ps*(long long)pp)>>10);
	if (Avail)
		*Avail = (u32)((ps*(long long)ap)>>10);
	return true;
#else
	// TODO: implement for non-availablity of symbols/features
	return false;
#endif
#elif defined(_IRR_OSX_PLATFORM_)
	int mib[2];
	int64_t physical_memory;
	size_t length;

	// Get the Physical memory size
	mib[0] = CTL_HW;
	mib[1] = HW_MEMSIZE;
	length = sizeof(int64_t);
	sysctl(mib, 2, &physical_memory, &length, NULL, 0);
	return true;
#else
	// TODO: implement for others
	return false;
#endif
}

u32 CRAM::getTotalMemory()
{
	u32 lTotal, lAvail;
	bool bResult = getSystemMemory( &lTotal, &lAvail );
	return lTotal;
}
		
u32 CRAM::getFreeMemory()
{
	u32 lTotal, lAvail;
	bool bResult = getSystemMemory( &lTotal, &lAvail );
	return lAvail;
}
		
u32 CRAM::getUsedMemory()
{
	u32 lTotal, lAvail;
	bool bResult = getSystemMemory( &lTotal, &lAvail );
	return lTotal-lAvail;
}

//===============================================================================================
//
// Implementation of class: CCPU
//
//===============================================================================================


u32 CCPU::getSpeedMhz()
{
#if defined(_IRR_WINDOWS_API_) && !defined(_WIN32_WCE ) && !defined (_IRR_XBOX_PLATFORM_)
	HKEY Key;
	LONG Error = RegOpenKeyEx(HKEY_LOCAL_MACHINE, __TEXT("HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0"), 0, KEY_READ, &Key);

	if (Error != ERROR_SUCCESS)
		return 0;

	DWORD MHz = 0;
	DWORD Size = sizeof(MHz);
	Error = RegQueryValueEx(Key, __TEXT("~MHz"), NULL, NULL, (LPBYTE)&MHz, &Size);

	RegCloseKey(Key);

	if (Error != ERROR_SUCCESS)
		return 0;
	else
		return MHz;
	
#elif defined(_IRR_OSX_PLATFORM_)
	struct clockinfo CpuClock;
	size_t Size = sizeof(clockinfo);

	if (!sysctlbyname("kern.clockrate", &CpuClock, &Size, NULL, 0))
		return 0;
	else
		return CpuClock.hz;
#else
	u32 MHz = 0;
	// could probably be read from "/proc/cpuinfo" or "/proc/cpufreq"
	FILE* file = fopen("/proc/cpuinfo", "r");
	if (file)
	{
		char buffer[1024];
		fread(buffer, 1, 1024, file);
		buffer[1023]=0;
		core::stringc str(buffer);
		s32 pos = str.find("cpu MHz");
		if (pos != -1)
		{
			pos = str.findNext(':', pos);
			if (pos != -1)
			{
				MHz = core::fast_atof(str.c_str()+pos+1);
			}
		}
		fclose(file);
	}
	return MHz;
#endif
}


s32 CCPU::getUsage()
{
	HKEY TempKey = 0;
	DWORD DataType,BufSize;
	BYTE Result = 0;
	BYTE Dummy = 0;

//	if ( COperatingSystem::isWin9x() ||
//		 COperatingSystem::isWinNT_NEW)
//	{
		// { start measuring }
	LSTATUS status = RegOpenKeyExW(
						HKEY_DYN_DATA, 
						L"PerfStats\\StartStat", 
						NULL, KEY_ALL_ACCESS, 
						&TempKey);

		if ( status != ERROR_SUCCESS)
		{
			return status;
		}

		DataType = REG_NONE;
		BufSize = sizeof(DWORD);
		if ( RegQueryValueExW(TempKey, L"KERNEL\\CPUUsage", NULL, &DataType, &Dummy, &BufSize) != ERROR_SUCCESS )
		{
			return -2;
		}

		RegCloseKey(TempKey);

		// { get the value }
		if ( RegOpenKeyExW(HKEY_DYN_DATA, L"PerfStats\\StatData", NULL, KEY_ALL_ACCESS, &TempKey) != ERROR_SUCCESS )
		{
			return -3;
		}

		RegCloseKey(TempKey);

		DataType = REG_NONE;
		BufSize = sizeof(DWORD);
		if ( RegQueryValueExW(TempKey, L"KERNEL\\CPUUsage", NULL, &DataType, &Result, &BufSize) != ERROR_SUCCESS )
		{
			return -4;
		}

		RegCloseKey(TempKey);

		// { stop measuring }
		if ( RegOpenKeyExW(HKEY_DYN_DATA, L"PerfStats\\StopStat", NULL, KEY_ALL_ACCESS, &TempKey) != ERROR_SUCCESS )
		{
			return -5;
		}

		DataType = REG_NONE;
		BufSize = sizeof(DWORD);
		if ( RegQueryValueExW(TempKey, L"KERNEL\\CPUUsage", NULL, &DataType, &Dummy, &BufSize) != ERROR_SUCCESS )
		{
			return -6;
		}

		RegCloseKey(TempKey);
//	}
//	else
//	{
//		dbERROR( "Unknown System to get CPU-usage from registry\n");
//	}

	return (s32)Result;
}

//
//core::stringc getProcessorType()
//{
//	core::stringc tmp("");
//#if defined( _IRR_WINDOWS_API_) || defined( _MSC_VER)
//	SYSTEM_INFO info;
//	GetSystemInfo(&info);
//    PROCESSOR_ALPHA_21064	 Alpha 210 64 processor.
//    PROCESSOR_AMD_X8664	 AMD X86 64 processor.
//    PROCESSOR_ARCHITECTURE_ALPHA	 Alpha architecture.
//    PROCESSOR_ARCHITECTURE_ALPHA64	 Alpha64 architecture.
//    PROCESSOR_ARCHITECTURE_AMD64	 AMD64 architecture.
//    PROCESSOR_ARCHITECTURE_ARM	 ARM architecture.
//    PROCESSOR_ARCHITECTURE_IA32_ON_WIN64	 IA32 On Win64 architecture.
//    PROCESSOR_ARCHITECTURE_IA64	 IA64 architecture.
//    PROCESSOR_ARCHITECTURE_INTEL	 Intel architecture.
//    PROCESSOR_ARCHITECTURE_MIPS	 MIPS architecture.
//    PROCESSOR_ARCHITECTURE_MSIL	 MSIL architecture.
//    PROCESSOR_ARCHITECTURE_PPC	 PPC architecture.
//    PROCESSOR_ARCHITECTURE_SHX	 SHX architecture.
//    PROCESSOR_ARCHITECTURE_UNKNOWN	 Unknown architecture.
//    PROCESSOR_ARM_7TDMI	 ARM 7TDMI processor.
//    PROCESSOR_ARM720	 ARM 720 processor.
//    PROCESSOR_ARM820	 ARM 820 processor.
//    PROCESSOR_ARM920	 ARM 920 processor.
//    PROCESSOR_HITACHI_SH3	 Hitachi SH3 processor.
//    PROCESSOR_HITACHI_SH3E	 Hitachi SH3E processor.
//    PROCESSOR_HITACHI_SH4	 Hitachi SH4 processor.
//    PROCESSOR_INTEL_386	 Intel i386 processor.
//    PROCESSOR_INTEL_486	 Intel i486 processor.
//    PROCESSOR_INTEL_IA64	 Intel IA64 processor.
//    PROCESSOR_INTEL_PENTIUM	 Intel Pentium processor.
//    PROCESSOR_MIPS_R4000	 MIPS R4000, R4101, R3910 processor.
//    PROCESSOR_MOTOROLA_821	 Motorola 821 processor.
//    PROCESSOR_OPTIL	 MSIL processor.
//    PROCESSOR_PPC_601	 PPC 601 processor.
//    PROCESSOR_PPC_603	 PPC 603 processor.
//    PROCESSOR_PPC_604	 PPC 604 processor.
//    PROCESSOR_PPC_620	 PPC 620 processor.
//    PROCESSOR_SHx_SH3	 SHx SH3 processor.
//    PROCESSOR_SHx_SH4	 SHx SH4 processor.
//    PROCESSOR_STRONGARM
//
//	switch (info.dwProcessorType)
//	{
//		case PROCESSOR_INTEL_386: tmp = "x86"; break;
//		case PROCESSOR_INTEL_486: tmp = "x86"; break;
//		case PROCESSOR_INTEL_PENTIUM: tmp = "x86"; break;
//		case PROCESSOR_AMD64: tmp = "x86_64"; break;
//		case PROCESSOR_AMD_IA64: tmp = "x64"; break;
//		default: tmp="unknown"; break;
//	}
//
//#elif defined( _IRR_POSIX_API_ )
//    #warning getProcessorType() not implemented.
//#else
//    #warning getProcessorType() not implemented.
//#endif
//    return tmp;
//}

//core::stringc getProcessorFlags(u32 i)
//{
//    core::stringc tmp("");
//
//
//PF_3DNOW_INSTRUCTIONS_AVAILABLE	 The 3D-Now instruction set is available.
//PF_ALPHA_BYTE_INSTRUCTIONS	 Unknown.
//PF_COMPARE_EXCHANGE_DOUBLE	 The compare and exchange double operation is available (Pentium, MIPS, and Alpha).
//PF_FLOATING_POINT_EMULATED	 Floating-point operations are emulated using a software emulator.
//PF_FLOATING_POINT_PRECISION_ERRATA	 In rare circumstances, on a Pentium, a floating-point precision error can occur.
//PF_MMX_INSTRUCTIONS_AVAILABLE	 The MMX instruction set is available.
//PF_PAE_ENABLED	 The processor is PAE-enabled.
//PF_PPC_MOVEMEM_64BIT_OK	 Unknown.
//PF_RDTSC_INSTRUCTION_AVAILABLE	 The RDTSC instruction is available.
//PF_XMMI_INSTRUCTIONS_AVAILABLE	 The SSE instruction set is available.
//PF_XMMI64_INSTRUCTIONS_AVAILABLE	 The SSE2 instruction set is available.
//
//    return tmp;
//}

E_CPU_TYPE CCPU::getType()
{
	return ECPU_UNKNOWN;
}




//===============================================================================================
//
// Ronald's functions that use pure x86 assembler ( Intel Syntax like MASM )
// and don't work for all CPUs other than Intel (x86) Architecture
//
//===============================================================================================

/*
{ Current flag assignment is as follows:                          }
{                                                                 }
{		bit23=1     CPU has MMX extension                         }
{		bit15=1     CMOV instruction supported                    }
{		bit9 =1     CPU contains a local APIC (iPentium-3V)       }
{		bit8 =1     CMPXCHG8B instruction supported               }
{		bit7 =1     machine check exception supported             }
{		bit6 =0     reserved (36bit-addressing & 2MB-paging)      }
{		bit5 =1     iPentium-style MSRs supported                 }
{		bit4 =1     time stamp counter TSC supported              }
{		bit3 =1     page size extensions supported                }
{		bit2 =1     I/O breakpoints supported                     }
{		bit1 =1     enhanced virtual 8086 mode supported          }
{		bit0 =1     CPU contains a floating-point unit (FPU)      }
*/

u32 CCPU::getFeatures()
{
	u32 Result = 0;

#ifndef WIN64
	__asm pushad
	__asm pushfd

	// { look if cpuid is supported }
	__asm pushfd			// Get original EFLAGS
	__asm pop    eax
	__asm mov    ecx, eax
	__asm xor    eax, 0x200000	// Flip ID bit in EFLAGS
	__asm push   eax		// Save new EFLAGS value on stack

	__asm popfd			// Replace current EFLAGS value
	__asm pushfd			// Get new EFLAGS
	__asm pop     eax		// Store new EFLAGS in EAX
	__asm xor     eax, ecx		// Can not toggle ID bit,
	__asm jz      exit		// Processor=80486

	__asm mov     eax, 1

	// __asm db      0x0F
	// __asm db      0xa2		// Get family/model/stepping/
        	
	__asm mov     Result, edx //   features

	__asm exit:

	__asm popfd
	__asm popad
#elif defined(BPM_LINUX)
	#warning Function not implemented!
#else
	//#warning Function not implemented!
#endif

	return Result;
}

/*
{=========================================================================}
{ Returns:                                                                }
{  0 = 8086/88,80286,80386,80486                                          }
{  1 = Pentium(R) Processor                                               }
{  2 = PentiumPro(R) Processor                                            }
{  3 or higher = Processor beyond the PentiumPro(R) Processor            }
{                                                                         }
{=========================================================================}
*/

u32 CCPU::getRonaldType()
{
   BYTE stepping = 0;
   BYTE model = 0;
   u32 Result = 0;

#ifndef WIN64
	//__asm		db 0x0F
	//__asm		db 0xa2		// Get family/model/stepping/

   __asm		pushad
   __asm		pushfd

   //   { look if cpuid is supported }
   __asm		pushfd			// Get original EFLAGS
   __asm		pop eax
   __asm		mov ecx, eax
   __asm		xor    eax, 0x200000	// Flip ID bit in EFLAGS
   __asm		push   eax		// Save new EFLAGS value on
   
   //   stack
   __asm		popfd			// Replace current EFLAGS value
   __asm		pushfd			// Get new EFLAGS
   __asm		pop eax		// Store new EFLAGS in EAX
   __asm		xor eax, ecx		// Can not toggle ID bit,
   __asm		jz _exit		// Processor=80486
   __asm		mov eax, 1


   
   //   features
   __asm		mov stepping, al
   __asm		and stepping, 0xF
   __asm		and al, 0xF0
   __asm		shr al, 4
   __asm		mov model, al
   __asm		and eax, 0xF00
   __asm		shr eax, 8		// Isolate family
   __asm		and eax, 0xF
   __asm		sub eax, 4
   __asm		mov Result, eax	// Set _cpu_type with family
   __asm _exit:
   __asm		popfd
   __asm		popad

#endif

	return Result;
}

/*
{=========================================================================}
{ Returns:                                                                }
{  0 = Pentium(R) Processor                                               }
{  1 = PentiumPro(R) Processor                                            }
{  2 = MMX Extension                                                      }
{=========================================================================}
*/

u32 CCPU::getMode()
{
	u32 Result = 0;

	// _USECPUEXT_ then
	if (hasMMX())
	{
		Result = 2;
	}
	else if ( getType() > ECPU_I586 ) // PENTIUM
	{
		Result = 1;
	}
	else
	{
		Result = 0;
	}

	return Result;
}

/*
{=========================================================================}
function GetCPUCycles: int64;
asm
{$IFDEF WIN32}
      db      00fh              //RDTSC
      db      031h
      {$IFNDEF DELPHI4}
      mov     TLargeInteger(Result).HighPart,edx
      mov     TLargeInteger(Result).LowPart,eax
      {$ENDIF}
{$ENDIF}
end;
{=========================================================================}
*/

// return as micro-seconds 10^-6
u64 CCPU::getCycles()
{
	///@todo Quark!!!
	u64 Result = 0;
	u32 Low = 0, High = 0;
#ifdef WIN32
	// __asm db 0x00f              //RDTSC
	// __asm db 0x031
	// __asm mov High,edx
	// __asm mov Low,eax

	// return (High<<32 + Low);
#endif

	return Result;
}

/*
BOOL WINAPI QueryProcessCycleTime(
  _In_   HANDLE ProcessHandle,
  _Out_  PULONG64 CycleTime
);

Windows Vista minimum

Parameters
ProcessHandle [in]

A handle to the process. The handle must have the PROCESS_QUERY_INFORMATION or PROCESS_QUERY_LIMITED_INFORMATION access right. For more information, see Process Security and Access Rights.
CycleTime [out]

The number of CPU clock cycles used by the threads of the process. This value includes cycles spent in both user mode and kernel mode.
Return value

If the function succeeds, the return value is nonzero.

If the function fails, the return value is zero. To get extended error information, call GetLastError.
Remarks

To enumerate the processes in the system, use the EnumProcesses function.

To compile an application that uses this function, define _WIN32_WINNT as 0x0600 or later.

BOOL WINAPI GetProcessTimes(
	  _In_   HANDLE hProcess,
	  _Out_  LPFILETIME lpCreationTime,
	  _Out_  LPFILETIME lpExitTime,
	  _Out_  LPFILETIME lpKernelTime,
	  _Out_  LPFILETIME lpUserTime
	);

Parameters
hProcess [in]

A handle to the process whose timing information is sought. The handle must have the PROCESS_QUERY_INFORMATION or PROCESS_QUERY_LIMITED_INFORMATION access right. For more information, see Process Security and Access Rights.

Windows Server 2003 and Windows XP:  The handle must have the PROCESS_QUERY_INFORMATION access right.
lpCreationTime [out]

A pointer to a FILETIME structure that receives the creation time of the process.
lpExitTime [out]

A pointer to a FILETIME structure that receives the exit time of the process. If the process has not exited, the content of this structure is undefined.
lpKernelTime [out]

A pointer to a FILETIME structure that receives the amount of time that the process has executed in kernel mode. The time that each of the threads of the process has executed in kernel mode is determined, and then all of those times are summed together to obtain this value.
lpUserTime [out]

A pointer to a FILETIME structure that receives the amount of time that the process has executed in user mode. The time that each of the threads of the process has executed in user mode is determined, and then all of those times are summed together to obtain this value. Note that this value can exceed the amount of real time elapsed (between lpCreationTime and lpExitTime) if the process executes across multiple CPU cores.
Return value

If the function succeeds, the return value is nonzero.

If the function fails, the return value is zero. To get extended error information, call GetLastError.
Remarks

All times are expressed using FILETIME data structures. Such a structure contains two 32-bit values that combine to form a 64-bit count of 100-nanosecond time units.

Process creation and exit times are points in time expressed as the amount of time that has elapsed since midnight on January 1, 1601 at Greenwich, England. There are several functions that an application can use to convert such values to more generally useful forms.

Process kernel mode and user mode times are amounts of time. For example, if a process has spent one second in kernel mode, this function will fill the FILETIME structure specified by lpKernelTime with a 64-bit value of ten million. That is the number of 100-nanosecond units in one second.

To retrieve the number of CPU clock cycles used by the threads of the process, use the QueryProcessCycleTime function.
*/
f32 CCPU::getProcessTime()
{

	return 0.0f;

}


bool CCPU::hasCPUID()
{
//	; returns 1 if CPUID is supported, 0 otherwise (ZF is also set accordingly)
//	pushfd ; get
//	pop eax
//	mov ecx, eax ; save
//	xor eax, 0x200000 ; flip
//	push eax ; set
//	popfd
//	pushfd ; and test
//	pop eax
//	xor eax, ecx ; mask changed bits
//	shr eax, 21 ; move bit 21 to bit 0
//	and eax, 1 ; and mask others
//	push ecx
//	popfd ; restore original flags
//	ret
	return true;
}

bool CCPU::CPUID( E_CPUID_REQUEST request, u32& eax, u32& ebx, u32& ecx, u32& edx )
{
	bpm_cpuid(request,eax,ebx,ecx,edx);
	return true;
}

irr::core::stringc CCPU::getVendorString()
{
	if (!hasCPUID())
	{
		// return
		return irr::core::stringc("no cpuid instruction");
	}

    u32 eax(0),ebx(0),ecx(0),edx(0);

	bpm_cpuid( ECR_GETVENDORSTRING, eax, ebx, ecx, edx);

    c8 buf[0x20]; 				// allocate 32 Bytes
    memset(buf, 0x00, 0x20);	// fill with zeros
    memcpy(buf, &ebx, 4);		// copy ebx to string
    memcpy(buf+4, &edx, 4);		// copy edx to string
    memcpy(buf+8, &ecx, 4);		// copy ecx to string

	// copy buffer to string and return
    irr::core::stringc txt("");
    txt += buf;
    return txt;
}

irr::core::stringc CCPU::getNameString()
{
    irr::core::stringc txt("");

    u32 eax(0),ebx(0),ecx(0),edx(0);
    
	bpm_cpuid( ECR_INTELEXTENDED, eax, ebx, ecx, edx);
    
	u32 max8 = eax;

    c8 buf[128];
	memset(buf, 0, 128);

    for (u32 i=0; i<3; ++i)
    {
        if (max8 >= 0x80000002 + i)
        {
			bpm_cpuid( 0x80000002+i, eax, ebx, ecx, edx);
            memcpy(buf+i*16+0, &eax, 4);
            memcpy(buf+i*16+4, &ebx, 4);
            memcpy(buf+i*16+8, &ecx, 4);
            memcpy(buf+i*16+12, &edx, 4);
        }
    }
	txt += buf;

    return txt;
}

irr::core::stringc CCPU::getFlagString()
{
    irr::core::stringc txt("");
    return txt;
}

E_CPU_VENDOR CCPU::getVendor()
{
	irr::core::stringc vendorString = getVendorString();
	return ECV_UNKNOWN;
}

bool CCPU::isVendor( E_CPU_VENDOR vend )
{
	switch ( vend )
	{
		case ECV_UNKNOWN: return false;
		case ECV_INTEL: return false;
		case ECV_AMD: return false;
		case ECV_CYRIX: return false;
		case ECV_VIA: return false;
		case ECV_TRANSMETA: return false;
		case ECV_SIS: return false;
		case ECV_UMC: return false;
		case ECV_ARM: return false;
		default: 
			return false;
	}
	return false;
}

bool CCPU::isVendorIntel()
{
	irr::core::stringc vendorString = getVendorString();
	if (vendorString.equals_ignore_case("GenuineIntel"))
		return true;
	return false;
}

bool CCPU::isVendorAMD()
{
	irr::core::stringc vendorString = getVendorString();
	if (vendorString.equals_ignore_case("AuthenticAMD"))
		return true;
	return false;
}

bool CCPU::isVendorCyrix()
{
	irr::core::stringc vendorString = getVendorString();
	if (vendorString.equals_ignore_case("CyrixInstead"))
		return true;
	return false;
}

bool CCPU::isVendorVIA()
{
	irr::core::stringc vendorString = getVendorString();
	if (vendorString.equals_ignore_case("CentaurHauls"))
		return true;
	return false;
}

bool CCPU::isVendorTransmeta()
{
	irr::core::stringc vendorString = getVendorString();
	if (vendorString.equals_ignore_case("GenuineTMx86"))
		return true;
	return false;
}

bool CCPU::isVendorSIS()
{
	irr::core::stringc vendorString = getVendorString();
	if (vendorString.equals_ignore_case("SiS SiS SiS "))
		return true;
	return false;
}

bool CCPU::isVendorUMC()
{
	irr::core::stringc vendorString = getVendorString();
	if (vendorString.equals_ignore_case("UMC UMC UMC "))
		return true;
	return false;
}

bool CCPU::isVendorARM()
{
	return false;
}

// EDX:0 klassisches FPU-Gleitkomma-Rechenwerk ist vorhanden
// EDX:6 Adresserweiterung PAE wird verarbeitet
// EDX:23 neueres MMX-Multimedia-Rechenwerk ist vorhanden
// EDX:26 modernes SSE2-Gleitkomma/Multimedia -Rechenwerk ist vorhanden
// ECX:7 Speedstep-Erweiterung ist ansprechbar

bool CCPU::hasMMX() 
{
	u32 eax,ebx,ecx,edx;
	
	bpm_cpuid( ECR_GETFEATURES, eax,ebx,ecx,edx );
	
	return (((edx & ECF_MMX) >> 23)==0)?false:true;
}

bool CCPU::hasCMOV()
{
	u32 eax,ebx,ecx,edx;
	
	bpm_cpuid( ECR_GETFEATURES, eax,ebx,ecx,edx );
	
	return (((edx & ECF_CMOV) >> 15)==0)?false:true;
}

bool CCPU::hasCMPXCHG8B()
{
	u32 eax,ebx,ecx,edx;
	
	bpm_cpuid( ECR_GETFEATURES, eax,ebx,ecx,edx );
	
	return (((edx & ECF_CX8) >> 8)==0)?false:true;
}

bool CCPU::hasException()
{
	u32 eax,ebx,ecx,edx;
	
	bpm_cpuid( ECR_GETFEATURES, eax,ebx,ecx,edx );
	
	return (((edx & ECF_MCE) >> 7)==0)?false:true;
}

bool CCPU::hasAddressExt()
{
	u32 eax,ebx,ecx,edx;
	
	bpm_cpuid( ECR_GETFEATURES, eax,ebx,ecx,edx );
	
	return (((edx & ECF_PAE) >> 6)==0)?false:true;
}

bool CCPU::has36BitPageSizeExt()
{
	u32 eax,ebx,ecx,edx;
	
	bpm_cpuid( ECR_GETFEATURES, eax,ebx,ecx,edx );
	
	return (((edx & ECF_PSE36) >> 17)==0)?false:true;
}

bool CCPU::hasTSC()
{
	u32 eax,ebx,ecx,edx;
	
	bpm_cpuid( ECR_GETFEATURES, eax,ebx,ecx,edx );
	
	return (((edx & ECF_TSC) >> 4)==0)?false:true;
}

bool CCPU::hasMSR()
{
	u32 eax,ebx,ecx,edx;
	
	bpm_cpuid( ECR_GETFEATURES, eax,ebx,ecx,edx );
	
	return (((edx & ECF_MSR) >> 5)==0)?false:true;
}

bool CCPU::hasPageSizeExt()
{
	u32 eax,ebx,ecx,edx;
	
	bpm_cpuid( ECR_GETFEATURES, eax,ebx,ecx,edx );
	
	return (((edx & ECF_MSR) >> 5)==0)?false:true;
}

bool CCPU::hasHWBreakPoints()
{
	u32 eax,ebx,ecx,edx;
	
	bpm_cpuid( ECR_GETFEATURES, eax,ebx,ecx,edx );
	
	return (((edx & ECF_DE) >> 2)==0)?false:true;
}

bool CCPU::hasVirt8086()
{
	u32 eax,ebx,ecx,edx;
	
	bpm_cpuid( ECR_GETFEATURES, eax,ebx,ecx,edx );
	
	return (((edx & ECF_VME) >> 1)==0)?false:true;
}

bool CCPU::hasFPU()
{
	u32 eax,ebx,ecx,edx;
	
	bpm_cpuid( ECR_GETFEATURES, eax,ebx,ecx,edx );
	
	return ((edx & ECF_FPU)==0)?false:true;
}

u32 CCPU::getNanometers()
{
	return 0;
}
u32 CCPU::getTransistors()
{
	return 0;
}

u32 CCPU::getMaxTDP()
{
	return 0;
}

//u32 getProcessorCount()

u32 CCPU::getCoreCount()
{
    u32 nCPU = 0;
#if defined( _IRR_WINDOWS_API_) || defined( _MSC_VER)
	SYSTEM_INFO info;
	GetSystemInfo(&info);
	nCPU = (u32)info.dwNumberOfProcessors;
#elif defined( _IRR_POSIX_API_ )
    #warning getProcessorCount() not implemented.
#else
    #warning getProcessorCount() not implemented.
#endif
	return nCPU;
}

//u32 getProcessorCount()

u32 CCPU::getThreadCount()
{
    u32 nCPU = 0;
#if defined( _IRR_WINDOWS_API_) || defined( _MSC_VER)
	SYSTEM_INFO info;
	GetSystemInfo(&info);
	nCPU = (u32)info.dwNumberOfProcessors;
#elif defined( _IRR_POSIX_API_ )
    #warning getProcessorCount() not implemented.
#else
    #warning getProcessorCount() not implemented.
#endif
	return nCPU;
}

u32 CCPU::getCacheSize()
{
	return 0;
}

u32 CCPU::getCacheSizeL1()
{
	return 0;
}

u32 CCPU::getCacheSizeL2()
{
	return 0;
}

u32 CCPU::getCacheSizeL3()
{
	return 0;
}

irr::core::stringc CCPU::dumpRegister()
{
    irr::core::stringc txt("__________________________________________________________________________________________________\n");

    u32 eax(0),ebx(0),ecx(0),edx(0);
    bpm_cpuid( 0x00000000, eax, ebx, ecx, edx);	// actual magic 1
    u32 max0 = eax;
    bpm_cpuid( 0x80000000, eax, ebx, ecx, edx);	// actual magic 2
    u32 max8 = eax - 0x80000000;

//    txt+="max0 = "; txt+=max0; txt+="\n";
//    txt+="max8 = "; txt+=max8; txt+="\n";

    const u32 n = 256;
    char buf[n];

    for (u32 i = 0; i <= max0; i++)
    {
        memset(buf, 0, n);
        bpm_cpuid( i, eax, ebx, ecx, edx);
        snprintf(buf, n, "CPUID %08x | EAX=0x%08x, EBX=0x%08x, ECX=0x%08x, EDX=0x%08x", i, eax, ebx, ecx, edx);
        txt+=buf;
        txt+=" | ";
        //! write EAX as 4 chars (replace non printable chars with '_')
        for (u32 j=0; j<4; j++)
		{
			c8 ch = ((c8*)&eax)[j];
			if (ch>=32)
				txt+=ch;
			else
				txt+='_';
		}
		//! write EBX as 4 chars (replace non printable chars with '_')
        for (u32 j=0; j<4; j++)
		{
			c8 ch = ((c8*)&ebx)[j];
			if (ch>=32)
				txt+=ch;
			else
				txt+='_';
		}
		//! write ECX as 4 chars (replace non printable chars with '_')
        for (u32 j=0; j<4; j++)
		{
			c8 ch = ((c8*)&ecx)[j];
			if (ch>=32)
				txt+=ch;
			else
				txt+='_';
		}
		//! write EDX as 4 chars (replace non printable chars with '_')
        for (u32 j=0; j<4; j++)
		{
			c8 ch = ((c8*)&edx)[j];
			if (ch>=32)
				txt+=ch;
			else
				txt+='_';
		}
        txt+="\n";
    }

    for (u32 i = 0; i <= max8; i++)
    {
        memset(buf, 0, n);
        bpm_cpuid( 0x80000000+i, eax, ebx, ecx, edx);
        snprintf(buf, n, "CPUID %08x | EAX=0x%08x, EBX=0x%08x, ECX=0x%08x, EDX=0x%08x", 0x80000000+i, eax, ebx, ecx, edx);
        txt+=buf;
        txt+=" | ";
        //! write EAX as 4 chars (replace non printable chars with '_')
        for (u32 j=0; j<4; j++)
		{
			c8 ch = ((c8*)&eax)[j];
			if (ch>=32)
				txt+=ch;
			else
				txt+='_';
		}
		//! write EBX as 4 chars (replace non printable chars with '_')
        for (u32 j=0; j<4; j++)
		{
			c8 ch = ((c8*)&ebx)[j];
			if (ch>=32)
				txt+=ch;
			else
				txt+='_';
		}
		//! write ECX as 4 chars (replace non printable chars with '_')
        for (u32 j=0; j<4; j++)
		{
			c8 ch = ((c8*)&ecx)[j];
			if (ch>=32)
				txt+=ch;
			else
				txt+='_';
		}
		//! write EDX as 4 chars (replace non printable chars with '_')
        for (u32 j=0; j<4; j++)
		{
			c8 ch = ((c8*)&edx)[j];
			if (ch>=32)
				txt+=ch;
			else
				txt+='_';
		}
        txt+="\n";
    }
//    txt+="__________________________________________________________________________________________________\n";
    return txt;
}

irr::core::stringc CCPU::dump()
{
    irr::core::stringc txt = dumpRegister();
	txt+="\n";

    u32 nSteppingID = 0;
    u32 nModel = 0;
    u32 nFamily = 0;
    u32 nProcessorType = 0;
    u32 nExtendedModel = 0;
    u32 nExtendedFamily = 0;
    u32 nBrandIndex = 0;
    u32 nCLFlushCacheLineSize = 0;
    u32 nAPICPhysicalID = 0;
    u32 nFeatureInfo = 0;
    u32 nCacheLineSize = 0;
    u32 nL2Associativity = 0;
    u32 nCacheSizeK = 0;
    bool bSSE3Instructions = false;
    bool bMonitorMWait = false;
    bool bCPLQualifiedDebugStore = false;
    bool bThermalMonitor2 = false;
    u32 max0(0), max8(0);
    u32 eax(0),ebx(0),ecx(0),edx(0);
    bpm_cpuid( 0x00000000, eax, ebx, ecx, edx);
    max0 = eax;
    bpm_cpuid( 0x80000000, eax, ebx, ecx, edx);
    max8 = eax;
//    txt+="max0 = "; txt+=(u32)max0; txt+="\n";
//    txt+="max8 = "; txt+=(u32)(max8-0x80000000); txt+="\n";

    if (max0>=1) // get infos from call 0x00000001
    {
        bpm_cpuid( 0x00000001, eax, ebx, ecx, edx);
        nSteppingID = eax & 0xf;
        nModel = (eax >> 4) & 0xf;
        nFamily = (eax >> 8) & 0xf;
        nProcessorType = (eax >> 12) & 0x3;
        nExtendedModel = (eax >> 16) & 0xf;
        nExtendedFamily = (eax >> 20) & 0xff;
        nBrandIndex = ebx & 0xff;
        nCLFlushCacheLineSize = ((ebx >> 8) & 0xff) * 8;
        nAPICPhysicalID = (ebx >> 24) & 0xff;
        bSSE3Instructions = (ecx & 0x1) || false;
        bMonitorMWait = (ecx & 0x8) || false;
        bCPLQualifiedDebugStore = (ecx & 0x10) || false;
        bThermalMonitor2 = (ecx & 0x100) || false;
        nFeatureInfo = edx;
    }

    if (max8 >= 0x80000006) // get extended intel infos
    {
        bpm_cpuid( 0x80000006, eax, ebx, ecx, edx);
        nCacheLineSize = ecx & 0xff;
        nL2Associativity = (ecx >> 12) & 0xf;
        nCacheSizeK = (ecx >> 16) & 0xffff;
    }

    txt+="Vendor : \t\t\t\t\t"; txt+=getVendorString(); txt+="\n";
    txt+="Brand : \t\t\t\t\t"; txt+=getNameString(); txt+="\n";
    txt+="Cache Line Size : \t\t\t"; txt+=nCacheLineSize; txt+="\n";
    txt+="L2 Associativity : \t\t\t"; txt+=nL2Associativity; txt+="\n";
    txt+="Cache Size : \t\t\t\t"; txt+=nCacheSizeK; txt+=" KiB\n";
    txt+="SteppingID : \t\t\t\t"; txt+=nSteppingID; txt+="\n";
    txt+="Model : \t\t\t\t\t"; txt+=nModel; txt+="\n";
    txt+="Family : \t\t\t\t\t"; txt+=nFamily; txt+="\n";
    txt+="Processor Type : \t\t\t\t"; txt+=nProcessorType; txt+="\n";
    txt+="Extended model : \t\t\t\t"; txt+=nExtendedModel; txt+="\n";
    txt+="Extended family : \t\t\t"; txt+=nExtendedFamily; txt+="\n";
    txt+="Brand Index : \t\t\t\t"; txt+=nBrandIndex; txt+="\n";
    txt+="CLFLUSH cache line size : \t\t"; txt+=nCLFlushCacheLineSize; txt+="\n";
    txt+="APIC Physical ID : \t\t\t"; txt+=nAPICPhysicalID; txt+="\n";
    txt+="MONITOR/MWAIT : \t\t\t\t"; txt+=(bMonitorMWait)?"YES":"NO"; txt+="\n";
    txt+="bSSE3Instructions : \t\t\t"; txt+=(bSSE3Instructions)?"YES":"NO"; txt+="\n";
    txt+="bCPLQualifiedDebugStore : \t\t"; txt+=(bCPLQualifiedDebugStore)?"YES":"NO"; txt+="\n";
    txt+="bThermalMonitor2 : \t\t\t"; txt+=(bThermalMonitor2)?"YES":"NO"; txt+="\n";
    txt+="nFeatureInfo : \t\t\t\t"; txt+=nFeatureInfo; txt+="\n";
    if  (nFeatureInfo)
	{
        u32 c(0);
        u32 k(1);
		u32 n = sizeof(CPUID_IntelFeatureStringsEDX)/sizeof(const char*);

		u32 max_tabs(0);
		for (u32 i=0; i<n; i++)
		{
			u32 szlen = strlen(CPUID_IntelFeatureStringsEDX[i])+1; //( +1 for ':')
			szlen>>=3; // len/(chars per tab)
			if (max_tabs < szlen)
				max_tabs = szlen;
		}

		max_tabs++; // just for making things sure

		for (u32 i=0; i<n; i++)
		{
			txt+=CPUID_IntelFeatureStringsEDX[i];
			txt+=":";
			u32 szlen = strlen(CPUID_IntelFeatureStringsEDX[i])+1; //( +1 for ':')
			u32 tabs = max_tabs-(szlen>>3);
			for (u32 t=0; t<tabs; t++)
				txt+="\t";

			if  (nFeatureInfo & k)
			{
				c++;
				txt+="YES";
			}
			else
			{
				txt+="NO";
			}

			k<<=1;
			txt+="\n";
		}

        txt+="CPU has "; txt+=c; txt+=" out of "; txt+=n; txt+=" features.\n";
    }

    return txt;
}



// {=========================================================================}
// {=========================================================================}
// {=========================================================================}

// Implementation for class COperatingSystem

// {=========================================================================}
// {=========================================================================}
// {=========================================================================}

bool COperatingSystem::is64Bit()
{
	bool Result = false;

#if defined(BPM_OS_WINDOWS)

    BOOL bIsWow64 = FALSE;

    //IsWow64Process is not available on all supported versions of Windows.
    //Use GetModuleHandle to get a handle to the DLL that contains the function
    //and GetProcAddress to get a pointer to the function if available.

    LPFN_ISWOW64PROCESS fnIsWow64Process = (LPFN_ISWOW64PROCESS) GetProcAddress( GetModuleHandle(TEXT("kernel32")),"IsWow64Process");

    if( NULL != fnIsWow64Process )
    {
        if (!fnIsWow64Process(GetCurrentProcess(),&bIsWow64))
        {
            //handle error
			dbERROR("COperatingSystem::is64Bit() : Cannot load IsWow64Process, maybe it does not exist on this system.");
        }
    }
    
	Result = (bIsWow64 == TRUE) ? true : false;

#else
	#warning not implemented
#endif

	return Result;
}

E_OS_TYPE COperatingSystem::getType()
{
	return EOS_UNKNOWN;
}
		
typedef BOOL (WINAPI *PGPI)(DWORD, DWORD, DWORD, DWORD, PDWORD);
// Needed for old windows apis
// depending on the SDK version and compilers some defines might be available
// or not
#ifndef PRODUCT_ULTIMATE
#define PRODUCT_ULTIMATE	0x00000001
#define PRODUCT_HOME_BASIC	0x00000002
#define PRODUCT_HOME_PREMIUM	0x00000003
#define PRODUCT_ENTERPRISE	0x00000004
#define PRODUCT_HOME_BASIC_N	0x00000005
#define PRODUCT_BUSINESS	0x00000006
#define PRODUCT_STARTER		0x0000000B
#endif
#ifndef PRODUCT_ULTIMATE_N
#define PRODUCT_BUSINESS_N	0x00000010
#define PRODUCT_HOME_PREMIUM_N	0x0000001A
#define PRODUCT_ENTERPRISE_N	0x0000001B
#define PRODUCT_ULTIMATE_N	0x0000001C
#endif
#ifndef PRODUCT_STARTER_N
#define PRODUCT_STARTER_N	0x0000002F
#endif
#ifndef PRODUCT_PROFESSIONAL
#define PRODUCT_PROFESSIONAL	0x00000030
#define PRODUCT_PROFESSIONAL_N	0x00000031
#endif
#ifndef PRODUCT_ULTIMATE_E
#define PRODUCT_STARTER_E	0x00000042
#define PRODUCT_HOME_BASIC_E	0x00000043
#define PRODUCT_HOME_PREMIUM_E	0x00000044
#define PRODUCT_PROFESSIONAL_E	0x00000045
#define PRODUCT_ENTERPRISE_E	0x00000046
#define PRODUCT_ULTIMATE_E	0x00000047
#endif

irr::core::stringc COperatingSystem::getName()
{
	irr::core::stringc out("");
	OSVERSIONINFOEX osvi;
	PGPI pGPI;
	BOOL bOsVersionInfoEx;

	ZeroMemory(&osvi, sizeof(OSVERSIONINFOEX));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);

	bOsVersionInfoEx = GetVersionEx((OSVERSIONINFO*) &osvi);
	if (!bOsVersionInfoEx)
	{
		osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
		if (! GetVersionEx((OSVERSIONINFO *) &osvi))
			return out;
	}

	switch (osvi.dwPlatformId)
	{
	case VER_PLATFORM_WIN32_NT:
		if (osvi.dwMajorVersion <= 4)
			out.append("Microsoft Windows NT ");
		else
		if (osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 0)
			out.append("Microsoft Windows 2000 ");
		else
		if (osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 1)
			out.append("Microsoft Windows XP ");
		else
		if (osvi.dwMajorVersion == 6 )
		{
			if (osvi.dwMinorVersion == 0)
			{
				if (osvi.wProductType == VER_NT_WORKSTATION)
					out.append("Microsoft Windows Vista ");
				else
					out.append("Microsoft Windows Server 2008 ");
			}
			else if (osvi.dwMinorVersion == 1)
			{
				if (osvi.wProductType == VER_NT_WORKSTATION)
					out.append("Microsoft Windows 7 ");
				else
					out.append("Microsoft Windows Server 2008 R2 ");
			}
		}

		if (bOsVersionInfoEx)
		{
			if (osvi.dwMajorVersion == 6)
			{
				DWORD dwType;
				pGPI = (PGPI)GetProcAddress(GetModuleHandle(TEXT("kernel32.dll")), "GetProductInfo");
				pGPI(osvi.dwMajorVersion, osvi.dwMinorVersion, 0, 0, &dwType);

				switch (dwType)
				{
				case PRODUCT_ULTIMATE:
				case PRODUCT_ULTIMATE_E:
				case PRODUCT_ULTIMATE_N:
					out.append("Ultimate Edition ");
					break;
				case PRODUCT_PROFESSIONAL:
				case PRODUCT_PROFESSIONAL_E:
				case PRODUCT_PROFESSIONAL_N:
					out.append("Professional Edition ");
					break;
				case PRODUCT_HOME_BASIC:
				case PRODUCT_HOME_BASIC_E:
				case PRODUCT_HOME_BASIC_N:
					out.append("Home Basic Edition ");
					break;
				case PRODUCT_HOME_PREMIUM:
				case PRODUCT_HOME_PREMIUM_E:
				case PRODUCT_HOME_PREMIUM_N:
					out.append("Home Premium Edition ");
					break;
				case PRODUCT_ENTERPRISE:
				case PRODUCT_ENTERPRISE_E:
				case PRODUCT_ENTERPRISE_N:
					out.append("Enterprise Edition ");
					break;
				case PRODUCT_BUSINESS:
				case PRODUCT_BUSINESS_N:
					out.append("Business Edition ");
					break;
				case PRODUCT_STARTER:
				case PRODUCT_STARTER_E:
				case PRODUCT_STARTER_N:
					out.append("Starter Edition ");
					break;
				}
			}
#ifdef VER_SUITE_ENTERPRISE
			else
			if (osvi.wProductType == VER_NT_WORKSTATION)
			{
#ifndef __BORLANDC__
				if( osvi.wSuiteMask & VER_SUITE_PERSONAL )
					out.append("Personal ");
				else
					out.append("Professional ");
#endif
			}
			else if (osvi.wProductType == VER_NT_SERVER)
			{
				if( osvi.wSuiteMask & VER_SUITE_DATACENTER )
					out.append("DataCenter Server ");
				else if( osvi.wSuiteMask & VER_SUITE_ENTERPRISE )
					out.append("Advanced Server ");
				else
					out.append("Server ");
			}
#endif
		}
		else
		{
			HKEY hKey;
			char szProductType[80];
			DWORD dwBufLen;

			RegOpenKeyEx( HKEY_LOCAL_MACHINE,
					__TEXT("SYSTEM\\CurrentControlSet\\Control\\ProductOptions"),
					0, KEY_QUERY_VALUE, &hKey );
			RegQueryValueEx( hKey, __TEXT("ProductType"), NULL, NULL,
					(LPBYTE) szProductType, &dwBufLen);
			RegCloseKey( hKey );

			if (_strcmpi( "WINNT", szProductType) == 0 )
				out.append("Professional ");
			if (_strcmpi( "LANMANNT", szProductType) == 0)
				out.append("Server ");
			if (_strcmpi( "SERVERNT", szProductType) == 0)
				out.append("Advanced Server ");
		}

		// Display version, service pack (if any), and build number.

		char tmp[255];

		if (osvi.dwMajorVersion <= 4 )
		{
			sprintf(tmp, "version %ld.%ld %s (Build %ld)",
					osvi.dwMajorVersion,
					osvi.dwMinorVersion,
					irr::core::stringc(osvi.szCSDVersion).c_str(),
					osvi.dwBuildNumber & 0xFFFF);
		}
		else
		{
			sprintf(tmp, "%s (Build %ld)", irr::core::stringc(osvi.szCSDVersion).c_str(),
			osvi.dwBuildNumber & 0xFFFF);
		}

		out.append(tmp);
		break;

	case VER_PLATFORM_WIN32_WINDOWS:

		if (osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 0)
		{
			out.append("Microsoft Windows 95 ");
			if ( osvi.szCSDVersion[1] == 'C' || osvi.szCSDVersion[1] == 'B' )
				out.append("OSR2 " );
		}

		if (osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 10)
		{
			out.append("Microsoft Windows 98 ");
			if ( osvi.szCSDVersion[1] == 'A' )
				out.append( "SE " );
		}

		if (osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 90)
			out.append("Microsoft Windows Me ");

		break;

	case VER_PLATFORM_WIN32s:
		out.append("Microsoft Win32s ");
		break;
	}

	return out;
}
		
irr::core::stringc COperatingSystem::getVendor()
{
#if defined(BPM_OS_WINDOWS)
	return "Microsoft";
#elif defined(BPM_OS_MACOSX)
	return "Apple";
#elif defined(BPM_OS_SOLARIS)
	return "Sun Microsystems";
#elif defined(BPM_OS_LINUX)
	return "GNU/Linux";
#else
	return "Unknown";
#endif
}

/**
{=========================================================================}
function HaveWin95: Boolean;
{$IFDEF WIN32}
var
   OS: TOSVERSIONINFO;
begin
   OS.dwOSVersionInfoSize := sizeOf(OS);
   GetVersionEx(OS);
   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_WINDOWS) and
             (OS.dwMajorVersion = 4) and (OS.dwMinorVersion = 0);
{$ELSE}
begin
   Result:=(GetVersion and $FF = 3)and((GetVersion shr 8)and $FF=95);
{$ENDIF}
end;
{=========================================================================}
*/
bool COperatingSystem::isWin95()
{
	bool Result = false;

#ifdef WIN32
	OSVERSIONINFOW os;
	os.dwOSVersionInfoSize = sizeof(OSVERSIONINFOW);
	GetVersionExW( &os );
	Result = (os.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS) && (os.dwMajorVersion == 4) && (os.dwMinorVersion == 0);
#else

    DWORD dwVersion = 0; 
    DWORD dwMajorVersion = 0;
    DWORD dwMinorVersion = 0; 
    DWORD dwBuild = 0;

    dwVersion = GetVersion();
 
    // Get the Windows version.

    dwMajorVersion = (DWORD)(LOBYTE(LOWORD(dwVersion)));
    dwMinorVersion = (DWORD)(HIBYTE(LOWORD(dwVersion)));

	Result = ((dwMajorVersion == 3) && (dwMinorVersion == 95 ));
#endif

	return Result;
}

/**
{=========================================================================}
function HaveWin98: Boolean;
{$IFDEF WIN32}
var
   OS: TOSVERSIONINFO;
begin
   OS.dwOSVersionInfoSize := sizeOf(OS);
   GetVersionEx(OS);
   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_WINDOWS) and
             (OS.dwMajorVersion = 4) and (OS.dwMinorVersion = 10);
{$ELSE}
begin
   Result:=(GetVersion and $FF = 3)and((GetVersion shr 8)and $FF=95);
{$ENDIF}
end;
{=========================================================================}
*/
bool COperatingSystem::isWin98()
{
	bool Result = false;

#ifdef WIN32
	OSVERSIONINFOW os;
	os.dwOSVersionInfoSize = sizeof(OSVERSIONINFOW);
	GetVersionExW(&os);
	Result = (os.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS) && (os.dwMajorVersion == 4) && (os.dwMinorVersion == 10);
#else

    DWORD dwVersion = 0; 
    DWORD dwMajorVersion = 0;
    DWORD dwMinorVersion = 0; 
    DWORD dwBuild = 0;

    dwVersion = GetVersion();
 
    // Get the Windows version.

    dwMajorVersion = (DWORD)(LOBYTE(LOWORD(dwVersion)));
    dwMinorVersion = (DWORD)(HIBYTE(LOWORD(dwVersion)));

	Result = ((dwMajorVersion == 3) && (dwMinorVersion == 95 ));
#endif

	return Result;
}

/**
{=========================================================================}
function HaveWinME: Boolean;
{$IFDEF WIN32}
var
   OS: TOSVERSIONINFO;
begin
   OS.dwOSVersionInfoSize := sizeOf(OS);
   GetVersionEx(OS);
   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_WINDOWS) and
             (OS.dwMajorVersion = 4) and (OS.dwMinorVersion >= 90);
{$ELSE}
begin
   Result:=(GetVersion and $FF = 3)and((GetVersion shr 8)and $FF=95);
{$ENDIF}
end;
{=========================================================================}
*/

bool COperatingSystem::isWinME()
{
	bool Result = false;

#ifdef WIN32
	OSVERSIONINFOW os;
	os.dwOSVersionInfoSize = sizeof(OSVERSIONINFOW);
	GetVersionExW(&os);
	Result = (os.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS) && (os.dwMajorVersion == 4) && (os.dwMinorVersion == 90);
#else

    DWORD dwVersion = 0; 
    DWORD dwMajorVersion = 0;
    DWORD dwMinorVersion = 0; 
    DWORD dwBuild = 0;

    dwVersion = GetVersion();
 
    // Get the Windows version.

    dwMajorVersion = (DWORD)(LOBYTE(LOWORD(dwVersion)));
    dwMinorVersion = (DWORD)(HIBYTE(LOWORD(dwVersion)));

	Result = ((dwMajorVersion == 3) && (dwMinorVersion == 95 ));
#endif

	return Result;
}

/**
{=========================================================================}
function HaveWinNT: Boolean;
{$IFDEF WIN32}
var
   OS: TOSVERSIONINFO;
begin
   OS.dwOSVersionInfoSize := sizeOf(OS);
   GetVersionEx(OS);
   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_NT) and
             (OS.dwMajorVersion = 3);
{$ELSE}
begin
   Result := (GetWinFlags and $4000) <> 0;
{$ENDIF}
end;
{=========================================================================}
*/
bool COperatingSystem::isWinNT()
{
	bool Result = false;

#ifdef WIN32
	OSVERSIONINFOW os;
	os.dwOSVersionInfoSize = sizeof(OSVERSIONINFOW);
	GetVersionExW(&os);
	Result = (os.dwPlatformId == VER_PLATFORM_WIN32_NT) && (os.dwMajorVersion == 3);
#else
	#warning No implementation found!
#endif

	return Result;
}

/**
{=========================================================================}
function HaveWinNT4: Boolean;
{$IFDEF WIN32}
var
   OS: TOSVERSIONINFO;
begin
   OS.dwOSVersionInfoSize := sizeOf(OS);
   GetVersionEx(OS);
   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_NT) and
             (OS.dwMajorVersion = 4);
{$ELSE}
begin
   Result := (GetWinFlags and $4000) <> 0;
{$ENDIF}
end;
{=========================================================================}
*/
bool COperatingSystem::isWinNT4()
{
	bool Result = false;

#ifdef WIN32
	OSVERSIONINFOW os;
	os.dwOSVersionInfoSize = sizeof(OSVERSIONINFOW);
	GetVersionExW(&os);
	Result = (os.dwPlatformId == VER_PLATFORM_WIN32_NT) && (os.dwMajorVersion == 4);
#else
	#warning No implementation found!
#endif

	return Result;
}

/**
{=========================================================================}
function HaveWin2K: Boolean;
{$IFDEF WIN32}
var
   OS: TOSVERSIONINFO;
begin
   OS.dwOSVersionInfoSize := sizeOf(OS);
   GetVersionEx(OS);
   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_NT) and
             (OS.dwMajorVersion = 5) and (OS.dwMinorVersion = 0);
{$ELSE}
begin
   Result := (GetWinFlags and $4000) <> 0;
{$ENDIF}
end;
{=========================================================================}
*/
bool COperatingSystem::isWin2K()
{
	bool Result = false;

#ifdef WIN32
	OSVERSIONINFOW os;
	os.dwOSVersionInfoSize = sizeof(OSVERSIONINFOW);
	GetVersionExW(&os);
	Result = (os.dwPlatformId == VER_PLATFORM_WIN32_NT) && (os.dwMajorVersion == 5) && (os.dwMinorVersion == 0);
#else
	#warning No implementation found!
#endif

	return Result;
}

/**
{=========================================================================}
function HaveWin2K3: Boolean;
{$IFDEF WIN32}
var
   OS: TOSVERSIONINFO;
begin
   OS.dwOSVersionInfoSize := sizeOf(OS);
   GetVersionEx(OS);
   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_NT) and
             (OS.dwMajorVersion = 5) and (OS.dwMinorVersion >= 2);
{$ELSE}
begin
   Result := (GetWinFlags and $4000) <> 0;
{$ENDIF}
end;
{=========================================================================}
*/
bool COperatingSystem::isWin2K3()
{
	bool Result = false;

#ifdef WIN32
	OSVERSIONINFOW os;
	os.dwOSVersionInfoSize = sizeof(OSVERSIONINFOW);
	GetVersionExW(&os);
	Result = (os.dwPlatformId == VER_PLATFORM_WIN32_NT) && (os.dwMajorVersion == 5) && (os.dwMinorVersion >= 2);
#else
	#warning No implementation found!
#endif

	return Result;
}

/**
{=========================================================================}
function HaveWinXP: Boolean;
{$IFDEF WIN32}
var
   OS: TOSVERSIONINFO;
begin
   OS.dwOSVersionInfoSize := sizeOf(OS);
   GetVersionEx(OS);
   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_NT) and
             (OS.dwMajorVersion = 5) and (OS.dwMinorVersion = 1);
{$ELSE}
begin
   Result := (GetWinFlags and $4000) <> 0;
{$ENDIF}
end;
{=========================================================================}
*/
bool COperatingSystem::isWinXP()
{
	bool Result = false;

#ifdef WIN32
	OSVERSIONINFOW os;
	os.dwOSVersionInfoSize = sizeof(OSVERSIONINFOW);
	GetVersionExW(&os);
	Result = (os.dwPlatformId == VER_PLATFORM_WIN32_NT) && (os.dwMajorVersion == 5) && (os.dwMinorVersion == 1);
#else
	#warning No implementation found!
#endif

	return Result;
}

/**
{=========================================================================}
function HaveWinVista: Boolean;
{$IFDEF WIN32}
var
   OS: TOSVERSIONINFO;
begin
   OS.dwOSVersionInfoSize := sizeOf(OS);
   GetVersionEx(OS);
   Result := ((OS.dwPlatformID = VER_PLATFORM_WIN32_NT) and
             (OS.dwMajorVersion >= 6)) or
             // detect Vista even in compatiblity mode
             assigned(GetProcAddress(GetModuleHandle('kernel32.dll'),'GetProductInfo'));
{$ELSE}
begin
   Result := (GetWinFlags and $4000) <> 0;
{$ENDIF}
end;
{=========================================================================}
*/

#define assigned(x) (x)

bool COperatingSystem::isWinVista()
{
	bool Result = false;

#ifdef WIN32
	OSVERSIONINFOW os;
	os.dwOSVersionInfoSize = sizeof(OSVERSIONINFOW);
	GetVersionExW(&os);
	Result = ((os.dwPlatformId == VER_PLATFORM_WIN32_NT) && (os.dwMajorVersion >= 6)) ||
    // detect Vista even in compatiblity mode
	    assigned( GetProcAddress( GetModuleHandleW( L"kernel32.dll"), "GetProductInfo") );
#else
	#warning No implementation found!
#endif

	return Result;
}

/**
{=========================================================================}
function HaveAfterWinVista: Boolean;
{$IFDEF WIN32}
var
   OS: TOSVERSIONINFO;
begin
   OS.dwOSVersionInfoSize := sizeOf(OS);
   GetVersionEx(OS);
   Result := ((OS.dwPlatformID = VER_PLATFORM_WIN32_NT) and
             (OS.dwMajorVersion > 6));
{$ELSE}
begin
   Result := (GetWinFlags and $4000) <> 0;
{$ENDIF}
end;
{=========================================================================}
*/
bool COperatingSystem::isWin7()
{
	bool Result = false;
	return Result;
}



/*
{=========================================================================}
// got it from: http://community.borland.com/article/0,1410,26752,00.html
function IsAdministrator(NeedFullVistaRights: Boolean): Boolean;
const
  SECURITY_NT_AUTHORITY: TSIDIdentifierAuthority = (Value: (0, 0, 0, 0, 0, 5));
  SECURITY_BUILTIN_DOMAIN_RID = $00000020;
  DOMAIN_ALIAS_RID_ADMINS     = $00000220;

var
  hAccessToken: THandle;
  ptgGroups: PTokenGroups;
  dwInfoBufferSize: DWORD;
  psidAdministrators: PSID;
  x: Integer;
  bSuccess: BOOL;
  hService: THandle;
begin
   Result := False;

   bSuccess := OpenThreadToken(GetCurrentThread, TOKEN_QUERY, True, hAccessToken);

   if not bSuccess then
   begin
      if (GetLastError = ERROR_NO_TOKEN) then
          bSuccess := OpenProcessToken(GetCurrentProcess, TOKEN_QUERY,hAccessToken);
   end;

   if bSuccess then
   begin
      GetMem(ptgGroups, 1024);
      bSuccess := GetTokenInformation(hAccessToken, TokenGroups, ptgGroups, 1024, dwInfoBufferSize);
      CloseHandle(hAccessToken);

      if bSuccess then
      begin
         AllocateAndInitializeSid(SECURITY_NT_AUTHORITY, 2,
                                  SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS,
                                  0, 0, 0, 0, 0, 0, psidAdministrators);
         {$R-}
         for x := 0 to ptgGroups.GroupCount - 1 do
             if EqualSid(psidAdministrators, ptgGroups.Groups[x].Sid) then
             begin
                if _WinVista_ and NeedFullVistaRights then
                begin
                  // Check if the current user has administrator privileges (only admins may start services)
                  // Attention: On Windows Vista it is NOT enough to test if the user is in the administrator group
                  // On Vista even administrators may run with restricted privileges! (User Account Manager!)
                  hService := OpenSCManager(nil, nil, SC_MANAGER_ALL_ACCESS);
                  if (hService <> 0) then
                  begin
                     Result := True;
                     CloseServiceHandle(hService);
                  end;
                end
                else
                  Result := True;
                break;
             end;
         {$R+}
         FreeSid(psidAdministrators);
      end;
      FreeMem(ptgGroups);
   end;
end;
{=========================================================================}
*/
bool COperatingSystem::isAdministrator( bool NeedFullVistaRights )
{
	bool Result = false;

	SID_IDENTIFIER_AUTHORITY authority = SECURITY_NT_AUTHORITY;
	// SECURITY_BUILTIN_DOMAIN_RID = 0x00000020;
	// DOMAIN_ALIAS_RID_ADMINS     = 0x00000220;

	HANDLE hAccessToken;
	PTOKEN_GROUPS ptgGroups;
	DWORD dwInfoBufferSize;
	PSID psidAdministrators;
	HANDLE hService;
	
	BOOL bSuccess = OpenThreadToken( GetCurrentThread(), TOKEN_QUERY, true, &hAccessToken);

	if (!bSuccess)
	{
		if (GetLastError() == ERROR_NO_TOKEN)
		{
			bSuccess = OpenProcessToken( GetCurrentProcess(), TOKEN_QUERY, &hAccessToken);
		}
	}

	if (bSuccess)
	{
		ptgGroups = (PTOKEN_GROUPS)malloc( 1024 );
		if (!ptgGroups)
		{
			return false;
		}

		bSuccess = GetTokenInformation(hAccessToken, TOKEN_INFORMATION_CLASS::TokenGroups, ptgGroups, 1024, &dwInfoBufferSize);
		CloseHandle(hAccessToken);

		if (bSuccess)
		{
			AllocateAndInitializeSid( &authority, 2, SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS, 0, 0, 0, 0, 0, 0, &psidAdministrators);

			for ( u32 x = 0; x < ptgGroups->GroupCount; x++)
			{
				if (EqualSid(psidAdministrators, ptgGroups->Groups[x].Sid))
				{
					if (isWinVista() && NeedFullVistaRights)
					{				
						// Check if the current user has administrator privileges (only admins may start services)
						// Attention: On Windows Vista it is NOT enough to test if the user is in the administrator group
						// On Vista even administrators may run with restricted privileges! (User Account Manager!)
						hService = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
						if (hService != 0)
						{
							Result = true;
							BOOL ok = CloseServiceHandle( (SC_HANDLE)hService );
							if (ok != ERROR_SUCCESS)
							{
								/// something went wrong
							}
						}
					}
					else
					{
						Result = true;
					}
					break;
				}
			}
			FreeSid(psidAdministrators);
		}
		free(ptgGroups);
	}

	return Result;
}


//=======================================================================================================

#ifdef BPM_USE_WX_GUI

void test_BPM_Utils( wxListBox* out )
{
	if (!out)
		return;

	out->Append( wxString( _("Start test for BPM Utils:") ) );

	wxString s;
	s = _("RAM Avail : "); s << CRAM::getFreeMemory() << _(" kB"); out->Append( s );
	s = _("RAM Total : "); s << CRAM::getTotalMemory() << _(" kB"); out->Append( s );
	s = _("RAM Used : "); s << CRAM::getUsedMemory() << _(" kB"); out->Append( s );

	s = _("CPU-Dump : ");
	irr::core::stringc cpu_dump = CCPU::dump();
	irr::core::array<irr::core::stringc> container;
	cpu_dump.split( container, "\r\n", 2, true, false );
	s << _("lines = "); s << container.size(); out->Append( s );

	for ( u32 line = 0; line < container.size(); line++ )
	{
		s = container[line].c_str();
		out->Append( s );
	}

	s = _("OS-Name : "); s << COperatingSystem::getName().c_str(); out->Append( s );
	s = _("OS-Vendor : "); s << COperatingSystem::getVendor().c_str(); out->Append( s );
	s = _("OS-isAdmin : "); s << COperatingSystem::isAdministrator( false ); out->Append( s );
	
}

#endif

} // end namespace bpm
