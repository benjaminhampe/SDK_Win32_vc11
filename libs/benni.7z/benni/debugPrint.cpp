#include "debugPrint.h"


// dbPRINT
irr::core::stringc dbDebugString( const char* fn, const char* file, int line, const char* formatString, ... )
{
	va_list p;
	va_start(p,formatString);
	const unsigned long int bufferSize = 4096;
	char buffer[bufferSize];

	#if defined(_MSC_VER) // if we are using Visual C++ Compiler
		vsnprintf_s( &(buffer[0]), bufferSize, bufferSize-1, formatString, p);
	#elif defined(__GNUC__) // if we are using GNU/Linux C++ Compiler
		vsnprintf( &(buffer[0]), bufferSize, formatString, p);
	#else // some Compiler we have not forseen
		#warning We dont know your Compiler, so we do nothing here
	#endif

	va_end(p);

	char pres[1024];
	sprintf( pres, "%s : %s : %d : ", fn, file, line);
	irr::core::stringc s( pres );
	s += buffer;
	return s;
}

/*
// dbPRINT
void dbPRINT_( const char* formatString, ... )
{
	va_list p;
	va_start(p,formatString);
	const unsigned long int bufferSize = 4096;
	char buffer[bufferSize];

	#if defined(_MSC_VER) // if we are using Visual C++ Compiler
		vsnprintf_s( &(buffer[0]), bufferSize, bufferSize-1, formatString, p);
	#elif defined(__GNUC__) // if we are using GNU/Linux C++ Compiler
		vsnprintf( &(buffer[0]), bufferSize, formatString, p);
	#else // some Compiler we have not forseen
		#warning We dont know your Compiler, so we do nothing here
	#endif

	va_end(p);

	/// pure BenniMagic

	// __DATE__ __TIME__ __FILE__ __LINE__ 
	wxString msg( _("") );
	msg << __DATE__;
	msg << __TIME__;
	msg << __FILE__;
	msg << __LINE__;
	msg << buffer;

	bpm::GDebugWindow::getInstance().logText( msg );
}

// dbPRINT
void dbPRINT_( const wchar_t* formatString, ... )
{
	va_list p;
	va_start(p,formatString);
	const unsigned long int bufferSize = 4096;
	wchar_t buffer[bufferSize];

	#if defined(_MSC_VER) // if we are using Visual C++ Compiler
		vswprintf( &(buffer[0]), bufferSize, formatString, p);
	#elif defined(__GNUC__) // if we are using GNU/Linux C++ Compiler
		vswprintf( &(buffer[0]), bufferSize, formatString, p);
	#else // some Compiler we have not forseen
		#warning We dont know your Compiler, so we do nothing here
	#endif

	va_end(p);

	/// pure BenniMagic
	wxString msg( _("") );
	msg << __DATE__;
	msg << __TIME__;
	msg << __FILE__;
	msg << __LINE__;
	msg << buffer;
	bpm::GDebugWindow::getInstance().logText( msg );
}

// dbERROR
void dbERROR_( const char* formatString, ... )
{
	va_list p;
	va_start(p,formatString);
	const unsigned long int bufferSize = 4096;
	char buffer[bufferSize];

	#if defined(_MSC_VER) // if we are using Visual C++ Compiler
		vsnprintf_s( &(buffer[0]), bufferSize, bufferSize-1, formatString, p);
	#elif defined(__GNUC__) // if we are using GNU/Linux C++ Compiler
		vsnprintf( &(buffer[0]), bufferSize, formatString, p);
	#else // some Compiler we have not forseen
		#warning We dont know your Compiler, so we do nothing here
	#endif

	va_end(p);

	/// pure BenniMagic
	wxString msg( _("") );
	msg << __DATE__;
	msg << __TIME__;
	msg << __FILE__;
	msg << __LINE__;
	msg << buffer;
	bpm::GDebugWindow::getInstance().logError( msg );
}

// dbERROR
void dbERROR_( const wchar_t* formatString, ... )
{
	va_list p;
	va_start(p,formatString);
	const unsigned long int bufferSize = 4096;
	wchar_t buffer[bufferSize];

	#if defined(_MSC_VER) // if we are using Visual C++ Compiler
		vswprintf( &(buffer[0]), bufferSize, formatString, p);
	#elif defined(__GNUC__) // if we are using GNU/Linux C++ Compiler
		vswprintf( &(buffer[0]), bufferSize, formatString, p);
	#else // some Compiler we have not forseen
		#warning We dont know your Compiler, so we do nothing here
	#endif

	va_end(p);

	/// pure BenniMagic
	wxString msg( _("") );
	msg << __DATE__;
	msg << __TIME__;
	msg << __FILE__;
	msg << __LINE__;
	msg << buffer;
	bpm::GDebugWindow::getInstance().logError( msg );
}

*/


// #if defined(_DEBUG) || defined(DEBUG)

/*
// dbPRINT
void dbPRINT( const char* formatString, ... )
{
	va_list p;
	va_start(p,formatString);
	const unsigned long int bufferSize = 4096;
	char buffer[bufferSize];

	#if defined(_MSC_VER) // if we are using Visual C++ Compiler

	vsnprintf_s( &(buffer[0]), bufferSize, bufferSize-1, formatString, p);

	#elif defined(__GNUC__) // if we are using GNU/Linux C++ Compiler

	vsnprintf( &(buffer[0]), bufferSize, formatString, p);

	#else // some Compiler we have not forseen
		#warning We dont know your Compiler, so we do nothing here
	#endif

	va_end(p);

	#ifdef _IRR_COMPILE_WITH_FLTK_ // if we use FastLightingToolKit for GUI stuff
		fl_alert( formatString, p );
	#endif

	fputs( buffer, stdout );	// simply put the string to standard out file-stream ( console )
	fflush( stdout );			// flush the buffer so we can get the message before anything bad happens or async ( multithreading )
}

// dbPRINT
void dbPRINT( const wchar_t* formatString, ... )
{
	va_list p;
	va_start(p,formatString);
	const unsigned long int bufferSize = 4096;
	wchar_t buffer[bufferSize];

	#if defined(_MSC_VER) // if we are using Visual C++ Compiler

	vswprintf( &(buffer[0]), bufferSize, formatString, p);

	#elif defined(__GNUC__) // if we are using GNU/Linux C++ Compiler

	vswprintf( &(buffer[0]), bufferSize, formatString, p);

	#else // some Compiler we have not forseen
		#warning We dont know your Compiler, so we do nothing here
	#endif

	va_end(p);

	#ifdef _IRR_COMPILE_WITH_FLTK_ // if we use FastLightingToolKit for GUI stuff
		fl_alert( formatString, p );
	#endif

	fputws( buffer, stdout );	// simply put the string to standard out file-stream ( console )
	fflush( stdout );			// flush the buffer so we can get the message before anything bad happens or async ( multithreading )
}

// dbERROR
void dbERROR( const char* formatString, ... )
{
	va_list p;
	va_start(p,formatString);
	const unsigned long int bufferSize = 4096;
	char buffer[bufferSize];

	#if defined(_MSC_VER) // if we are using Visual C++ Compiler

	vsnprintf_s( &(buffer[0]), bufferSize, bufferSize-1, formatString, p);

	#elif defined(__GNUC__) // if we are using GNU/Linux C++ Compiler

	vsnprintf( &(buffer[0]), bufferSize, formatString, p);

	#else // some Compiler we have not forseen
		#warning We dont know your Compiler, so we do nothing here
	#endif

	va_end(p);

	#ifdef _IRR_COMPILE_WITH_FLTK_ // if we use FastLightingToolKit for GUI stuff
		fl_alert( formatString, p );
	#endif

	fputs( buffer, stderr );	// simply put the string to standard out file-stream ( console )
	fflush( stderr );			// flush the buffer so we can get the message before anything bad happens or async ( multithreading )
}

// dbERROR
void dbERROR( const wchar_t* formatString, ... )
{
	va_list p;
	va_start(p,formatString);
	const unsigned long int bufferSize = 4096;
	wchar_t buffer[bufferSize];

	#if defined(_MSC_VER) // if we are using Visual C++ Compiler

	vswprintf( &(buffer[0]), bufferSize, formatString, p);

	#elif defined(__GNUC__) // if we are using GNU/Linux C++ Compiler

	vswprintf( &(buffer[0]), bufferSize, formatString, p);

	#else // some Compiler we have not forseen
		#warning We dont know your Compiler, so we do nothing here
	#endif

	va_end(p);

	#ifdef _IRR_COMPILE_WITH_FLTK_ // if we use FastLightingToolKit for GUI stuff
		fl_alert( formatString, p );
	#endif

	fputws( buffer, stderr );	// simply put the string to standard out file-stream ( console )
	fflush( stderr );			// flush the buffer so we can get the message before anything bad happens or async ( multithreading )
}
*/

void dbPRINT_INFO()
{
#if defined(__x86_64__) || defined(_M_X64)
	dbPRINT("Architecture = x86 64-Bit\n");
#elif defined(__i386) || defined(_M_IX86)
	dbPRINT("Architecture = x86 32-Bit\n");
#else
	dbPRINT("Architecture = unknown\n");
#endif
}

///* dbSTR */
//irr::core::stringc dbSTR( const char* formatString, ... )
//{
//	va_list p;
//	va_start(p,formatString);
//	const unsigned long int bufferSize = 4096;
//	char buffer[bufferSize];
//
//	#if defined(_MSC_VER) // if we are using Visual C++ Compiler
//
//	vsnprintf_s( &(buffer[0]), bufferSize, bufferSize-1, formatString, p);
//
//	#elif defined(__GNUC__) // if we are using GNU/Linux C++ Compiler
//
//	vsnprintf( &(buffer[0]), bufferSize, formatString, p);
//
//	#else // some Compiler we have not forseen
//		#warning We dont know your Compiler, so we do nothing here
//	#endif
//
//	va_end(p);
//
//	return irr::core::stringc( buffer );
//}
//
///* dbSTR */
//irr::core::stringw dbSTR( const wchar_t* formatString, ... )
//{
//	va_list p;
//	va_start(p,formatString);
//	const unsigned long int bufferSize = 4096;
//	wchar_t buffer[bufferSize];
//
//	#if defined(_MSC_VER) // if we are using Visual C++ Compiler
//
//	vswprintf( &(buffer[0]), bufferSize, formatString, p);
//
//	#elif defined(__GNUC__) // if we are using GNU/Linux C++ Compiler
//
//	vswnprintf( &(buffer[0]), bufferSize, formatString, p);
//
//	#else // some Compiler we have not forseen
//		#warning We dont know your Compiler, so we do nothing here
//	#endif
//
//	va_end(p);
//
//	return irr::core::stringw( buffer );
//}

// #endif
