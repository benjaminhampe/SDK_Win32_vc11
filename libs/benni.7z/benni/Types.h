/*
	BPM Studio Primitive Types header

	2014 by BenjaminHampe@gmx.de

	Important: This header-file must be included before anything else
	to detect is your OS, CPU are supported by the current project state
	
	All libraries and interfaces ( API ) are enabled/disabled by this header file,
	so that we have a global control-file for the whole project
	
	If you like to write a module then #include <> this file and use its defines
*/
#ifndef BPM_TYPES_H_INCLUDED
#define BPM_TYPES_H_INCLUDED

#include "Config.h"

////////////////////////////////////////////////////////////
// Define portable fixed-size types
////////////////////////////////////////////////////////////
#	if defined(BPM_COMPILE_WITH_IRRLICHT)
#		include <irrTypes.h>
#		include <irrString.h>
#		include <irrArray.h>
#   	include <path.h>
#	else
#		include <vector>
#		include <string>
#	endif

#	if defined(BPM_COMPILE_WITH_OPENGL)

#	endif

namespace bpm
{
    // All "common" platforms use the same size for char, short and int
    // (basically there are 3 types for 3 sizes, so no other match is possible),
    // we can use them without doing any kind of check

    // 8 bits integer types
    typedef signed   char s8;
    typedef unsigned char u8;

    // 16 bits integer types
    typedef signed   short s16;
    typedef unsigned short u16;

    // 32 bits integer types
    typedef signed   int s32;
    typedef unsigned int u32;

    // 64 bits integer types
    #if defined(_MSC_VER)
        typedef signed   __int64 s64;
        typedef unsigned __int64 u64;
    #else
        typedef signed   long long s64;
        typedef unsigned long long u64;
    #endif

	// floating point types
	typedef float f32;
	typedef double f64;
	typedef long double f80;

	#if defined(BPM_COMPILE_WITH_IRRLICHT)
		typedef irr::io::path SPath;
	#else
		#if defined(BPM_COMPILE_WITH_WX)
			typedef wxString SPath;
		#else
			typedef std::filesystem::path SPath;
		#endif
	#endif
	
	#if defined(BPM_COMPILE_WITH_IRRLICHT)
		typedef irr::core::stringc CString;
		typedef irr::core::stringw WString;
		typedef irr::core::array<CString> CStringArray;
		typedef irr::core::array<WString> WStringArray;
		typedef irr::core::array<s16> SampleBuffer;
		typedef irr::core::array<f32> SampleBufferf;
		typedef irr::core::array<f64> SampleBufferd;
	#else
		#if defined(BPM_COMPILE_WITH_WX)
			// typedef wxInt8		s8;
			// typedef wxUint8		u8;
			// typedef char		c8;
			// typedef wxChar16	c16;
			// typedef wxInt16		s16;
			// typedef wxUint16	u16;
			// typedef wxInt32		s32;
			// typedef wxUint32	u32;
			// typedef wxLongLong_t s64;
			// typedef wxULongLong_t u64;
			// typedef wxFloat32	f32;
			// typedef wxFloat64	f64;
			// typedef wxChar		char_t;
	
			typedef wxString CString;
			typedef wxString WString;
			typedef std::vector<CString> CStringArray;
			typedef std::vector<WString> WStringArray;
			typedef std::vector<s16> SampleBuffer;
			typedef std::vector<f32> SampleBufferf;
			typedef std::vector<f64> SampleBufferd;
		#else	
			typedef std::string CString;
			typedef std::wstring WString;
			typedef std::vector<CString> CStringArray;
			typedef std::vector<WString> WStringArray;
			typedef std::vector<s16> SampleBuffer;
			typedef std::vector<f32> SampleBufferf;
			typedef std::vector<f64> SampleBufferd;
		#endif
	#endif
	
	typedef CString AnsiString;
	typedef WString WideString;
	
} // end namespace bpm

 
#endif