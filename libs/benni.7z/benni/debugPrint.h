// Copyright (C) 2002-2014 Benjamin Hampe
// This file is part of the "irrlicht-engine"
// For conditions of distribution and use, see copyright notice in irrlicht.h

#ifndef BPM6_DEBUG_PRINT_H_INCLUDED
#define BPM6_DEBUG_PRINT_H_INCLUDED

#include <cstdio>
#include <cstdarg>
#include <bpm6/Config.h>
#include <irrlicht.h>

/*
  Zeichen     Hex    Okt 
 ======================== 
    '�'       8E     216 
    '�'       84     204 
    '�'       99     231 
    '�'       94     224 
    '�'       9A     232 
    '�'       81     201 
    '�'       E1     341
*/

#ifdef BPM_USE_WX_GUI

#include <bpm6/gui/wx/GWxDebugWindow.h>

#define dbPRINT(format, ...) \
{ \
	printf("%s : %s : %d : %s", __TIME__ , __FILE__, __LINE__, format, __VA_ARGS__); \
}

#define dbERROR(format, ...) \
{ \
	printf("%s : %s : %d : %s", __TIME__ , __FILE__, __LINE__, format, __VA_ARGS__); \
}

/*
#define dbPRINT(format, ...) \
{ \
	irr::core::stringc msg = dbDebugString(__TIME__ , __FILE__, __LINE__, format, __VA_ARGS__); \
	bpm::GDebugWindow::getInstance().logText( wxString(msg.c_str()) ); \
}

#define dbERROR(format, ...) \
{ \
	irr::core::stringc msg = dbDebugString(__TIME__ , __FILE__, __LINE__, format, __VA_ARGS__); \
	bpm::GDebugWindow::getInstance().logText( wxString(msg.c_str()) ); \
}
*/
#else

#define dbPRINT(format, ...) \
{ \
	fprintf( stdout, "%s : %s : %d : %s\n", __DATE__, __FILE__, __LINE__, (format) , __VA_ARGS__ ); \
}

#define dbERROR(format, ...) \
{ \
	fprintf( stderr, "%s : %s : %d : %s\n", __DATE__, __FILE__, __LINE__, (format) , __VA_ARGS__ ); \
}

#endif


irr::core::stringc dbDebugString( const char* fn, const char* file, int line, const char* formatString, ... );

void dbPRINT_INFO();

#endif // BPM6_DEBUG_PRINT_H_INCLUDED
