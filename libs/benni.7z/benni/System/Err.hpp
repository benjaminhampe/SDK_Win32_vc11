#ifndef BPM_ERR_H
#define BPM_ERR_H

////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include <Config.h>
#include <ostream>

namespace bpm
{
////////////////////////////////////////////////////////////
/// \brief Standard stream used by BPM to output warnings and errors
///
////////////////////////////////////////////////////////////
BPM_API std::ostream& err();

} // namespace bpm

#endif // BPM_ERR_H


////////////////////////////////////////////////////////////
/// \fn bpm::err
/// \ingroup system
///
/// By default, bpm::err() outputs to the same location as std::cerr,
/// (-> the stderr descriptor) which is the console if there's
/// one available.
///
/// It is a standard std::ostream instance, so it supports all the
/// insertion operations defined by the STL
/// (operator <<, manipulators, etc.).
///
/// bpm::err() can be redirected to write to another output, independantly
/// of std::cerr, by using the rdbuf() function provided by the
/// std::ostream class.
///
/// Example:
/// \code
/// // Redirect to a file
/// std::ofstream file("bpmml-log.txt");
/// std::streambuf* previous = bpm::err().rdbuf(file.rdbuf());
///
/// // Redirect to nothing
/// bpm::err().rdbuf(NULL);
///
/// // Restore the original output
/// bpm::err().rdbuf(previous);
/// \endcode
///
////////////////////////////////////////////////////////////
