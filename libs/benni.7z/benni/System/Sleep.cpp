////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include "Sleep.h"

#if defined(BPM_SYSTEM_WINDOWS)
    #include <System/Win32/SleepImpl.h>
#else
    #include <System/Unix/SleepImpl.h>
#endif


namespace bpm
{
////////////////////////////////////////////////////////////
void sleep(Time duration)
{
    if (duration >= Time::Zero)
        priv::sleepImpl(duration);
}

} // namespace bpm
