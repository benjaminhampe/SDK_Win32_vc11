#ifndef BPM_SLEEP_H
#define BPM_SLEEP_H

////////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include <Config.h>
#include <System/Time.h>

namespace bpm
{
////////////////////////////////////////////////////////////
/// \ingroup system
/// \brief Make the current thread sleep for a given duration
///
/// bpm::sleep is the best way to block a program or one of its
/// threads, as it doesn't consume any CPU power.
///
/// \param duration Time to sleep
///
////////////////////////////////////////////////////////////
void BPM_API sleep(Time duration);

} // namespace bpm


#endif // BPM_SLEEP_H
