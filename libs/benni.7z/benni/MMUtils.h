/*
	(c) 2014 AlcaTech Benjamin Hampe
	
	All Rights Reserved

	D 01277 Dresden			Tel.: +49(0)351-4403270
	Schlüterstraße 29       info@alcatech.de

	This code is for reference purposes only and may not be copied or
	distributed in any format electronic or otherwise except one copy
	for backup purposes.
	
	No Any Component individually or in a collection
	subclassed or otherwise from the code in this unit, or associated
	files may be sold or distributed without express permission from AlcaTech.

	For more licence informations please refer to the associated HelpFile.
	
	Date: 2014-07-07
	
*/

#ifndef BPM_UTILS_H_INCLUDED
#define BPM_UTILS_H_INCLUDED

#define _MMDEBUG_

#ifdef BUILD_ACTIVEX
   #include MMREGCODES.INC
#endif

#include <irrlicht.h>
#include <windows.h>

namespace bpm {
namespace utils {

	irr::core::stringc InstalledUser = "*UI:*******************************************************************************";
	
    long InitCode = 0;
    long ErrorCode = 0;
    int SHandle = 0;
    int IValue = 0;
    int DValue = 0;
    char* SBuf = nullptr;
    HANDLE MMUTILDLLHandle = NULL;

	irr::core::stringc SValue;
    bool _Win95_;
    bool _Win98_;
    bool _WinME_;
    bool _Win9x_;
    bool _WinNT3_;
    bool _WinNT4_;
    bool _Win2K_;
    bool _Win2K3_;
    bool _WinXP_;
    bool _WinVista_;
    bool _Windows7_;
    bool _WinVistaUp_;
    bool _WinNT_;
    bool _WinNT_NEW_;
    bool _WinNT_WDM_;
    int _CPU_;
    bool _MMX_;
    bool _USECPUEXT_;

#ifdef USEDLL
const
#ifdef WIN32
   MMUtilDLLName    = "MMUTIL32.DLL"; // \\0
   MMUtilDLLKeyName = "MMKEY32.DLL"; // \\0
#else
   MMUtilDLLName    = "MMUTIL16.DLL"; // \\0
   MMUtilDLLKeyName = "MMKEY16.DLL"; // \\0
#endif
#endif

const
    // { Processor constants }
    int PENTIUM    = 1;
    int PENTIUMPRO = 2;
    int PENTIUMPRO2= 3;

    int MMAXLONG   = 2000000000;

#ifdef WIN32
    int MM_USER    = WM_APP;
#else
    int MM_USER    = WM_USER;
#endif

    int MM_TIMER   = MM_USER + 10;

#ifndef WIN32
    MAX_PATH   = 260;
    cl3DLight  = clBtnFace;

	void MoveWindowOrg( HDC hDC, int dx, int dy);
#else
	bool MMSetThreadPriority( HANDLE hThread, int nPriority);
	//Variant GetFromRegistry( HKEY _RootKey, string _Localkey, string _Field, Variant Value);
	//procedure SaveInRegistry(_RootKey:HKEY;_Localkey,_Field:string;Value:Variant);
	//function  GetFromRegistryBinary(_RootKey:HKEY;_Localkey,_Field:string;var Buffer; BufSize: integer): integer;
	//procedure SaveInRegistryBinary(_RootKey:HKEY;_Localkey,_Field:string;var Buffer; BufSize: integer);
	//procedure DeleteRegistryValue(_RootKey:HKEY;_Localkey,_Field:string);
	//procedure DeleteRegistryKey(_RootKey:HKEY;Key:string);
	//procedure MoveRegistryKey(_RootKey:HKEY;OldKey,NewKey: string; Delete: Boolean);

	//function  GetCPUUsage: integer;
	//function  GetShortFileName(const FileName: TFileName): String;

	//function  GetCPUType: integer;
	//function  GetCPUFeatures: Longint;
	//function  GetCPUMode: integer;
	//function  GetCPUCycles: int64;

	//procedure InitTimeMeasure;
	//procedure StartTimeMeasure;
	//function  StopTimeMeasure(Scale: integer): string;

	//procedure InitCyclesMeasure;
	//procedure StartCyclesMeasure;
	//function  StopCyclesMeasure(Scale: integer): string;
#endif

//function  HaveWin95: Boolean;
//function  HaveWin98: Boolean;
//function  HaveWinME: Boolean;
//function  HaveWinNT: Boolean;
//function  HaveWinNT4: Boolean;
//function  HaveWin2K: Boolean;
//function  HaveWin2K3: Boolean;
//function  HaveWinXP: Boolean;
//function  HaveWinVista: Boolean;
//function  HaveWindows7: Boolean;
//function  HaveAfterWinVista: Boolean;
//function  HaveAfterWin7: Boolean;
//
//function  Is64BitWindows: Boolean;
//
//function  IsRunningVirtualPC: Boolean;
//
//function  IsAdministrator(NeedFullVistaRights: Boolean): Boolean;
//
//function  GetCPUCount: integer;
//
//function  GetProcessAffinityMaskByID(ID: DWord; var dwProcessAffinityMask, dwSystemAffinityMask: DWord): Boolean;
//function  SetProcessAffinityMaskByID(ID, Affinity: DWORD): Boolean;
//function  SetThreadAffinityMaskByID(ID, Affinity: DWORD): Boolean;
//function  SetThreadIdealProcessorByID(ID, Processor: Dword): Boolean;
//
//function  GetProcessorCountByAffinityMask(Mask: integer): integer;
//
//function  GetRegAccessMode(sKey: string; defAccess: Cardinal): Cardinal;
//
//function  TimeGetExactTime: int64;
//
//procedure Delay(ms: DWORD; ProcessMessages: Boolean);
//function  NonClientHeight: integer;
//function  MenuHeight: integer;
//function  BitsPerPixel: integer;
//function  ClientToClient(Destination, Source: TControl; P: TPoint): TPoint;

#ifdef WIN32
	//function  CreateFullDir(Dir: string): Boolean;
	//function  IsDirectoryEmptyEx(const Dir: string; CheckForFilesOnly: Boolean): Boolean;
	//function  IsDirectoryEmpty(const Dir: string): Boolean;
	//function  ListDirectoriesEx(Dir: string; ReturnFullPath, SubDirs: Boolean; var DirList: TStrings): integer;
	//function  ListDirectories(Dir: string; ReturnFullPath: Boolean; var DirList: TStrings): integer;
	//function  ListFiles(Dir: string; Extensions: array of string; var FileList: TStrings): integer;
	//function  DeleteFileEx(FileName: String; Recycle: Boolean): Boolean;
	//function  CopyDir(fromDir, toDir: string): Boolean;
	//function  MoveDir(fromDir, toDir: string): Boolean;
	//function  DeleteDir(Dir: string): Boolean;
#endif

//function  GetFileSize(Name: TFileName): Longint;
//function  GetDiskStats(const Directory: string; var nFree, nSize: Int64): Boolean;
//function  GetDiskFree(const Directory: string; nBytes: Longint): Boolean;
//procedure ChangeColors(Bitmap: TBitmap; DrawInactive: Boolean;
//                       ForeColor, InactiveColor, BackColor: TColor);
//procedure GetBitmapSize(Bitmap: HBitmap; var W, H: integer);
//function  GetTransparentColorEx(Bitmap: HBitmap; Point: TPoint): TColorRef;
//function  GetTransparentColor(Bitmap: HBitmap): TColorRef;
//procedure DrawTransparentBitmapROP(DC: HDC; Bitmap: HBitmap; X, Y: integer;
//                                   Src: TRect; Transparent: TColorRef;
//                                   ROP: DWORD);
//procedure DrawTransparentBitmapEx(DC: HDC; Bitmap: HBitmap; X, Y: integer;
//                                  Src: TRect; Transparent: TColorRef);
//procedure DrawTransparentBitmap(DC: HDC; Bitmap: HBitmap;
//                                X, Y: integer; Transparent: TColorRef);
//procedure StretchDrawTransparentBitmap(DC: HDC; Bitmap: HBitmap; X, Y, DestWidth, DestHeight: integer; Transparent: TColorRef);
//procedure TileBlt(DC: HDC; Bitmap: HBitmap; const aRect:TRect; ROP: Longint; Direction: integer);
//procedure FillGradient(DC: HDC; BeginColor, EndColor: TColor;
//                       nColors: integer; const aRect: TRect);
//procedure FillSolid(DC: HDC; Color: TColor; const aRect: TRect);
//function  WinExecAndWait(FileName: TFileName): Boolean;
//function  WinExecAndWaitEx(FileName: TFileName; TimeOut: DWORD): Boolean;
//function  WinExecAndWaitElevated(FileName: TFileName; TimeOut: DWORD; Elevated: Boolean): Boolean;
//
//procedure TimeDecode(Time: Longint; var Hour, Min, Sec, MSec: Word);
//function  TimeToMask(Time: Longint): string;
//function  MaskToTime(Mask: string): Longint;

#ifdef WIN32
//function  TimeToString64Ex(Time: int64; MSec: Boolean): string;
//function  TimeToString64(LowTime,HighTime: Cardinal; MSec: Boolean): string;
#endif
//function  TimeToStringEx(Time: MM_int64; MSec: Boolean): string;
//function  TimeToString(Time: MM_int64): string;

//function  CheckFloat(const S: string): string;
//function  CheckFloatEx(const S: string; DecimalSep: Char): string;
//function  StrToFloatEx(S: string): Extended;
//function  FloatToStrEx(V: Extended; DecimalSep: Char): string;
//
//function  WideStrLen(CharsP: PWideChar): Integer;
//
//function  DBToLin(DB: Float): Float;
//function  LinToDB(lin: Float): Float;
//function  DBToVolume(DB: Float; Base: Longint): Longint;
//function  VolumeToDB(Volume, Base: Longint): Float;
//function  VolumeToStringShort(Volume, Base: Longint;  Precision: integer): string;
//function  VolumeToString(Volume, Base: Longint;  Precision: integer): string;
//function  PanningToString(Panning, Range: Longint): String;
//procedure CalcVolume(Base,Volume,Panning: Longint; var Left, Right: Longint);
//function  CombineVolume(Vol1,Vol2,Base: Longint): Longint;
//function  FormatBigNumber(dw: Longint): String;
//function  BytesToString(Bytes: Comp): string;
//procedure DrawRubberband(Sender: TObject; aRect: TRect);
//procedure DrawRubberLineEx(Sender: TObject; aRect: TRect; Pen: HPEN; ROP: DWORD);
//procedure DrawRubberLine(Sender: TObject; aRect: TRect);
//procedure TextOutAligned(Canvas: TCanvas; X, Y: integer; Text: String;
//                         FontName: PChar; FontSize: integer; Align: Byte);
//
//function  GetVersionNumber(FileName: String): string;
//function  VersionToInt(sVersion: string): integer;
//function  GetWindowsLanguage: integer;
//function  GetCountryCode: string;
//
//function  GetHarddiskID(HarddiskID: Byte): string;
//function  GetVolumeID(Drive: Char): string;
//function  GetHWID: string;
//
//function  GetShellDisplayName(Path: string; IgnoreMediumName: Boolean): string;
//function  GetShellIconIndex(Path: string; Flags: DWORD): integer;
//function  GetShellIcon(Path: string; Flags: DWORD): HICON;
//function  GetShellSystemImageList: THandle;
//
//function  GetVolumeName(Drive: string): string;
//
//function  TextToUniqueInt(Text: string): Cardinal;
//function  CreateUniqueID(Files: TStringList): Cardinal;
//
//function  GetSpecialFolder(nFolderId: integer): string;
//
//function  ExtractTopDirectory(const Directory: string): string;
//function  ExtractSubDirectory(const Directory: string): string;
//function  ExtractParentDir(const Directory: string): string;
//
//procedure CenterFormOverActiveForm(AForm,ActiveForm: TForm);
//procedure CenterFormOverActive(aForm: TForm);
//
//procedure ConvertTo32BitImageList(const ImageList: TImageList);
//
//function  GetTaskbarHeight: integer;
//function  GetTaskbarWidth: integer;
//function  GetWorkAreaRect: TRect;
//
//procedure SetFontSmoothing(aFont: TFont);
//
//procedure AssignStrings(Dest, Source: TStrings);
//procedure GrowStrings(Strings: TStrings);
//
//procedure WinYield(Wnd: THandle);
//function  DesignMode: Boolean;

//const
//  PathDelim  = {$IFDEF MSWINDOWS} '\'; {$ELSE} '/'; {$ENDIF}
//  DriveDelim = {$IFDEF MSWINDOWS} ':'; {$ELSE} '';  {$ENDIF}
//  PathSep    = {$IFDEF MSWINDOWS} ';'; {$ELSE} ':'; {$ENDIF}
//
//function IncludeTrailingPathDelimiter(const S: string): string;
//function ExcludeTrailingPathDelimiter(const S: string): string;
//function IncludeTrailingBackslash(const S: string): string;
//function ExcludeTrailingBackslash(const S: string): string;
//
//function  CheckPath(const Path: string; Flag: Boolean): String;
//function  CheckFileName(S: String; IncludesPath: Boolean): string;
//
//function SearchParamStr(Switch: string): Boolean;
//
//function int64shl32(V: int64; Shift: Byte): MMLarge_Integer;
//function int64shr32(V: MMLARGE_INTEGER; Shift: Byte): integer;
//function int64add32(V: MMLARGE_INTEGER; AddValue: integer): MMLarge_Integer;
//function int64sub32(V: MMLARGE_INTEGER; SubValue: integer): MMLarge_Integer;
//
//function CalcHash(lpBuffer: PAnsiChar; Length: integer): integer;

#ifdef WIN32
//function  MakeCdeclCallback(const Method: TMethod; StackSize: Shortint): Pointer;
//function  MakeStdcallCallback(const Method: TMethod): Pointer;
//procedure FreeCallback(Callback: Pointer);
//function  GetTempFile: string;
//
//function  Min64(a, b: int64): int64;
//function  Max64(a, b: int64): int64;
//function  MinMax64(X, Min, Max: int64): int64;
//function  InMinMax64(X,Min,Max: int64): Boolean;
//
//function  Sign(Value: Longint): Longint;
//
//function SwapWord(const aValue: Word): Word;
//function SwapDWord(const aValue : DWord): DWord;
#endif

//procedure FreeAndNil(var Obj);

#ifdef WIN32
//type
//    EWin32Error = class(Exception)
//    public
//        ErrorCode: DWORD;
//    end;
//
//function    SysErrorMessage(ErrorCode: Integer): string;
//procedure   RaiseLastWin32Error;
//function    Win32Check(RetVal: BOOL): BOOL;
#endif

///// {========================================================================}
////Functionpointer
///// {
//   SwapSmall          : procedure (var a, b: SmallInt);
//   SwapInt            : procedure (var a, b: integer);
//   SwapLong           : procedure (var a, b: Longint);
//   Min                : function  (a, b: Longint): Longint;
//   Max                : function  (a, b: Longint): Longint;
//   MinMax             : function  (X, Min, Max: Longint): Longint;
//   Limit              : function  (X, Min, Max: Longint): Longint;
//   InMinMax           : function  (X, Min, Max: Longint): Boolean;
//   InRange            : function  (X, Min, Max: Longint): Boolean;
//
//   incHuge            : procedure (Var Pointer; nBytes: Longint);
//   GlobalFillMem      : procedure (var X; Cnt: Longint; Value: Byte);
//   GlobalFillLong     : procedure (var X; Cnt: Longint; Value: Longint);
//   GlobalMoveMem      : procedure (const Source; var Dest; Cnt: Longint);
//   GlobalCmpMem       : function  (const p1, p2; Cnt: Longint): Boolean;
//
////   {$IFDEF TRIAL}
//   IDERunning         : function: Boolean;
//   CheckTime          : function: Boolean;
//   CheckParam1        : function  (dw1: DWORD; b1: BOOL; lp1: PChar): THandle; stdcall;
//   CheckParam2        : function  (lp1, lp2: PChar; dw1: DWORD; lp3, lp4, lp5: PDWORD;
//                                   lp6: PChar; dw2: DWORD): Boolean; stdcall;
////   {$ENDIF}
//
//function  GlobalAllocMem(Size: Longint): Pointer;
//procedure GlobalReAllocMem(var p: Pointer; Size: Longint);
//procedure GlobalFreeMem(var p: Pointer);
//function  GlobalMemSize(const p: Pointer): Longint;
//
//procedure RegisterPackage(const Pack: string); {$IFDEF BUILD_ACTIVEX} stdcall; export; {$ENDIF}
//procedure RegisterFailed(Code: Longint; Control: TComponent; Text: string);
//procedure RegisterComponent(Code: Longint; Control: TComponent; Text: string);
//function  ComponentRegistered(Code: Longint; Control: TComponent; Text: string): Longint;
//function  PackageRegistered(Pack: string): integer;
//
//function FindIDERunning: Boolean;
//

} // end namespace utils
} // end namespace bpm

#endif // BPM_UTILS_H_INCLUDED