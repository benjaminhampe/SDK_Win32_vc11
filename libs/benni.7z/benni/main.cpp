

///
///
///	Test PortAudio Streams and SFML Streams
///
///
#include <stdio.h>
#include <math.h>

#include <irrlicht.h>
#include <../source/Irrlicht/os.cpp>
#include <../source/Irrlicht/CColorConverter.cpp>
#include <../source/Irrlicht/CImage.cpp>

/*
#include "debugPrint.h"

#define TEST_SFML_PLAYING
#define TEST_PORTAUDIO_PLAYING

#include <SFML/Audio.hpp>

#ifdef TEST_PORTAUDIO_PLAYING
#include <portaudio.h>
#include <pa_asio.h>
#define NUM_SECONDS   (10)
#define SAMPLE_RATE   (44100)
#define AMPLITUDE     (0.8)
#define FRAMES_PER_BUFFER  (64)
#define OUTPUT_DEVICE Pa_GetDefaultOutputDevice()

class BPM_AudioBuffer
{
	irr::u32 Format; // 0 == S16, 1 == F32
	irr::u32 ChannelCount;
	irr::u32 SampleRate;
    
	irr::s16* SampleData;
	irr::s64 SampleCount;
	irr::s64 SampleIndex;
	irr::s64 FrameCount;
	irr::s64 FrameIndex;

public:
	BPM_AudioBuffer( sf::SoundBuffer* buffer = NULL)
		: Format(0), ChannelCount(0), SampleRate(0), SampleData(NULL)
		, SampleCount(0), SampleIndex(0)
	{
		if (buffer)
		{
			Format = 0;
			ChannelCount = buffer->getChannelCount();
			SampleRate = buffer->getSampleRate();
			SampleData = (irr::s16*)const_cast<sf::Int16*>( buffer->getSamples() );
			SampleCount = buffer->getSampleCount();
			SampleIndex = 0;
			FrameCount = SampleCount / ChannelCount;
			FrameIndex = 0;
		}
	}
	
	inline irr::s16 getSample()
	{
		if (!SampleData)
			return 0;

		irr::s16 sample = SampleData[ SampleIndex ];

		SampleIndex++;
		SampleIndex = SampleIndex % SampleCount;

		return sample;
	}

} myAudioDataS16;

// This routine will be called by the PortAudio engine when audio is needed.
// It may called at interrupt level on some machines so don't do anything
// that could mess up the system like calling malloc() or free().

static int paCallbackS16( 
						const void *inputBuffer, 
						void *outputBuffer, // signed 16-bit
						unsigned long framesPerBuffer,
                        const PaStreamCallbackTimeInfo* timeInfo,
                        PaStreamCallbackFlags statusFlags,
                        void *userData )
{
    // avoid unused variable warnings
    (void) inputBuffer;
    (void) timeInfo;
    (void) statusFlags;

	BPM_AudioBuffer *data = (BPM_AudioBuffer*)userData;

    irr::s16 *out = (irr::s16*)outputBuffer;

	unsigned long finished = 0;

    for( unsigned long i=0; i<framesPerBuffer; i++ )
    {
		*out = data->getSample()
	}

	return finished;
}

#endif


int main ( int argc, char** argv )
{

	sf::SoundBuffer aBuffer;
	sf::SoundBuffer bBuffer;
	sf::SoundBuffer cBuffer;
	sf::SoundBuffer dBuffer;

	bool aLoaded = aBuffer.loadFromFile("a.ogg");
	bool bLoaded = bBuffer.loadFromFile("b.ogg");
	bool cLoaded = cBuffer.loadFromFile("c.ogg");
	bool dLoaded = dBuffer.loadFromFile("d.ogg");

	if (!aLoaded) dbERROR("Could not load a.ogg\n" ) else dbPRINT("Loaded a.ogg and start playing\n" )
	if (!bLoaded) dbERROR("Could not load b.ogg\n" ) else dbPRINT("Loaded b.ogg and start playing\n" )
	if (!cLoaded) dbERROR("Could not load c.ogg\n" ) else dbPRINT("Loaded c.ogg and start playing\n" )
	if (!dLoaded) dbERROR("Could not load d.ogg\n" ) else dbPRINT("Loaded d.ogg and start playing\n" )

#ifdef TEST_SFML_PLAYING
	sf::Sound aSound;
	sf::Sound bSound;
	sf::Sound cSound;
	sf::Sound dSound;

	if (aLoaded) { aSound.setBuffer(aBuffer); aSound.play(); }
	if (bLoaded) { bSound.setBuffer(bBuffer); bSound.play(); }
	if (cLoaded) { cSound.setBuffer(cBuffer); cSound.play(); }
	if (dLoaded) { dSound.setBuffer(dBuffer); dSound.play(); }

	Sleep( 15000 );

	aSound.stop();
	bSound.stop();
	cSound.stop();
	dSound.stop();
#endif

#ifdef TEST_PORTAUDIO_PLAYING
    PaError err;
	PaStream *stream;
	PaStreamParameters outputParameters;
    PaAsioStreamInfo asioOutputInfo;
    paAudioData data;
	data.Data = aBuffer.getSamples();


    int outputChannelSelectors[1];
    
    err = Pa_Initialize();
    if( err != paNoError ) goto error;

    outputParameters.device = OUTPUT_DEVICE;
    outputParameters.channelCount = 1;       // MONO output 
    outputParameters.sampleFormat = paFloat32; // 32 bit floating point output
    outputParameters.suggestedLatency = Pa_GetDeviceInfo( outputParameters.device )->defaultLowOutputLatency;

	// Use an ASIO specific structure. WARNING - this is not portable.
    asioOutputInfo.size = sizeof(PaAsioStreamInfo);
    asioOutputInfo.hostApiType = paASIO;
    asioOutputInfo.version = 1;
    asioOutputInfo.flags = paAsioUseChannelSelectors;
    outputChannelSelectors[0] = 1; // skip channel 0 and use the second (right) ASIO device channel
    asioOutputInfo.channelSelectors = outputChannelSelectors;
    outputParameters.hostApiSpecificStreamInfo = &asioOutputInfo;

    err = Pa_OpenStream(
              &stream,
              NULL, // no input
              &outputParameters,
              SAMPLE_RATE,
              FRAMES_PER_BUFFER,
              paClipOff,      // we won't output out of range samples so don't bother clipping them
              patestCallback,
              &data );
    if( err != paNoError ) goto error;

    err = Pa_StartStream( stream );
    if( err != paNoError ) goto error;
    
    printf("Play for %d seconds.\n", NUM_SECONDS ); fflush(stdout);
    Pa_Sleep( NUM_SECONDS * 1000 );

    err = Pa_StopStream( stream );
    if( err != paNoError ) goto error;
    
    err = Pa_CloseStream( stream );
    if( err != paNoError ) goto error;
    
    Pa_Terminate();
    printf("Test finished.\n");
    return err;
error:
    Pa_Terminate();
    fprintf( stderr, "An error occured while using the portaudio stream\n" );
    fprintf( stderr, "Error number: %d\n", err );
    fprintf( stderr, "Error message: %s\n", Pa_GetErrorText( err ) );
    return err;

#endif
	return 0;
}
*/
