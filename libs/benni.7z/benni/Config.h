/*
	BPM Studio Config header

	2014 by BenjaminHampe@gmx.de

	Important: This header-file must be included before anything else
	to detect is your OS, CPU are supported by the current project state
	
	All libraries and interfaces ( API ) are enabled/disabled by this header file,
	so that we have a global control-file for the whole project
	
	If you like to write a module then #include <> this file and use its defines
*/
#ifndef BPM_COMPILE_CONFIG_H_INCLUDED
#define BPM_COMPILE_CONFIG_H_INCLUDED

////////////////////////////////////////////////////////////
// Include C/C++ Standard header before anything else
////////////////////////////////////////////////////////////

#include <cstdlib>
#include <cstdio>
#include <cstdarg>
#include <ctime>
#include <cmath>
#include <clocale>
#include <cctype>
#include <cfloat>

#define RND(seed) rand()%(seed)

////////////////////////////////////////////////////////////
// Define a portable debug macro
////////////////////////////////////////////////////////////
#if !defined(NDEBUG)
    #define BPM_DEBUG
#endif

////////////////////////////////////////////////////////////
// Identify the operating system
////////////////////////////////////////////////////////////

/// Apple Macintosh
#if defined(__APPLE__) || defined(MACOSX)
	#define BPM_OS_MACOSX
	#include <TargetConditionals.h> // OSX header for further differentiation
	#if !defined(MACOSX)
	#define MACOSX // legacy support
	#endif
#endif

/// Sun Solaris
#if defined(__SVR4) && defined(__sun)
	#define BPM_OS_SOLARIS
	#if defined(__sparc)
		#define __BIG_ENDIAN__
	#endif
#endif

/// GNU/Linux 
#if !defined(BPM_OS_WIN32) && !defined(BPM_OS_WIN64) && !defined(BPM_OS_MACOSX)
#if !defined(BPM_OS_SOLARIS)
	#define BPM_OS_LINUX
#endif
#define BPM_POSIX_API
#define BPM_COMPILE_WITH_X11
#endif


// Windows
#if defined(_WINDOWS) || defined(_WIN32) || defined(WIN32) || defined(__WIN32__) || defined(_WIN64) || defined(WIN64)
    #define BPM_SYSTEM_WINDOWS

	// Windows 32
	#if defined(_WIN32) || defined(WIN32) || defined(__WIN32__)
		#define BPM_SYSTEM_WIN32
	#endif
	
	// Windows 64
	#if defined(_WIN64) || defined(WIN64)
		#define BPM_SYSTEM_WIN64
	#endif
	
// Windows CE is a very restricted environment for mobile devices
#elif defined(_WIN32_WCE)
	#error Microsoft Windows CE is not supported by BPM-Studio

// XBox only supports the native Window stuff
#elif defined(_XBOX)
	#error Microsoft XBox is not supported by BPM-Studio
	
// Linux
#elif defined(linux) || defined(__linux)
    #define BPM_SYSTEM_LINUX

// MacOS	
#elif defined(__APPLE__) || defined(MACOSX) || defined(macintosh) || defined(Macintosh)
    #define BPM_SYSTEM_MACOS

// FreeBSD
#elif defined(__FreeBSD__) || defined(__FreeBSD_kernel__) 
    #define BPM_SYSTEM_FREEBSD

// Unsupported system
#else
    #error This operating system is not supported by SFML library
	
#endif


#if defined(BPM_SYSTEM_WINDOWS)

    #ifndef NOMINMAX
        #define NOMINMAX
    #endif
	
	/// when using MICROSOFT compiler ...
	#if defined(_MSC_VER)
		#define BPM_COMPILE_WITH_VISUAL_STUDIO
		
		#if _MSC_VER>=1600
			#define BPM_COMPILE_WITH_VC11
		#endif

		#if !defined(_CRT_SECURE_NO_WARNINGS)
			#define _CRT_SECURE_NO_WARNINGS
		#endif
		
		#pragma warning(disable: 4996)
		
		#if !defined(_CRT_SECURE_NO_WARNINGS)
			#define _CRT_SECURE_NO_WARNINGS
		#endif

		#define WIN32_LEAN_AND_MEAN
		#define VC_EXTRALEAN
		#define WIN32_EXTRA_LEAN
		//#define NOSERVICE
		#define NOCOMM
		#define NOMCX
		#define NOIME
		#define NOSOUND
		#define NOKANJI
		#define NORPC
		#define NOPROXYSTUB
		#define NOIMAGE
		#define NOTAPE
	#endif

//	#include <windows.h>
#endif
	
////////////////////////////////////////////////////////////
// Define helpers to create portable import / export macros for each module
////////////////////////////////////////////////////////////
#if !defined(BPM_STATIC)

    #if defined(BPM_SYSTEM_WINDOWS)

        // Windows compilers need specific (and different) keywords for export and import
        #define BPM_API_EXPORT __declspec(dllexport)
        #define BPM_API_IMPORT __declspec(dllimport)

        // For Visual C++ compilers, we also need to turn off this annoying C4251 warning
        #ifdef _MSC_VER

            #pragma warning(disable : 4251)

        #endif

    #else // Linux, FreeBSD, Mac OS X

        #if __GNUC__ >= 4

            // GCC 4 has special keywords for showing/hidding symbols,
            // the same keyword is used for both importing and exporting
            #define BPM_API_EXPORT __attribute__ ((__visibility__ ("default")))
            #define BPM_API_IMPORT __attribute__ ((__visibility__ ("default")))

        #else

            // GCC < 4 has no mechanism to explicitely hide symbols, everything's exported
            #define BPM_API_EXPORT
            #define BPM_API_IMPORT

        #endif

    #endif

#else
    // Static build doesn't need import/export macros
    #define BPM_API_EXPORT
    #define BPM_API_IMPORT
#endif

////////////////////////////////////////////////////////////
// Define portable import / export macros
////////////////////////////////////////////////////////////
#if defined(BPM_EXPORTS)
    #define BPM_API BPM_API_EXPORT
#else
    #define BPM_API BPM_API_IMPORT
#endif

////////////////////////////////////////////////////////////
// Define more compilers
////////////////////////////////////////////////////////////

// when using GCC compiler
#if defined(_MSC_VER)
	// empty
#elif defined(__GNUC__)
	#define BPM_COMPILE_WITH_GCC
#else
	#error The Compiler you use is not supported by BPM-Studio	
#endif

////////////////////////////////////////////////////////////
// Get Host Machine CPU Type
////////////////////////////////////////////////////////////

#if defined(__x86_64__) || defined(_M_X64)
	
	#define BPM_CPU	"amd64"
	#define BPM_CPU_64_BIT
	#define BPM_CPU_HAS_MMX
	#define BPM_CPU_HAS_SSE
	#define BPM_CPU_HAS_SSE2
	#define BPM_LITTLE_ENDIAN
	
#elif defined(__i386) || defined(_M_IX86)

	#define BPM_CPU "i386"
	#define BPM_CPU_32_BIT
	#define BPM_LITTLE_ENDIAN
	
#else
	#error Unknown and thatswhy not supported CPU u got
#endif

// -------------------- Section - Supported Audio APIs -----------------------------------------------

#define BPM_COMPILE_WITH_WX
#define BPM_COMPILE_WITH_IRRLICHT
//#define BPM_COMPILE_WITH_FREETYPE
#define BPM_COMPILE_WITH_FREEGLUT
//#define BPM_COMPILE_WITH_FLTK
//#define BPM_COMPILE_WITH_STL
//#define BPM_COMPILE_WITH_BOOST
#define BPM_COMPILE_WITH_OPENGL
#define BPM_COMPILE_WITH_FFTW3
#define BPM_COMPILE_WITH_PORTAUDIO
#define BPM_COMPILE_WITH_ASIO
#define BPM_COMPILE_WITH_DSOUND9
#define BPM_COMPILE_WITH_WASAPI
#define BPM_COMPILE_WITH_WDMKS
#define BPM_COMPILE_WITH_PLUGINS
#define BPM_COMPILE_WITH_PLUGIN_BASE_DLL
#define BPM_COMPILE_WITH_PLUGIN_CORE_DLL
 
#endif