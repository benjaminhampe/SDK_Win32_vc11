#include "CFileLogger.h"

CFileLogger :: CFileLogger( const char* filename )
	: mFilename(filename)
	, mStream(NULL)
{
	//if((mStream = freopen( mFilename.c_str(), "w", stdout)) == NULL)
    //  exit(-1);

	// printf("this is stdout output\n");
}

CFileLogger :: ~CFileLogger()
{
	// if (mStream)
	//	mStream = freopen("CON", "w", stdout);
   
	// printf("And now back to the console once again\n");
	
	
	// dump all to file	
	FILE* mOut = fopen( mFilename.c_str(), "w" );
	if (mOut)
	{
		fputs( mData.c_str(), mOut );
		fclose( mOut );
	}
}

// now we can get portaudio debug-messages
void CFileLogger :: cb_portaudio_logger(const char *log)
{
	mData += log;
}