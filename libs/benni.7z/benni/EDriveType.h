#ifndef BPM_E_DRIVE_TYPE_H
#define BPM_E_DRIVE_TYPE_H

namespace bpm 
{
	enum E_AUDIO_SAMPLE_TYPE
	{
		EAST_UNKNOW=0,
		EAST_S16,
		EAST_F32,
		EAST_F64,
		EAST_COUNT
	};

	/// Some possible FileAttributes
	enum E_FILE_ATTRIBUTES {
		EFA_READ = 1,
		EFA_WRITE = 2,
		EFA_EXECUTE = 4,
		EFA_HIDDEN = 8,
		EFA_NORMAL = EFA_READ | EFA_WRITE | EFA_EXECUTE
	};

	//! for getDriveList()
	enum E_DRIVE_TYPE {
		ELDT_UNKNOWN = 0,
		ELDT_NOT_EXIST,
		ELDT_REMOVABLE,
		ELDT_FIXED,
		ELDT_REMOTE,
		ELDT_CDROM,
		ELDT_RAMDISK
	};

	//! new names
	const char* const E_DRIVE_TYPE_NAMES[] = {
		"ELDT_UNKNOWN",	"ELDT_NOT_EXIST", "ELDT_REMOVABLE",
		"ELDT_FIXED", "ELDT_REMOTE", "ELDT_CDROM", "ELDT_RAMDISK"
	};

	//! holding information about available physical drives
	struct SDriveInfo {
		AnsiString Name;
		E_DRIVE_TYPE Type;
		u64 AvailSpace; // in KiB
		u64 TotalSpace; // in KiB
		u32 OptimalBlockSize; // in Bytes
	};

} // end namespace bpm
 
#endif