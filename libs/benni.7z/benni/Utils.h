// Copyright (C) 2002-2014 Benjamin Hampe
// This file is part of "BPM-Studio"
// For conditions of distribution and use, see copyright notice in bpm_license.txt

#ifndef BPM6_OS_DETECTION_H_INCLUDED
#define BPM6_OS_DETECTION_H_INCLUDED

#include <bpm6/Config.h>

#if defined(BPM_OS_WINDOWS)
	#include <windows.h>
	#include <tchar.h>
#endif

#ifdef BPM_USE_WX_GUI
	#include <wx/wx.h>
#endif

namespace bpm
{
	//============================================================================================
	//=== Macros for save pointer-deletion
	//============================================================================================

	///@brief Makro for save deleting a pointer created with new
	#define SAVE_DELETE(x)\
	{\
		if ((x)) \
		{ \
			delete (x); \
			(x) = NULL; \
		} \
	}

	///@brief Makro for save deleting an one dimensional array created with new
	#define SAVE_DELETE_ARRAY(x) \
	{ \
		if ((x)) \
		{ \
			delete [] (x); \
			(x) = NULL; \
		} \
	}

	///@brief Makro for save deleting a pointer created with malloc
	#define SAVE_FREE_AND_NIL(x) \
	{ \
		free((x)); \
		(x) = NULL; \
	}

	///@brief Makro for save deleting a COM Object ( derived from IUnknown )
	#define SAVE_RELEASE(x) \
	{ \
		if ((x)) \
		{ \
			(x)->Release(); \
			(x) = NULL; \
		} \
	}

	///@brief Makro for save deleting a reference counted object ( derived from irr::IReferenceCounted )
	#define SAVE_DROP(x) \
	{ \
		if ((x)) \
		{ \
			(x)->drop(); \
			(x) = NULL; \
		} \
	}

	///@brief checks if the given coords are over ( on border or inside ) given rectangle
#ifdef BPM_USE_WX_GUI
	bool isPointInsideRect( const wxPoint& p, const wxRect& r );
#endif

	//============================================================================================
	//=== RAM Commands
	//============================================================================================

	///@class Random Access Memory ( RAM )
	class CRAM
	{
	public:
		static bool getSystemMemory( u32* Total, u32* Avail ); // in kB

		static u32 getTotalMemory(); // in kB
		
		static u32 getFreeMemory(); // in kB
		
		static u32 getUsedMemory(); // in kB
	};

	//============================================================================================
	//=== CPU Commands
	//============================================================================================

	///@brief Macro encapsulating CPUID command
	#if defined(_MSC_VER)
		#include <intrin.h>
		#define bpm_cpuid(request,ax,bx,cx,dx) \
			{ \
				s32 ex[4]; \
				__cpuid(ex,request); \
				(ax) = (u32)ex[0]; \
				(bx) = (u32)ex[1]; \
				(cx) = (u32)ex[2]; \
				(dx) = (u32)ex[3]; \
			}
	#else // just needs GCC compiler and GAS GNU Assembler
		#include <cstdlib>
		#include <cstdio>
		#include <cstring>
		#define bpm_cpuid(request,eax,ebx,ecx,edx) \
			__asm__ __volatile__ ("cpuid": \
			"=a" (eax), "=b" (ebx), "=c" (ecx), "=d" (edx) : "a" (request));   // uses constraints
	#endif

	///@enum CPUID Request
    enum E_CPUID_REQUEST
	{
		ECR_GETVENDORSTRING=0,
		ECR_GETFEATURES,
		ECR_GETTLB,
		ECR_GETSERIAL,
		ECR_INTELEXTENDED=0x80000000,
		ECR_INTELFEATURES,
		ECR_INTELBRANDSTRING,
		ECR_INTELBRANDSTRINGMORE,
		ECR_INTELBRANDSTRINGEND,
		ECR_FORCE_32BIT=0xFFFFFFFF
    };

	const char* const CPUID_IntelFeatureStringsECX[] =
	{
		"",	// 0
		"",	// 1
		"",	// 2
		"",	// 3
		"",	// 4
		"",	// 5
		"",	// 6
		"",	// 7
		"",	// 8
		"",	// 9
		"",	// 10
		"",	// 11
		"",	// 12
		"",	// 13
		"",	// 14
		"",	// 15
		"",	// 16
		"",	// 17
		"",	// 18
		"",	// 19
		"",	// 20
		"",	// 21
		"",	// 22
		"",	// 23
		"",	// 24
		"",	// 25
		"",	// 26
		"",	// 27
		"",	// 28
		"",	// 29
		"",	// 30
		""	// 31
	};


	///@enum Intel CPU features that can be read from ECX register ( as bitflags )
    enum E_CPUID_FEATURE_ECX
	{
        ECF_INTEL_SSE3		= 1 << 0, // SSE3, MXCSR, CR4.OSXMMEXCPT, #XF, if FPU=1 then also FISTTP
		ECF_AMD_AHF64		= 1 << 0, // LAHF and SAHF in PM64
		ECF_INTEL_PCLMUL	= 1 << 1, // PCLMULQDQ
		ECF_AMD_CMP			= 1 << 1, // HTT=1 indicates HTT (0) or CMP (1)
		ECF_INTEL_DTES64	= 1 << 2, // 64-bit Debug Trace and EMON Store MSRs
		ECF_AMD_SVM			= 1 << 2, // EFER.SVME,VMRUN, VMMCALL, VMLOAD and VMSAVE, STGI and CLGI,SKINIT,INVLPGA
		ECF_INTEL_MON		= 1 << 3, // MONITOR/MWAIT, MISC_ENABLE.MONE, MISC_ENABLE.LCMV MONITOR_FILTER_LINE_SIZE MSR also see standard level 0000_0005h setting MISC_ENABLE.MONE=0 causes MON=0
		ECF_AMD_EAS			= 1 << 3, // extended APIC space (APIC_VER.EAS, EXT_APIC_FEAT, etc.)
		ECF_INTEL_DSCPL		= 1 << 4, // Intel CPL-qualified Debug Store
		ECF_AMD_CR8D		= 1 << 4, // MOV from/to CR8D by means of LOCK-prefixed MOV from/to CR0
		ECF_INTEL_VMX		= 1 << 5, // Intel Virtual machine extensions
		ECF_AMD_LZCNT		= 1 << 5, // LZCNT
		ECF_INTEL_SMX		= 1 << 6, // Intel Safer mode extensions CR4.SMXE, GETSEC
		ECF_AMD_SSE4A		= 1 << 6, // SSE4A
		ECF_INTEL_EST		= 1 << 7, // Intel Enhanced SpeedStep Technology
		ECF_AMD_MSSE		= 1 << 7, // misaligned SSE, MXCSR.MM
		ECF_INTEL_TM2		= 1 << 8, // Intel Thermal Monitor MISC_ENABLE.TM2E THERM_INTERRUPT and THERM_STATUS MSRs xAPIC thermal LVT entry THERM2_CONTROL MSR
		ECF_AMD_3DNOW		= 1 << 8, // PREFETCH and PREFETCHW (K8 Rev G and K8L+)
		ECF_INTEL_SSSE3		= 1 << 9, // Supplemental Streaming SIMD Extensions 3 (SSSE3)
		//ECF_AMD_OSVW		= 1 << 9, // OS-visible workaround
		ECF_INTEL_CID		= 1 << 10,// L1 context ID, context ID: the L1 data cache can be set to adaptive or shared mode MISC_ENABLE.L1DCCM
		ECF_AMD_IBS			= 1 << 10,// instruction based sampling
		ECF_INTEL_SDBG		= 1 << 11,// DEBUG_INTERFACE MSR for silicon debug 
		ECF_AMD_XOP			= 1 << 11,// XOP (was also used going to be used for SSE5A)
		ECF_INTEL_FMA		= 1 << 12,// 256-bit FMA extensions ( Fused MultiplyAdd )
		ECF_AMD_SKINIT		= 1 << 12,// SKINIT, STGI, DEV
		ECF_INTEL_CX16      = 1 << 13,// CMPXCHG16B support
		ECF_AMD_WDT			= 1 << 13,// watchdog timer
		ECF_INTEL_ETPRD     = 1 << 14,// xTPR update control
		ECF_AMD_RESERVED1	= 1 << 14,// reserved		
		ECF_INTEL_PDCM      = 1 << 15,// Performance Debug Capability MSR
		ECF_AMD_LWP			= 1 << 15,// LWP		
		ECF_INTEL_RESERVED1 = 1 << 16,// reserved
		ECF_AMD_FMA4		= 1 << 16,// FMA4		
		ECF_INTEL_PCID		= 1 << 17,// CR4.PCIDE
		ECF_AMD_TCE			= 1 << 17,// translation cache extension		
		ECF_INTEL_DCA       = 1 << 18,// Direct Cache Access (that is, the ability to prefetch data from MMIO) also see standard level 0000_0009h
		ECF_AMD_RESERVED2	= 1 << 18,// reserved
		ECF_INTEL_SSE4_1    = 1 << 19,// SSE4.1 extensions1, MXCSR, CR4.OSXMMEXCPT, #XF
		ECF_AMD_NODEID		= 1 << 19,// node ID: MSR C001_100Ch
		ECF_INTEL_SSE4_2    = 1 << 20,// SSE4.2 extensions
		ECF_AMD_RESERVED3	= 1 << 20,// reserved
		ECF_INTEL_X2APIC    = 1 << 21,// x2APIC support, APIC_BASE.EXTD, MSRs 0000_0800h...0000_0BFFh 64-bit ICR (+030h but not +031h), no DFR (+00Eh), SELF_IPI (+040h) also see standard level 0000_000Bh
		ECF_AMD_TBM			= 1 << 21,// TBM
		ECF_INTEL_MOVBE     = 1 << 22,// MOVBE support
		ECF_AMD_TOPX		= 1 << 22,// topology extensions: extended levels 8000_001Dh and 8000_001Eh
		ECF_INTEL_POPCNT    = 1 << 23,// POPCNT instruction support
		ECF_AMD_PCX_CORE	= 1 << 23,// core perf counter extensions (MSRs C001_020[0...B]h)
		ECF_INTEL_TSCD		= 1 << 24,// local APIC supports one-shot operation using TSC deadline value
		ECF_AMD_PCX_NB		= 1 << 24,// NB perf counter extensions (MSRs C001_024[0...7]h)
		ECF_INTEL_AES       = 1 << 25,// AES support
		ECF_AMD_RESERVED4	= 1 << 25,// reserved
		ECF_INTEL_XSAVE     = 1 << 26,// CR4.OSXSAVE, XCRn, XGETBV, XSETBV, XSAVE(OPT), XRSTOR also see standard level 0000_000Dh
		ECF_AMD_DBX			= 1 << 26,// data breakpoint extensions (MSRs C001_1027h and C001_10[19...1B]h)
		ECF_INTEL_OSXSAVE   = 1 << 27,// non-privileged read-only copy of current CR4.OSXSAVE value
		ECF_AMD_PERFTSC		= 1 << 27,// performance TSC (MSR C001_0280h)
		ECF_INTEL_AVX       = 1 << 28,// AVX 256-bit Intel advanced vector extensions
		ECF_AMD_PCX_L2I		= 1 << 28,// L2I perf counter extensions (MSRs C001_023[0...7]h)
		ECF_INTEL_F16C      = 1 << 29,// VCVTPH2PS and VCVTPS2PH
		ECF_AMD_RESERVED5	= 1 << 29,// reserved
		ECF_INTEL_RDRAND    = 1 << 30,// RDRAND
		ECF_AMD_RESERVED6	= 1 << 30,// reserved
		ECF_INTEL_RESERVED2 = 1 << 31, // reserved 
		ECF_AMD_RESERVED7	= 1 << 31// reserved
	};

	const char* const CPUID_IntelFeatureStringsEDX[] =
	{
		"x87 FPU On Chip",					// 0
		"Virtual-8086 Mode Enhancement",	// 1
		"Debugging Extensions",				// 2
		"Page Size Extensions",				// 3
		"Time Stamp Counter",				// 4
		"RDMSR and WRMSR Support",			// 5
		"Physical Address Extensions",		// 6
		"Machine Check Exception",			// 7
		"CMPXCHG8B Instruction",			// 8
		"APIC On Chip",						// 9
		"Unknown1",							// 10
		"SYSENTER and SYSEXIT",				// 11
		"Memory Type Range Registers",		// 12
		"PTE Global Bit",					// 13
		"Machine Check Architecture",		// 14
		"Conditional Move/Compare Instruction",	// 15
		"Page Attribute Table",				// 16
		"Page Size Extension",				// 17
		"Processor Serial Number",			// 18
		"CFLUSH Extension",					// 19
		"Unknown2",							// 20
		"Debug Store",						// 21
		"Thermal Monitor and Clock Ctrl",	// 22
		"MMX Technology",					// 23
		"FXSAVE/FXRSTOR",					// 24
		"SSE Extensions",					// 25
		"SSE2 Extensions",					// 26
		"Self Snoop",						// 27
		"Hyper-threading Technology",		// 28
		"Thermal Monitor",					// 29
		"Unknown4",							// 30
		"Pend. Brk. EN."					// 31
	};

	///@enum CPU features that can be read from EDX register ( as bitflags )
    enum E_CPUID_FEATURE_EDX
	{
        ECF_FPU				= 1 << 0, // x87 FPU on chip, FPU
        ECF_VME				= 1 << 1, // Virtual-8086 mode enhancement, CR4.VME/PVI, EFLAGS.VIP/VIF, TSS32.IRB
        ECF_DE				= 1 << 2, // Debugging extensions, CR4.DE, DR7.RW=10b, #UD on MOV from/to DR4/5
        ECF_PSE				= 1 << 3, // Page size extensions, PDE.PS, PDE/PTE.res, CR4.PSE, #PF(1xxxb)
        ECF_TSC				= 1 << 4, // Time stamp counter, TSC, RDTSC, CR4.TSD (doesn't imply MSR=1)
        ECF_MSR				= 1 << 5, // RDMSR and WRMSR support, MSRs, RDMSR/WRMSR
        ECF_PAE				= 1 << 6, // Physical address extensions, 64-bit PDPTE/PDE/PTEs, CR4.PAE
        ECF_MCE				= 1 << 7, // Machine check exception, MCAR/MCTR MSRs, CR4.MCE, #MC
        ECF_CX8				= 1 << 8, // CMPXCHG8B instruction, Some processors do support CMPXCHG8B, but don't report it by default. This is due to a Windows NT bug.
        ECF_APIC			= 1 << 9, // APIC on chip, If the APIC has been disabled, then the APIC feature flag will read as 0. Early AMD K5 processors (SSA5) inadvertently used this bit to report PGE support.
        ECF_RESERVED1		= 1 << 10,// reserved 
		ECF_SEP				= 1 << 11,// SYSENTER and SYSEXIT, EFER/STAR MSRs #1, The Intel P6 processor does not support SEP, but inadvertently reports it.
        ECF_MTRR			= 1 << 12,// Memory type range registers, MSRs
        ECF_PGE				= 1 << 13,// PTE global bit, CR4.PGE
        ECF_MCA				= 1 << 14,// Machine check architecture, MCG_*/MCn_* MSRs, CR4.MCE, #MC
        ECF_CMOV			= 1 << 15,// Conditional move/compare instruction, CMOVcc, if FPU=1 then also FCMOVcc/F(U)COMI(P)
        ECF_PAT				= 1 << 16,// Page Attribute Table, PAT MSR, PDE/PTE.PAT
 		ECF_AMD_FCMOV		= 1 << 16,// FCMOVcc/F(U)COMI(P) (implies FPU=1) or on AMD K7: PAT MSR, PDE/PTE.PAT
		ECF_PSE36			= 1 << 17,// 36-bit page size extension, 4 MB PDE bits 16...13, CR4.PSE
		ECF_PSN				= 1 << 18,// Processor serial number, PSN (see standard level 0000_0003h), MISC_CTL.PSND, If the PSN has been disabled, then the PSN feature flag will read as 0. In addition the value for the maximum supported standard level (reported by standard level 0000_0000h, register EAX) will be lower.
		ECF_AMD_RESERVED8	= 1 << 18,// reserved
		ECF_CLFL			= 1 << 19,// CLFLUSH
		ECF_AMD_MP			= 1 << 19,// MP-capable #3
		ECF_RESERVED2		= 1 << 20,// reserved
		ECF_AMD_NX			= 1 << 20,// EFER.NXE, P?E.NX, #PF(1xxxx)
		ECF_DTES			= 1 << 21,// Debug store, Debug Trace and EMON Store MSRs
		ECF_AMD_RESERVED9	= 1 << 21,// reserved
		ECF_ACPI			= 1 << 22,// Thermal monitor and clock control, THERM_CONTROL MSR
		ECF_AMD_MMXP		= 1 << 22,// MMX+, AMD specific: MMX-SSE and SSE-MEM
		ECF_MMX				= 1 << 23,// MMX technology ( 64bit register )
		ECF_FXSR			= 1 << 24,// FXSAVE/FXRSTOR, CR4.OSFXSR, Cyrix specific: extended MMX
		ECF_SSE				= 1 << 25,// SSE extensions, MXCSR, CR4.OSXMMEXCPT, #XF
		ECF_AMD_FFXSR		= 1 << 25,// EFER.FFXSR
		ECF_SSE2			= 1 << 26,// SSE2 extensions, MXCSR, CR4.OSXMMEXCPT, #XF
		ECF_AMD_PG1G		= 1 << 26,// PML3E.PS
		ECF_SS				= 1 << 27,// Self snoop
		ECF_AMD_TSCP		= 1 << 27,// TSC, TSC_AUX, RDTSCP, CR4.TSD
		ECF_HTT				= 1 << 28,// Hyper-Threading Technology, PAUSE
		ECF_AMD_MULTICORE	= 1 << 28,// With the AMD chipset, all multi-core AMD CPUs set bit 28 of the feature information bits to indicate that the chip has more than one core.
		ECF_TM				= 1 << 29,// Thermal monitor MISC_ENABLE.TM1E THERM_INTERRUPT and THERM_STATUS MSRs xAPIC thermal LVT entry
		ECF_AMD_LM			= 1 << 29,// AMD64/EM64T, Long Mode
		ECF_IA64			= 1 << 30,// IA-64, JMPE Jv, JMPE Ev
		ECF_AMD_3DNOWEX		= 1 << 30,// extended 3DNow!
		ECF_PBE				= 1 << 31,// Pending Break Event enable, STPCLK, FERR#, MISC_ENABLE.PBE
		ECF_AMD_3DNOW2		= 1 << 31// 3DNow!
    };

	enum E_CPU_VENDOR
	{
		ECV_UNKNOWN=0,
		ECV_INTEL,
		ECV_AMD,
		ECV_CYRIX,
		ECV_VIA,
		ECV_TRANSMETA,
		ECV_SIS,
		ECV_UMC,
		ECV_ARM
	};

	///@enum CPU Type
	enum E_CPU_TYPE
	{
		ECPU_UNKNOWN=0,
		ECPU_I386,
		ECPU_I486,
		ECPU_I586,
		ECPU_I686,
		ECPU_AMD64,
		ECPU_ARM32,
		ECPU_ARM64,
		ECPU_POWER64,
		ECPU_IA64,
		ECPU_MMX,
		ECPU_3DNOW,
		ECPU_SSE1,
		ECPU_SSE2,
		ECPU_SSE3,
		ECPU_SSE4,
		ECPU_COUNT
	};

	///@class CPU
	class CCPU
	{
	public:
		//============================================================================================/
		// Benni's functions using Instrinsics ( plattform independant assembler !!! )
		// working for all platforms and CPUs that have intrinsics
		//============================================================================================
		
		static f32 getProcessTime(); 

		static bool hasCPUID();
		static bool CPUID( E_CPUID_REQUEST request, u32& eax, u32& ebx, u32& ecx, u32& edx );

		static E_CPU_TYPE getType();
		static irr::core::stringc getNameString();
		static irr::core::stringc getFlagString();
		static irr::core::stringc getVendorString();

		// Return the usage-level of CPU(s) in percent, 
		// seems like it is stored in registry 1000 times a second ( wtf )
		static s32 getUsage();

		static u32 getSpeedMhz();

		static u32 getCoreCount();

		static u32 getThreadCount();


		static E_CPU_VENDOR getVendor();
		static bool isVendor( E_CPU_VENDOR vend );
		static bool isVendorIntel();
		static bool isVendorAMD();
		static bool isVendorCyrix();
		static bool isVendorVIA();
		static bool isVendorTransmeta();
		static bool isVendorSIS();
		static bool isVendorUMC();
		static bool isVendorARM();

		static bool hasMMX();
		static bool hasAddressExt();
		static bool hasCMOV();
		static bool hasCMPXCHG8B();
		static bool hasException();
		static bool has36BitPageSizeExt();
		static bool hasMSR();
		static bool hasTSC();
		static bool hasPageSizeExt();
		static bool hasHWBreakPoints();
		static bool hasVirt8086();
		static bool hasFPU();


		// static u32 getFlagsECX();

		//static u32 getFlagsEDX();


		static u32 getNanometers();
		static u32 getTransistors();
		static u32 getMaxTDP();
		static u32 getCacheSize();
		static u32 getCacheSizeL1();
		static u32 getCacheSizeL2();
		static u32 getCacheSizeL3();

		static irr::core::stringc dumpRegister();
		static irr::core::stringc dump();

		//============================================================================================
		// Ronald's functions that use pure x86 assembler ( Intel Syntax like MASM )
		// and don't work for all CPUs other than Intel (x86) Architecture
		//============================================================================================

		static u32 getRonaldType();
		static u64 getCycles();		// micro-sekunden 10^-6
		static u32 getMode();		
		static u32 getFeatures();

	};

	//============================================================================================
	//=== OS Commands
	//============================================================================================

	///@enum Operating System Type
	enum E_OS_TYPE
	{
		EOS_UNKNOWN=0,
		EOS_POSIX,
		EOS_MACOSX,
		EOS_WIN_95,
		EOS_WIN_98,
		EOS_WIN_ME,
		EOS_WIN_9X,
		EOS_WIN_NT3,
		EOS_WIN_NT4,
		EOS_WIN_2000,
		EOS_WIN_XP,
		EOS_WIN_2003,
		EOS_WIN_VISTA,
		EOS_WIN_NT,
		EOS_WIN_NT_NEW,
		EOS_WIN_NT_WDM,
		EOS_WIN_7,
		EOS_WIN_71,
		EOS_WIN_8,
		EOS_WIN_81,
		EOS_COUNT
	};

	///@class Operating System
	class COperatingSystem
	{
	public:

		#if defined(BPM_OS_WINDOWS)
		
		typedef BOOL (WINAPI *LPFN_ISWOW64PROCESS) (HANDLE, PBOOL);

		#endif

		static bool is64Bit();

		static E_OS_TYPE getType();

		static bool isWin95();

		static bool isWin98();

		static bool isWinME();

		static bool isWinNT();

		static bool isWinNT4();

		static bool isWin2K();

		static bool isWin2K3();

		static bool isWinXP();

		static bool isWinVista();

		static bool isWin7();

		static bool isAdministrator( bool NeedFullVistaRights );

		static irr::core::stringc getName();
		
		static irr::core::stringc getVendor();

		/// Monitor

		// static u32 getMonitorCount();

		// static u32 getMonitorRefreshRateHz( u32 index = 0 );

		// static u32 getMonitorWidth( u32 index = 0 );

		// static u32 getMonitorHeight( u32 index = 0 );

		// static s32 getMonitorDepth( u32 index = 0 );

		/// Desktop
		
		static u32 getDesktopWidth();

		static u32 getDesktopHeight();

		static s32 getDesktopDepth();

		/// Screen ( Current Render Target )
		
		//static u32 getScreenWidth();

		//static u32 getScreenHeight();

		//static s32 getScreenDepth();

	};


#ifdef BPM_USE_WX_GUI

	void test_BPM_Utils( wxListBox* out );

#endif

} // end namespace bpm

#endif // BPM6_OS_DETECTION_H_INCLUDED
