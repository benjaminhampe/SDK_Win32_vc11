// Copyright (C) 2002-2014 Benjamin Hampe
// This file is part of the "irrlicht-engine"
// For conditions of distribution and use, see copyright notice in irrlicht.h

#ifndef BPM6_MATH_H_INCLUDED
#define BPM6_MATH_H_INCLUDED

namespace bpm
{
	template <class T>
	T abs( T value )
	{
		return (value<(T)0) ? (-value) : (value);
	}


} // end namespace bpm

#endif // BPM6_MATH_H_INCLUDED
