#include "MMUtils.h"

//
//
//implementation
//
//uses
//    MMSystem,
//    MMString,
//    MMSearch,
//    MMMulDiv,
//    MMMath,
//    MMInt64
//    {$IFDEF _MMDEBUG_}
//    ,MMDebug
//    {$ENDIF}
//    ;
//
//{$IFNDEF WIN32}
//{=========================================================================}
//procedure MoveWindowOrg(DC: HDC; DX, DY: Integer);
//var
//  P: TPoint;
//
//begin
//   GetWindowOrgEx(DC, @P);
//   SetWindowOrgEx(DC, P.X - DX, P.Y - DY, nil);
//end;
//{$ELSE}
//
//var
//   TransSection: TRTLCriticalSection;
//   _GetDiskFreeSpaceEx: function (Directory: PChar; var FreeAvailable,
//                                  TotalSpace: Int64;
//                                  TotalFree: PInt64): Bool stdcall = nil;
//
//{=========================================================================}
//function MMSetThreadPriority(hThread: THandle; nPriority: integer): Boolean;
//begin
//   Result := SetThreadPriority(hThread,nPriority);
//end;
//
//{=========================================================================}
//procedure DeleteRegistryValue(_RootKey:HKEY;_Localkey,_Field:string);
//begin
//   try
//      {$IFNDEF DELPHI5}
//      with TRegistry.CreateWithAccess(GetRegAccessMode(_LocalKey,KEY_ALL_ACCESS)) do
//      {$ELSE}
//      with TRegistry.Create(GetRegAccessMode(_LocalKey,KEY_ALL_ACCESS)) do
//      {$ENDIF}
//      try
//         RootKey := _RootKey;
//
//         if OpenKey(_Localkey,False) then
//            DeleteValue(_Field);
//
//         CloseKey;
//
//      finally
//         Free;
//      end;
//   except
//   end;
//end;
//
//{=========================================================================}
//procedure SaveInRegistry(_RootKey:HKEY;_Localkey,_Field:string;Value:Variant);
//begin
//   try
//      {$IFNDEF DELPHI5}
//      with TRegistry.CreateWithAccess(GetRegAccessMode(_LocalKey,KEY_ALL_ACCESS)) do
//      {$ELSE}
//      with TRegistry.Create(GetRegAccessMode(_LocalKey,KEY_ALL_ACCESS)) do
//      {$ENDIF}
//      try
//         RootKey := _RootKey;
//
//         if OpenKey(_Localkey,True) then
//         try
//            case VarType(Value) of
//               varByte,
//               varNull,
//               varInteger,
//               {$IFDEF DELPHI6}
//               varShortInt,
//               varWord,
//               varError,
//               {$ENDIF}
//               varSmallint: WriteInteger (_Field,Value);
//               {$IFDEF DELPHI2009}
//               varUInt64,
//               {$ENDIF}
//               {$IFDEF DELPHI6}
//               varInt64   : WriteString(_Field,IntToStr(Value));
//               varLongWord: WriteString(_Field,IntToStr(Int64(TVarData(Value).VLongWord)));
//               {$ENDIF}
//               varSingle,
//               varDouble  : WriteFloat   (_Field,Value);
//               varCurrency: WriteCurrency(_Field,Value);
//               varDate    : WriteDateTime(_Field,Value);
//               varBoolean : WriteBool    (_Field,Value);
//               varString,
//               {$IFDEF UNICODE}
//               varUString,
//               {$ENDIF}
//               varOleStr  : WriteString  (_Field,Value);
//               else raise Exception.CreateFmt('Unknown VarType: $%x',[VarType(Value)]);
//            end;
//         finally
//             CloseKey;
//         end;
//
//      finally
//         Free;
//      end;
//   except
//   end;
//end;
//
//{=========================================================================}
//procedure SaveInRegistryBinary(_RootKey:HKEY;_Localkey,_Field:string;var Buffer; BufSize: integer);
//begin
//   try
//      if (BufSize > 0) then
//      begin
//         {$IFNDEF DELPHI5}
//         with TRegistry.CreateWithAccess(GetRegAccessMode(_LocalKey,KEY_ALL_ACCESS)) do
//         {$ELSE}
//         with TRegistry.Create(GetRegAccessMode(_LocalKey,KEY_ALL_ACCESS)) do
//         {$ENDIF}
//         try
//            RootKey := _RootKey;
//
//            OpenKey(_Localkey,True);
//            WriteBinaryData(_Field,Buffer,BufSize);
//            CloseKey;
//
//         finally
//             Free;
//         end;
//      end;
//   except
//   end;
//end;
//
//{=========================================================================}
//function GetFromRegistry(_RootKey:HKEY;_Localkey,_Field:String;Value:Variant): Variant;
//begin
//   Result := Value;
//   try
//      {$IFNDEF DELPHI5}
//      with TRegistry.CreateWithAccess(GetRegAccessMode(_LocalKey,KEY_READ)) do
//      {$ELSE}
//      with TRegistry.Create(GetRegAccessMode(_LocalKey,KEY_READ)) do
//      {$ENDIF}
//      try
//         RootKey := _RootKey;
//
//         if OpenKeyReadOnly(_Localkey) then
//         begin
//            if ValueExists(_Field) then
//            case VarType(Value) of
//                varByte,
//                varNull,
//                varInteger,
//                {$IFDEF DELPHI6}
//                varShortInt,
//                varWord,
//                varError,
//                {$ENDIF}
//                varSmallint: Result := ReadInteger(_Field);
//                {$IFDEF DELPHI2009}
//                varUInt64,
//                {$ENDIF}
//                {$IFDEF DELPHI6}
//                varInt64,
//                varLongWord: Result := StrToInt64(ReadString(_Field));
//                {$ENDIF}
//                varSingle,
//                varDouble  : Result := ReadFloat   (_Field);
//                varCurrency: Result := ReadCurrency(_Field);
//                varDate    : Result := ReadDateTime(_Field);
//                varBoolean : Result := ReadBool    (_Field);
//                varString,
//                {$IFDEF UNICODE}
//                varUString,
//                {$ENDIF}
//                varOleStr  : Result := ReadString  (_Field);
//                else raise Exception.CreateFmt('Unknown VarType: $%x',[VarType(Value)]);
//            end;
//            CloseKey;
//         end;
//
//      finally
//         Free;
//      end;
//   except
//   end;
//end;
//
//{=========================================================================}
//function GetFromRegistryBinary(_RootKey:HKEY;_Localkey,_Field:string;var Buffer; BufSize: integer): integer;
//begin
//   Result := 0;
//   try
//      {$IFNDEF DELPHI5}
//      with TRegistry.CreateWithAccess(GetRegAccessMode(_LocalKey,KEY_READ)) do
//      {$ELSE}
//      with TRegistry.Create(GetRegAccessMode(_LocalKey,KEY_READ)) do
//      {$ENDIF}
//      try
//         RootKey := _RootKey;
//
//         if OpenKeyReadOnly(_Localkey) then
//         begin
//            if ValueExists(_Field) then
//            begin
//               if (BufSize = 0) then
//                   Result := GetDataSize(_Field)
//               else
//                   Result := ReadBinaryData(_Field,Buffer,BufSize);
//            end;
//            CloseKey;
//         end;
//
//      finally
//         Free;
//      end;
//   except
//   end;
//end;
//
//{=========================================================================}
//procedure MoveRegistryKey(_RootKey:HKEY;OldKey,NewKey: string; Delete: Boolean);
//begin
//   try
//      with TRegistry.Create do
//      try
//         RootKey := _RootKey;
//
//         MoveKey(OldKey, NewKey, Delete);
//      finally
//         Free;
//      end;
//   except
//   end;
//end;
//
//{=========================================================================}
//procedure DeleteRegistryKey(_RootKey:HKEY;Key:string);
//begin
//   try
//      {$IFNDEF DELPHI5}
//      with TRegistry.CreateWithAccess(GetRegAccessMode(Key,KEY_ALL_ACCESS)) do
//      {$ELSE}
//      with TRegistry.Create(GetRegAccessMode(Key,KEY_ALL_ACCESS)) do
//      {$ENDIF}
//      try
//         RootKey := _RootKey;
//
//         DeleteKey(Key);
//      finally
//         Free;
//      end;
//   except
//   end;
//end;
//
//{=========================================================================}
//function GetCPUUsage: integer;
//var
//   TempKey: HKEY;
//   DataType,BufSize,Dummy: integer;
//
//begin
//   Result := 0;
//   if _WIN9x_ or _WINNT_NEW_ then
//   begin
//      TempKey := 0;
//      { start measuring }
//      if RegOpenKeyEx(HKEY_DYN_DATA, 'PerfStats\StartStat', 0,
//                      KEY_ALL_ACCESS, TempKey) <> ERROR_SUCCESS then exit;
//
//      DataType := REG_NONE;
//      BufSize := sizeOf(integer);
//      if RegQueryValueEx(TempKey, 'KERNEL\CPUUsage', nil, @DataType,
//                         @Dummy, @BufSize) <> ERROR_SUCCESS then exit;
//
//      RegCloseKey(TempKey);
//
//      { get the value }
//      if RegOpenKeyEx(HKEY_DYN_DATA, 'PerfStats\StatData', 0,
//                      KEY_ALL_ACCESS, TempKey) <> ERROR_SUCCESS then exit;
//
//      RegCloseKey(TempKey);
//
//      DataType := REG_NONE;
//      BufSize := sizeOf(integer);
//      if RegQueryValueEx(TempKey, 'KERNEL\CPUUsage', nil, @DataType,
//                         @Result, @BufSize) <> ERROR_SUCCESS then exit;
//
//      RegCloseKey(TempKey);
//
//      { stop measuring }
//      if RegOpenKeyEx(HKEY_DYN_DATA, 'PerfStats\StopStat', 0,
//                      KEY_ALL_ACCESS, TempKey) <> ERROR_SUCCESS then exit;
//
//      DataType := REG_NONE;
//      BufSize := sizeOf(integer);
//      if RegQueryValueEx(TempKey, 'KERNEL\CPUUsage', nil, @DataType,
//                         @Dummy, @BufSize) <> ERROR_SUCCESS then exit;
//
//      RegCloseKey(TempKey);
//   end;
//end;
//
//{=========================================================================}
//function GetShortFileName(const FileName: TFileName): string;
//var
//   Buf: array[0..MAX_PATH] of Char;
//begin
//   GetShortPathName(PChar(FileName),Buf,sizeOf(Buf));
//   Result := StrPas(Buf);
//end;
//
//{=========================================================================}
//{ Returns:                                                                }
//{  0 = 8086/88,80286,80386,80486                                          }
//{  1 = Pentium(R) Processor                                               }
//{  2 = PentiumPro(R) Processor                                            }
//{  3 or higher = Processor beyond the PentiumPro(R) Processor            }
//{                                                                         }
//{=========================================================================}
//function GetCPUType: integer;
//var
//   stepping: Byte;
//   model: Byte;
//
//begin
//   Result := 0;
//{$IFDEF WIN32}
//   asm
//      pushad
//      pushfd
//
//      { look if cpuid is supported }
//      pushfd			// Get original EFLAGS
//      pop    eax
//
//      mov    ecx, eax
//      xor    eax, 200000h	// Flip ID bit in EFLAGS
//      push   eax		// Save new EFLAGS value on
//      				//   stack
//      popfd			// Replace current EFLAGS value
//
//      pushfd			// Get new EFLAGS
//      pop     eax		// Store new EFLAGS in EAX
//
//      xor     eax, ecx		// Can not toggle ID bit,
//      jz      @@exit		// Processor=80486
//
//      mov     eax, 1
//
//      db      $0F
//      db      $a2		// Get family/model/stepping/
//        			//   features
//      mov     stepping, al
//      and     stepping, $F
//
//      and     al, $F0
//      shr     al, 4
//      mov     model, al
//
//      and     eax, $F00
//      shr     eax, 8		// Isolate family
//      and     eax, $F
//      sub     eax, 4
//      mov     Result, eax	// Set _cpu_type with family
//
//   @@exit:
//
//      popfd
//      popad
//   end;
//{$ENDIF}
//end;
//
//{=========================================================================}
//function Min64(a, b: int64): int64;
//begin
//   if a > b then Result := b
//   else Result := a;
//end;
//
//{=========================================================================}
//function Max64(a, b: int64): int64;
//begin
//   if a > b then Result := a
//   else Result := b;
//end;
//
//{=========================================================================}
//function MinMax64(X, Min, Max: int64): int64;
//begin
//   if (X < Min) then X := Min
//   else if (X > Max) then X := Max;
//   Result := X;
//end;
//
//{=========================================================================}
//function InMinMax64(X,Min,Max: int64): Boolean;
//begin
//   { if Min > Max then Result is never true }
//   if (X < Min) then Result := False
//   else if (X > Max) then Result := False
//   else Result := True;
//end;
//
//{=========================================================================}
//function Sign(Value: Longint): Longint;
//begin
//   if (Value > 0) then
//       Result := 1
//   else if (Value < 0) then
//       Result := -1
//   else
//       Result := Value;
//end;
//
//{=========================================================================}
//function SwapWord(const aValue: Word): Word;
//begin
//   Result := ((aValue shl 8) and $FF00) or ((aValue shr 8) and $00FF);
//end;
//
//{=========================================================================}
//function SwapDWord(const aValue: DWord): DWord;
//begin
//  Result := ((aValue shl 24) and $FF000000) or
//            ((aValue shl  8) and $00FF0000) or
//            ((aValue shr  8) and $0000FF00) or
//            ((aValue shr 24) and $000000FF);
//end;
//
//{$IFNDEF DELPHI5}
//{=========================================================================}
//procedure FreeAndNil(var Obj);
//var
//  Temp: TObject;
//begin
//  Temp := TObject(Obj);
//  Pointer(Obj) := nil;
//  Temp.Free;
//end;
//{$ENDIF}
//
//{=========================================================================}
//{ Current flag assignment is as follows:                                  }
//{                                                                         }
//{		bit23=1     CPU has MMX extension                         }
//{		bit15=1     CMOV instruction supported                    }
//{		bit9 =1     CPU contains a local APIC (iPentium-3V)       }
//{		bit8 =1     CMPXCHG8B instruction supported               }
//{		bit7 =1     machine check exception supported             }
//{		bit6 =0     reserved (36bit-addressing & 2MB-paging)      }
//{		bit5 =1     iPentium-style MSRs supported                 }
//{		bit4 =1     time stamp counter TSC supported              }
//{		bit3 =1     page size extensions supported                }
//{		bit2 =1     I/O breakpoints supported                     }
//{		bit1 =1     enhanced virtual 8086 mode supported          }
//{		bit0 =1     CPU contains a floating-point unit (FPU)      }
//{=========================================================================}
//function GetCPUFeatures: Longint;
//begin
//   Result := 0;
//{$IFDEF WIN32}
//   asm
//      pushad
//      pushfd
//
//      { look if cpuid is supported }
//      pushfd			// Get original EFLAGS
//      pop    eax
//      mov    ecx, eax
//      xor    eax, 200000h	// Flip ID bit in EFLAGS
//      push   eax		// Save new EFLAGS value on
//      				//   stack
//      popfd			// Replace current EFLAGS value
//      pushfd			// Get new EFLAGS
//      pop     eax		// Store new EFLAGS in EAX
//      xor     eax, ecx		// Can not toggle ID bit,
//      jz      @@exit		// Processor=80486
//
//      mov     eax, 1
//
//      db      $0F
//      db      $a2		// Get family/model/stepping/
//        			//   features
//      mov     Result, edx
//
//   @@exit:
//
//      popfd
//      popad
//   end;
//{$ENDIF}
//end;
//
//{=========================================================================}
//{ Returns:                                                                }
//{  0 = Pentium(R) Processor                                               }
//{  1 = PentiumPro(R) Processor                                            }
//{  2 = MMX Extension                                                      }
//{=========================================================================}
//function GetCPUMode: integer;
//begin
//   if _USECPUEXT_ then
//   begin
//      if _MMX_ then
//         Result := 2
//      else if _CPU_ > PENTIUM then
//         Result := 1
//      else
//         Result := 0;
//   end
//   else Result := 0;
//end;
//
//{=========================================================================}
//function GetCPUCycles: int64;
//asm
//{$IFDEF WIN32}
//      db      00fh              //RDTSC
//      db      031h
//      {$IFNDEF DELPHI4}
//      mov     TLargeInteger(Result).HighPart,edx
//      mov     TLargeInteger(Result).LowPart,eax
//      {$ENDIF}
//{$ENDIF}
//end;
//
//var
//   TimeCount: Longint;
//   OldTime,TimeMin,TimeMax,TimeAvg: int64;
//
//{=========================================================================}
//procedure InitTimeMeasure;
//begin
//   TimeCount:= 0;
//   TimeMin  := MAXLONGINT;
//   TimeMax  := 0;
//   TimeAvg  := 0;
//end;
//
//{=========================================================================}
//procedure StartTimeMeasure;
//begin
//   inc(TimeCount);
//   OldTime := TimeGetExactTime;
//end;
//
//{=========================================================================}
//function StopTimeMeasure(Scale: integer): string;
//var
//   CurTime: int64;
//begin
//   CurTime := TimeGetExactTime-OldTime;
//
//   if (CurTime < TimeMin) then TimeMin := CurTime;
//   if (CurTime > TimeMax) then TimeMax := CurTime;
//   TimeAvg := TimeAvg+CurTime;
//
//   if Scale < 1 then Scale := 1;
//
//   Result := Format('Time:  Cur: %f  Min: %f  Max: %f  Avg: %f',[CurTime,
//                                                                 TimeMin/Scale,
//                                                                 TimeMax/Scale,
//                                                                 (TimeAvg/TimeCount)/Scale]);
//end;
//
//var
//   CycleCount: Longint;
//   OldCycles,CyclesMin,CyclesMax,CyclesAvg: int64;
//
//{=========================================================================}
//procedure InitCyclesMeasure;
//begin
//   CycleCount := 0;
//   CyclesMin  := MAXLONGINT;
//   CyclesMax  := 0;
//   CyclesAvg  := 0;
//end;
//
//{=========================================================================}
//procedure StartCyclesMeasure;
//begin
//   inc(CycleCount);
//   OldCycles := GetCPUCycles;
//end;
//
//{=========================================================================}
//function StopCyclesMeasure(Scale: integer): string;
//var
//   CurCycles: int64;
//begin
//   CurCycles := GetCPUCycles-OldCycles;
//
//   if (CurCycles < CyclesMin) then CurCycles := CyclesMin;
//   if (CurCycles > CyclesMax) then CurCycles := CyclesMax;
//   CyclesAvg := CyclesAvg+CurCycles;
//
//   if Scale < 1 then Scale := 1;
//
//   Result := Format('CPU-Cycles:  Min: %f Max: %f Avg: %f',[CyclesMin/Scale,
//                                                            CyclesMax/Scale,
//                                                            (CyclesAvg/CycleCount)/Scale]);
//end;
//{$ENDIF}
//
//const
//     Freq: Cardinal = 0;
//
//{=========================================================================}
//function TimeGetExactTime: int64;
//{$IFDEF WIN32}
//var
//   {$IFDEF DELPHI4}
//   CurTime: int64;
//   {$ELSE}
//   CurTime: MMLARGE_INTEGER;
//   {$ENDIF}
//{$ENDIF}
//
//begin
//   { returns system time in micro second }
//{$IFDEF WIN32}
//   if (Freq = 0) then
//   begin
//      QueryPerformanceFrequency(CurTime);           { determine timer frequency }
//      {$IFDEF DELPHI4}
//      if (Curtime shr 32 > 0) then
//          Freq := 1                                 { timer is too fast }
//      else
//          Freq := CurTime and $FFFFFFFF;            { ticks per second }
//      {$ELSE}
//      if (Curtime.HighPart > 0) then
//          Freq := 1                                 { timer is too fast }
//      else
//          Freq := CurTime.LowPart;                  { ticks per second }
//      {$ENDIF}
//   end;
//
//   if (abs(Freq) > 1) then
//   begin
//      QueryPerformanceCounter(CurTime);
//      {$IFDEF DELPHI4}
//      Result := (1000000 * CurTime) div Freq;
//      {$ELSE}
//      asm
//         push    CurTime.HighPart
//         push    CurTime.LowPart
//         push    0
//         push    1000000;
//         call    int64x64
//
//         push    Freq
//         push    edx
//         push    eax
//         call    int64Div32
//
//         mov     dword ptr Result[0], eax
//         mov     dword ptr Result[4], edx
//      end;
//      {$ENDIF}
//   end
//   else
//{$ENDIF}
//   begin
//      { on Win16 we must return the time in a 1000 micro second raster }
//      Result := 1000;
//      Result := Result * TimeGetTime;
//   end;
//end;
//
//{=========================================================================}
//function HaveWin95: Boolean;
//{$IFDEF WIN32}
//var
//   OS: TOSVERSIONINFO;
//begin
//   OS.dwOSVersionInfoSize := sizeOf(OS);
//   GetVersionEx(OS);
//   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_WINDOWS) and
//             (OS.dwMajorVersion = 4) and (OS.dwMinorVersion = 0);
//{$ELSE}
//begin
//   Result:=(GetVersion and $FF = 3)and((GetVersion shr 8)and $FF=95);
//{$ENDIF}
//end;
//
//{=========================================================================}
//function HaveWin98: Boolean;
//{$IFDEF WIN32}
//var
//   OS: TOSVERSIONINFO;
//begin
//   OS.dwOSVersionInfoSize := sizeOf(OS);
//   GetVersionEx(OS);
//   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_WINDOWS) and
//             (OS.dwMajorVersion = 4) and (OS.dwMinorVersion = 10);
//{$ELSE}
//begin
//   Result:=(GetVersion and $FF = 3)and((GetVersion shr 8)and $FF=95);
//{$ENDIF}
//end;
//
//{=========================================================================}
//function HaveWinME: Boolean;
//{$IFDEF WIN32}
//var
//   OS: TOSVERSIONINFO;
//begin
//   OS.dwOSVersionInfoSize := sizeOf(OS);
//   GetVersionEx(OS);
//   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_WINDOWS) and
//             (OS.dwMajorVersion = 4) and (OS.dwMinorVersion = 90);
//{$ELSE}
//begin
//   Result:=(GetVersion and $FF = 3)and((GetVersion shr 8)and $FF=95);
//{$ENDIF}
//end;
//
//{=========================================================================}
//function HaveWinNT: Boolean;
//{$IFDEF WIN32}
//var
//   OS: TOSVERSIONINFO;
//begin
//   OS.dwOSVersionInfoSize := sizeOf(OS);
//   GetVersionEx(OS);
//   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_NT) and
//             (OS.dwMajorVersion = 3);
//{$ELSE}
//begin
//   Result := (GetWinFlags and $4000) <> 0;
//{$ENDIF}
//end;
//
//{=========================================================================}
//function HaveWinNT4: Boolean;
//{$IFDEF WIN32}
//var
//   OS: TOSVERSIONINFO;
//begin
//   OS.dwOSVersionInfoSize := sizeOf(OS);
//   GetVersionEx(OS);
//   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_NT) and
//             (OS.dwMajorVersion = 4);
//{$ELSE}
//begin
//   Result := (GetWinFlags and $4000) <> 0;
//{$ENDIF}
//end;
//
//{=========================================================================}
//function HaveWin2K: Boolean;
//{$IFDEF WIN32}
//var
//   OS: TOSVERSIONINFO;
//begin
//   OS.dwOSVersionInfoSize := sizeOf(OS);
//   GetVersionEx(OS);
//   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_NT) and
//             (OS.dwMajorVersion = 5) and (OS.dwMinorVersion = 0);
//{$ELSE}
//begin
//   Result := (GetWinFlags and $4000) <> 0;
//{$ENDIF}
//end;
//
//{=========================================================================}
//function HaveWin2K3: Boolean;
//{$IFDEF WIN32}
//var
//   OS: TOSVERSIONINFO;
//begin
//   OS.dwOSVersionInfoSize := sizeOf(OS);
//   GetVersionEx(OS);
//   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_NT) and
//             (OS.dwMajorVersion = 5) and (OS.dwMinorVersion = 2);
//{$ELSE}
//begin
//   Result := (GetWinFlags and $4000) <> 0;
//{$ENDIF}
//end;
//
//{=========================================================================}
//function HaveWinXP: Boolean;
//{$IFDEF WIN32}
//var
//   OS: TOSVERSIONINFO;
//begin
//   OS.dwOSVersionInfoSize := sizeOf(OS);
//   GetVersionEx(OS);
//   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_NT) and
//             (OS.dwMajorVersion = 5) and (OS.dwMinorVersion = 1);
//{$ELSE}
//begin
//   Result := (GetWinFlags and $4000) <> 0;
//{$ENDIF}
//end;
//
//{=========================================================================}
//function HaveWinVista: Boolean;
//var
//   OS: TOSVERSIONINFO;
//begin
//   OS.dwOSVersionInfoSize := sizeOf(OS);
//   GetVersionEx(OS);
//   Result := ((OS.dwPlatformID = VER_PLATFORM_WIN32_NT) and
//              (OS.dwMajorVersion = 6) and (OS.dwMinorVersion = 0)) or
//             // detect Vista even in compatiblity mode
//             assigned(GetProcAddress(GetModuleHandle('kernel32.dll'),'GetProductInfo'));
//end;
//
//{=========================================================================}
//function HaveWindows7: Boolean;
//var
//   OS: TOSVERSIONINFO;
//begin
//   OS.dwOSVersionInfoSize := sizeOf(OS);
//   GetVersionEx(OS);
//   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_NT) and
//             ((OS.dwMajorVersion = 6) and (OS.dwMinorVersion >= 1));
//end;
//
//{=========================================================================}
//function HaveAfterWinVista: Boolean;
//var
//   OS: TOSVERSIONINFO;
//begin
//   OS.dwOSVersionInfoSize := sizeOf(OS);
//   GetVersionEx(OS);
//   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_NT) and
//             ((OS.dwMajorVersion > 6) or ((OS.dwMajorVersion = 6) and (OS.dwMinorVersion > 0)));
//end;
//
//{=========================================================================}
//function HaveAfterWin7: Boolean;
//var
//   OS: TOSVERSIONINFO;
//begin
//   OS.dwOSVersionInfoSize := sizeOf(OS);
//   GetVersionEx(OS);
//   Result := (OS.dwPlatformID = VER_PLATFORM_WIN32_NT) and
//             ((OS.dwMajorVersion > 6) or ((OS.dwMajorVersion = 6) and (OS.dwMinorVersion > 1)));
//end;
//
//{=========================================================================}
//function Is64BitWindows: Boolean;
//type
//   TIsWow64Process = function(Handle: THandle; var Res: BOOL): BOOL; stdcall;
//var
//   IsWow64Result: BOOL;
//   IsWow64Process: TIsWow64Process;
//begin
//  Result := False;
//
//  // Try to load required function from kernel32
//  IsWow64Process := Windows.GetProcAddress(GetModuleHandle('kernel32'), 'IsWow64Process');
//  if assigned(IsWow64Process) then
//  begin
//     // Function is implemented: call it
//     if IsWow64Process(GetCurrentProcess, IsWow64Result) then
//        // Return result of function
//        Result := IsWow64Result;
//  end
//  else
//     ; // Function not implemented: can't be running on Wow64
//end;
//
//{=========================================================================}
//function IsRunningVirtualPC: Boolean;
//asm
//   push ebp
//   mov ebp, esp
//   mov ecx, offset @exception_handler
//
//   push ebx
//   push ecx
//
//   push dword ptr fs:[0]
//   mov dword ptr fs:[0], esp
//
//   mov ebx, 0                    // Flag
//   mov eax, 1                    // VPC function number
//
//   db $0F, $3F, $07, $0B         // call VPC
//
//   mov eax, dword ptr ss:[esp]
//   mov dword ptr fs:[0], eax
//
//   add esp, 8
//
//   xor  eax, eax
//   
//   test ebx, ebx
//
//   setz al
//
//   lea esp, dword ptr ss:[ebp-4]
//   mov ebx, dword ptr ss:[esp]
//   mov ebp, dword ptr ss:[esp+4]
//
//   add esp, 8
//
//   jmp @ret1
//
//@exception_handler:
//
//   mov ecx, [esp+0Ch];
//   mov dword ptr [ecx+0A4h], -1; // EBX = -1 ->; not running, ebx = 0 -> running
//
//   add dword ptr [ecx+0B8h], 4;  // ->; skip past the call to VPC
//   xor eax, eax;                 // exception is handled
//@ret1:
//end;
//
//{=========================================================================}
//// got it from: http://community.borland.com/article/0,1410,26752,00.html
//function IsAdministrator(NeedFullVistaRights: Boolean): Boolean;
//const
//  SECURITY_NT_AUTHORITY: TSIDIdentifierAuthority = (Value: (0, 0, 0, 0, 0, 5));
//  SECURITY_BUILTIN_DOMAIN_RID = $00000020;
//  DOMAIN_ALIAS_RID_ADMINS     = $00000220;
//
//var
//  hAccessToken: THandle;
//  ptgGroups: PTokenGroups;
//  dwInfoBufferSize: DWORD;
//  psidAdministrators: PSID;
//  x: Integer;
//  bSuccess: BOOL;
//  hService: THandle;
//begin
//   Result := False;
//
//   bSuccess := OpenThreadToken(GetCurrentThread, TOKEN_QUERY, True, hAccessToken);
//
//   if not bSuccess then
//   begin
//      if (GetLastError = ERROR_NO_TOKEN) then
//          bSuccess := OpenProcessToken(GetCurrentProcess, TOKEN_QUERY,hAccessToken);
//   end;
//
//   if bSuccess then
//   begin
//      GetMem(ptgGroups, 1024);
//      bSuccess := GetTokenInformation(hAccessToken, TokenGroups, ptgGroups, 1024, dwInfoBufferSize);
//      CloseHandle(hAccessToken);
//
//      if bSuccess then
//      begin
//         AllocateAndInitializeSid(SECURITY_NT_AUTHORITY, 2,
//                                  SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS,
//                                  0, 0, 0, 0, 0, 0, psidAdministrators);
//         {$R-}
//         for x := 0 to ptgGroups.GroupCount - 1 do
//             if EqualSid(psidAdministrators, ptgGroups.Groups[x].Sid) then
//             begin
//                if _WinVistaUp_ and NeedFullVistaRights then
//                begin
//                  // Check if the current user has administrator privileges (only admins may start services)
//                  // Attention: On Windows Vista it is NOT enough to test if the user is in the administrator group
//                  // On Vista even administrators may run with restricted privileges! (User Account Manager!)
//                  hService := OpenSCManager(nil, nil, SC_MANAGER_ALL_ACCESS);
//                  if (hService <> 0) then
//                  begin
//                     Result := True;
//                     CloseServiceHandle(hService);
//                  end;
//                end
//                else
//                  Result := True;
//                break;
//             end;
//         {$R+}
//         FreeSid(psidAdministrators);
//      end;
//      FreeMem(ptgGroups);
//   end;
//end;
//
//{=========================================================================}
//function GetCPUCount: integer;
//var
//   SysInfo: TSystemInfo;
//begin
//   GetSystemInfo(SysInfo);
//   Result := SysInfo.dwNumberOfProcessors;
//end;
//
//{=========================================================================}
//function GetProcessorCountByAffinityMask(Mask: integer): integer;
//var
//   i: integer;
//begin
//   Result := 0;
//   for i := 0 to 31 do
//       if ((Mask and (1 shl i)) <> 0) then
//           inc(Result);
//end;
//
//{=========================================================================}
//function GetProcessAffinityMaskByID(ID: DWord; var dwProcessAffinityMask, dwSystemAffinityMask: DWord): Boolean;
//var
//  HDLL  : THandle;
//  Handle: THandle;
//  GetProcessAffinityMask: function(Handle: THandle; var dwProcessAffinityMask, dwSystemAffinityMask: DWord): LONGBOOL; stdcall;
//begin
//  // Prozessorzuweisung holen
//  Result := False;
//
//  HDLL := GetModuleHandle(PChar(Kernel32));
//
//  @GetProcessAffinityMask := GetProcAddress(HDLL,'GetProcessAffinityMask');
//  if assigned(GetProcessAffinityMask) then
//  begin
//     Result := False;
//     Handle := OpenProcess(PROCESS_QUERY_INFORMATION, False, ID);
//     if Handle <> 0 then
//     begin
//        Result := GetProcessAffinityMask(Handle, dwProcessAffinityMask, dwSystemAffinityMask);
//
//        CloseHandle(Handle);
//     end;
//  end;
//end;
//
//{=========================================================================}
//function SetProcessAffinityMaskByID(ID, Affinity: DWORD): Boolean;
//var
//  HDLL  : THandle;
//  Handle: THandle;
//  SetProcessAffinityMask: function(Handle: THandle; Affinity: DWORD): DWord; stdcall;
//begin
//  // Prozessorzuweisung setzen
//  Result := False;
//
//  HDLL := GetModuleHandle(PChar(Kernel32));
//
//  @SetProcessAffinityMask := GetProcAddress(HDLL,'SetProcessAffinityMask');
//  if assigned(SetProcessAffinityMask) then
//  begin
//     Result := False;
//     Handle := OpenProcess(PROCESS_SET_INFORMATION, False, ID);
//     if Handle <> 0 then
//     begin
//       Result := SetProcessAffinityMask(Handle, Affinity) <> 0;
//
//       CloseHandle(Handle);
//     end;
//  end;
//end;
//
//{=========================================================================}
//function SetThreadAffinityMaskByID(ID, Affinity: DWORD): Boolean;
//const
//  THREAD_SET_INFORMATION   = $0020;
//  THREAD_QUERY_INFORMATION = $0040;
//var
//  HDLL  : THandle;
//  Handle: THandle;
//  SetThreadAffinityMask: function(Handle: THandle; Affinity: DWORD): DWord; stdcall;
//  OpenThread: function(dwDesiredAccess: DWord; bInheritHandle: Bool; dwThreadId: DWord): DWord; stdcall;
//
//begin
//  // Threadzuweisung setzen
//  Result := False;
//
//  HDLL := GetModuleHandle(PChar(Kernel32));
//
//  @SetThreadAffinityMask := GetProcAddress(HDLL,'SetThreadAffinityMask');
//  @OpenThread            := GetProcAddress(HDLL,'OpenThread');
//  if assigned(SetThreadAffinityMask) and assigned(OpenThread) then
//  begin
//     Result := False;
//     Handle := OpenThread(THREAD_SET_INFORMATION or THREAD_QUERY_INFORMATION, False, ID);
//     if Handle <> 0 then
//     begin
//       Result := SetThreadAffinityMask(Handle, Affinity) <> 0;
//       CloseHandle(Handle);
//     end;
//  end;
//end;
//
//{=========================================================================}
//function SetThreadIdealProcessorByID(ID, Processor: Dword): Boolean;
//const
//  THREAD_SET_INFORMATION   = $0020;
//  THREAD_QUERY_INFORMATION = $0040;
//var
//  HDLL  : THandle;
//  Handle: THandle;
//  Res   : DWORD;
//  SetThreadIdealProcessor: function(Handle: THandle; Processor: DWORD): integer; stdcall;
//  OpenThread: function(dwDesiredAccess: DWord; bInheritHandle: Bool; dwThreadId: DWord): DWord; stdcall;
//
//begin
//  // Threadzuweisung setzen
//  Result := False;
//
//  HDLL := GetModuleHandle(PChar(Kernel32));
//
//  @SetThreadIdealProcessor := GetProcAddress(HDLL,'SetThreadIdealProcessor');
//  @OpenThread              := GetProcAddress(HDLL,'OpenThread');
//  if assigned(SetThreadIdealProcessor) and assigned(OpenThread) then
//  begin
//     Result := False;
//     Handle := OpenThread(THREAD_SET_INFORMATION or THREAD_QUERY_INFORMATION, False, ID);
//     if Handle <> 0 then
//     begin
//       Res := SetThreadIdealProcessor(Handle, Processor);
//       Result := (Res >= 0);
//       CloseHandle(Handle);
//     end;
//  end;
//end;
//
//{=========================================================================}
//function GetRegAccessMode(sKey: string; defAccess: Cardinal): Cardinal;
//const
//    KEY_WOW64_64KEY = $0100;
//    KEY_WOW64_32KEY = $0200;
//begin
//   Result := DefAccess;
//
//   // Bei 32-Bit-Windows kein spezieller Accessmode erforderlich
//   if not Is64BitWindows then
//      exit;
//
//   if Pos('WOW6432NODE', UpperCase(sKey)) > 0 then // 32-Bit-Wert schreiben?
//      Result := (Result or KEY_WOW64_32KEY)
//   else
//      Result := (Result or KEY_WOW64_64KEY);
//
//   (* Beispiel:
//
//    var
//       AccessMode: Cardinal;
//       sKey: String;
//    begin
//      sKey := '\Software\Microsoft\Windows';
//      AccessMode := GetRegAccessMode(sKey);
//
//      with TRegistry.Create(AccessMode) do
//      begin
//        try
//          {.........}
//        finally
//          free;
//        end;
//    end;
//    *)
//end;
//
//{=========================================================================}
//procedure Delay(ms: DWORD; ProcessMessages: Boolean);
//Var
//   Time: DWORD;
//begin
//  if ms > 0 then
//  begin
//{$IFDEF WIN32}
//    if ProcessMessages then
//    begin
//      Time := GetTickCount;
//      repeat
//        case MsgWaitForMultipleObjects(0, nil^, True, Time - GetTickCount + ms, QS_ALLEVENTS) of
//          WAIT_OBJECT_0:
//          begin
//            Application.ProcessMessages;
//            if GetTickCount-Time >= ms then break;
//          end;
//          WAIT_TIMEOUT:
//            break;
//        end
//      until csDestroying in Application.ComponentState
//    end
//    else Sleep(ms);
//{$ELSE}
//    Time := GetTickCount;
//    repeat
//      if ProcessMessages then Application.ProcessMessages;
//    until GetTickCount-Time >= ms;
//{$ENDIF}
//  end;
//end;
//
//{=========================================================================}
//function ClientToClient(Destination, Source: TControl; P: TPoint): TPoint;
//begin
//   Result := Destination.ScreenToClient(Source.ClientToScreen(P));
//end;
//
//{=========================================================================}
//function NonClientHeight: integer;
//begin
//   { returns the full CaptionBar height }
//   Result := GetSystemMetrics(SM_CYCAPTION)+2*GetSystemMetrics(SM_CYFRAME);
//end;
//
//{=========================================================================}
//function MenuHeight: integer;
//begin
//   { returns the full Menu height }
//   Result := GetSystemMetrics(SM_CYMENU	);
//end;
//
//{=========================================================================}
//function BitsPerPixel: integer;
//var
//   DC: HDC;
//
//begin
//   { returns "Bits Per Pixel" for the actual display
//     1     = 16 Color
//     8     = 256 Color,
//     15/16 = HiColor
//     24/32 = TrueColor }
//
//   DC := CreateDC('DISPLAY',nil,nil,nil);
//   Result := GetDeviceCaps(DC,BITSPIXEL);
//   DeleteDC(DC);
//end;
//
//{$IFNDEF  DELPHI6}
//{=========================================================================}
//function IncludeTrailingPathDelimiter(const S: string): string;
//begin
//   Result := S;
//   if not IsPathDelimiter(Result, Length(Result)) then
//      Result := Result + PathDelim;
//end;
//
//{=========================================================================}
//function ExcludeTrailingPathDelimiter(const S: string): string;
//begin
//   Result := S;
//   if IsPathDelimiter(Result, Length(Result)) then
//      SetLength(Result, Length(Result)-1);
//end;
//
//{=========================================================================}
//function IncludeTrailingBackslash(const S: string): string;
//begin
//   Result := IncludeTrailingPathDelimiter(S);
//end;
//
//{=========================================================================}
//function ExcludeTrailingBackslash(const S: string): string;
//begin
//   Result := ExcludeTrailingPathDelimiter(S);
//end;
//{$ENDIF}
//
//{=========================================================================}
//function CheckPath(const Path: string; Flag: Boolean): String;
//{Funktion pr�ft, ob letztes Zeichen in Pfadangabe ein '\' ist
// Flag:
//        TRUE - '\' Zeichen erw�nscht
//        FALSE - '\' Zeichen unerw�nscht}
//
//begin
//   if (Path <> '') then
//   begin
//      if (Flag = True) then
//          Result := IncludeTrailingPathDelimiter(Path)
//      else
//          Result := ExcludeTrailingPathDelimiter(Path);
//   end
//   else
//      Result := '';
//end;
//
//{=========================================================================}
//function CheckFilename(S: String; IncludesPath: Boolean): string;
//const
//   InvalidChars = '/*?"<>|,;';
//var
//   i,cnt: integer;
//   HasDrive: Boolean;
//   FName,Drive: string;
//begin
//   if IncludesPath then
//   begin
//      Drive := ExtractFileDrive(S);
//      HasDrive := Pos(':',Drive) > 0;
//   end
//   else
//      HasDrive := False;
//
//   i := 1;
//   while i <= Length(S) do
//   begin
//      if (Ord(S[i]) < $20) or IsDelimiter(InvalidChars,S,i) then
//          S[i] := '_'
//      else if (S[i] = ':') and (not IncludesPath or not HasDrive or (PosNoCase(Drive,S) < i-1))  then
//      begin
//         if (i < Length(S)) and (Length(S) <= i+1) and (S[i+1] = '\') then
//             cnt := 2
//         else
//             cnt := 1;
//         Delete(S,i,cnt);
//         continue;
//      end;
//      inc(i);
//   end;
//
//   FName := ChangeFileExt(S,'');
//
//   if IncludesPath then
//      FName := ExtractFileName(FName);
//
//   for i := 1 to Length(FName) do
//   begin
//      if (FName[i] in ['\','.']) then
//          FName[i] := '_';
//   end;
//
//   Result := FName+ExtractFileExt(S);
//
//   if IncludesPath then
//      Result := CheckPath(ExtractFilePath(S),True)+Result;
//end;
//
//{==============================================================================}
//function int64shl32(V: int64; Shift: Byte): MMLarge_Integer;
//var
//   R: MMLarge_Integer;
//begin
//   asm
//     {$IFDEF WIN32}
//      mov   cl, Shift
//      mov   eax, dword ptr V[0]
//      mov   edx, dword ptr V[4]
//      shld  edx, eax, cl
//      shl   eax, cl
//      mov   dword ptr R.HighPart, edx
//      mov   dword ptr R.LowPart, eax
//
//      {$ELSE}
//
//      mov   cl, Shift
//
//      db    66h
//      mov   ax, word ptr V[0]
//
//      db    66h
//      mov   dx, word ptr V[4]
//
//      db    66h      { shld  edx, eax, cl }
//      db    0Fh
//      db    0A5h
//      db    0C2h
//
//      db    66h
//      shl   ax, cl
//
//      db    66h
//      mov   word ptr R.HighPart, dx
//
//      db    66h
//      mov   word ptr R.LowPart, ax
//      {$ENDIF}
//   end;
//   Result := R;
//end;
//
//{==============================================================================}
//function int64shr32(V: MMLARGE_INTEGER; Shift: Byte): integer;
//var
//   R: integer;
//begin
//   asm
//     {$IFDEF WIN32}
//      mov   cl, Shift
//      mov   eax, dword ptr V[0]
//      mov   edx, dword ptr V[4]
//      shrd  eax, edx, cl
//      mov   dword ptr R, eax
//      {$ELSE}
//
//      not supported
//
//      {$ENDIF}
//   end;
//   Result := R;
//end;
//
//{=========================================================================}
//function int64add32(V: MMLARGE_INTEGER; AddValue: integer): MMLarge_Integer;
//var
//   R: MMLarge_Integer;
//begin
//   asm
//     {$IFDEF WIN32}
//      mov   eax, dword ptr V[0]
//      mov   edx, dword ptr V[4]
//
//      add   eax, dword ptr AddValue
//      adc   edx, 0
//
//      mov   dword ptr R.HighPart, edx
//      mov   dword ptr R.LowPart, eax
//     {$ELSE}
//     not supported !
//     {$ENDIF}
//   end;
//   Result := R;
//end;
//
//{=========================================================================}
//function int64sub32(V: MMLARGE_INTEGER; SubValue: integer): MMLarge_Integer;
//var
//   R: MMLarge_Integer;
//begin
//   asm
//     {$IFDEF WIN32}
//      mov   eax, dword ptr V[0]
//      mov   edx, dword ptr V[4]
//
//      sub   eax, dword ptr SubValue
//      sbb   edx, 0
//
//      mov   dword ptr R.HighPart, edx
//      mov   dword ptr R.LowPart, eax
//     {$ELSE}
//     not supported !
//     {$ENDIF}
//   end;
//   Result := R;
//end;
//
//{$IFDEF DELPHI7}
//{=========================================================================}
//function CalcHash(lpBuffer: PAnsiChar; Length: integer): integer;
//begin
//   Result := 0;
//   asm
//      push  esi
//
//      xor   edx,edx                //Default return
//      mov   esi,lpBuffer           //Address into ESI
//      mov   ecx,Length             //Length into ECX
//      test  ecx,ecx
//      jz    @@done                 //Abort on null string
//   @@next:
//      movsx eax,[esi]    //get next byte
//      add   edx,eax                //accumulate new byte
//      inc   esi
//      loop  @@next                 //do it again
//
//   @@done:
//      mov   Result,edx             //return 4 bytes into EAX
//
//      pop   esi
//   end;
//end;
//{$ENDIF}
//
//{$IFDEF WIN32}
//{=========================================================================}
//function GetTempFile: string;
//var
//   aBuf: array[0..MAX_PATH] of Char;
//begin
//   GetTempPath(sizeOf(aBuf) div sizeof(Char)-1,aBuf);
//   GetTempFileName(aBuf,'w'#0,Random(256)+1,aBuf);
//   Result := StrPas(aBuf);
//end;
//
//{=========================================================================}
//function CreateFullDir(Dir: string): Boolean;
//var
//   Drive,Path,S: string;
//   idx: integer;
//
//   function ExtractPathTotken(idx: integer; S: string): string;
//   var
//      x,p: integer;
//   begin
//      Result := '';
//      x := -1;
//      while (x < idx) do
//      begin
//         p := Pos('\',S);
//         if (p <= 0) then
//         begin
//            Result := '';
//            exit;
//         end;
//         Result := Result+Copy(S,1,p);
//         Delete(S,1,p);
//         inc(x);
//      end;
//   end;
//
//begin
//   Result := False;
//
//   Dir := CheckPath(Dir,True);
//
//   Drive := CheckPath(ExtractFileDrive(Dir),True);
//   Path  := CheckPath(Copy(ExtractFilePath(Dir),Length(Drive)+1,Length(Dir)),True);
//
//   if (Drive = '') or (Path = '') then exit;
//
//   idx := 0;
//   repeat
//      S := ExtractPathTotken(idx,Path);
//      if (S <> '') then
//      begin
//         if not DirectoryExists(Drive+S) then
//         begin
//            if not CreateDir(Drive+S) then
//            begin
//               Result := False;
//               exit;
//            end;
//         end;
//         inc(idx);
//      end;
//   until (S = '');
//
//   Result := True;
//end;
//
//{=========================================================================}
//function IsDirectoryEmptyEx(const Dir: string; CheckForFilesOnly: Boolean): Boolean;
//var
//   SearchData: TSearchRec;
//begin
//   Result := True;
//
//   if FindFirst(CheckPath(Dir,True) + '*', faAnyFile, SearchData) = 0 then
//   try
//      repeat
//         if (SearchData.Name <> '.') and (SearchData.Name <> '..') and
//            ((SearchData.Attr <> faDirectory) or not CheckForFilesOnly) then
//         begin
//            Result := False;
//            break;
//         end;
//      until FindNext(SearchData) <> 0;
//   finally
//      FindClose(SearchData);
//   end;
//end;
//
//{=========================================================================}
//function IsDirectoryEmpty(const Dir: string): Boolean;
//begin
//   Result := IsDirectoryEmptyEx(Dir,False);
//end;
//
//{==============================================================================}
//function ListDirectoriesEx(Dir: string; ReturnFullPath, SubDirs: Boolean; var DirList: TStrings): integer;
//var
//   SearchData: TSearchRec;
//begin
//   // F�llt eine StringListe mit allen Unterverzeichnissen von "Dir"
//   Result := 0;
//
//   Dir := IncludeTrailingPathDelimiter(Dir);
//   if FindFirst(Dir + '*', faDirectory, SearchData) = 0 then
//   try
//      repeat
//         if (SearchData.Attr and faDirectory <> 0) and (SearchData.Name <> '.') and (SearchData.Name <> '..') then
//         begin
//            if not assigned(DirList) then
//               DirList := TStringList.Create;
//
//            if ReturnFullPath then
//               DirList.Add(Dir + SearchData.Name + '\')
//            else
//               DirList.Add(SearchData.Name);
//
//            inc(Result);
//
//            if SubDirs then
//               inc(Result, ListDirectoriesEx(Dir + SearchData.Name, ReturnFullPath, SubDirs, DirList));
//         end;
//      until FindNext(SearchData) <> 0;
//   finally
//     FindClose(SearchData);
//   end;
//end;
//
//{==============================================================================}
//function ListDirectories(Dir: string; ReturnFullPath: Boolean; var DirList: TStrings): integer;
//begin
//   Result := ListDirectoriesEx(Dir,ReturnFullPath,False,DirList);
//end;
//
//{==============================================================================}
//function ListFiles(Dir: string; Extensions: array of string; var FileList: TStrings): integer;
//var
//   Ext: string;
//   SearchData: TSearchRec;
//   i: integer;
//begin
//   // F�llt eine StringListe mit allen Files in "Dir" welche den Kriterien entsprechen
//   Result := 0;
//
//   Dir := IncludeTrailingPathDelimiter(Dir);
//   if FindFirst(Dir + '*', faDirectory, SearchData) = 0 then
//   try
//      repeat
//         if (SearchData.Attr and faDirectory = 0) then
//         begin
//            if High(Extensions) < 0 then
//            begin
//               if not assigned(FileList) then
//                  FileList := TStringList.Create;
//               FileList.AddObject(Dir + SearchData.Name, TObject(SearchData.Size));
//               inc(Result);
//            end
//            else
//            begin
//               Ext := ExtractFileExt(SearchData.Name);
//               for i := 0 to High(Extensions) do
//               if SameText(Ext,Extensions[i]) or (Extensions[i] = '.*') then
//               begin
//                  if not assigned(FileList) then
//                     FileList := TStringList.Create;
//                  FileList.AddObject(Dir + SearchData.Name, TObject(SearchData.Size));
//                  inc(Result);
//                  break;
//               end;
//            end;
//         end;
//      until FindNext(SearchData) <> 0;
//   finally
//      FindClose(SearchData);
//   end;
//end;
//
//{=========================================================================}
//function DeleteFileEx(FileName: String; Recycle: Boolean): Boolean;
//var
//   LDelObj: TSHFileOpStruct;
//begin
//   if Recycle then
//   begin
//      FileName := FileName + #0#0;
//      FillChar(LDelObj,sizeOf(LDelObj), 0);
//      with LDelObj do
//      begin
//         Wnd := Application.Handle;
//         wFunc := FO_DELETE;
//         pFrom := PChar(Filename);
//         pTo := nil;
//         fFlags := FOF_ALLOWUNDO or FOF_NOCONFIRMATION or FOF_SILENT or FOF_NOERRORUI;
//      end;
//      Result := SHFileOperation(LDelObj) = 0; //0 = Erfolgreich
//   end
//   else
//      Result := DeleteFile(FileName);
//end;
//
//{=========================================================================}
//function CopyDir(fromDir, toDir: string): Boolean;
//var
//  fos: TSHFileOpStruct;
//begin
//   fromDir := CheckPath(fromDir,True)+'*.*'#0#0;
//   toDir   := CheckPath(todir,False) + #0#0;
//
//   FillChar(fos,sizeOf(fos),0);
//   with fos do
//   begin
//      wFunc  := FO_COPY;
//      fFlags := FOF_NOCONFIRMATION or FOF_SILENT or FOF_NOERRORUI;
//      pFrom  := PChar(fromDir);
//      pTo    := PChar(toDir);
//   end;
//   Result := (ShFileOperation(fos) = 0);
//end;
//
//{=========================================================================}
//function MoveDir(fromDir, toDir: string): Boolean;
//var
//  fos: TSHFileOpStruct;
//begin
//   fromDir := CheckPath(fromDir,True)+'*.*'#0#0;
//   toDir   := CheckPath(todir,False) + #0#0;
//
//   FillChar(fos,sizeOf(fos),0);
//   with fos do
//   begin
//      wFunc  := FO_MOVE;
//      fFlags := FOF_NOCONFIRMATION or FOF_SILENT or FOF_NOERRORUI;
//      pFrom  := PChar(fromDir);
//      pTo    := PChar(toDir);
//   end;
//   Result := (ShFileOperation(fos) = 0);
//end;
//
//{=========================================================================}
//function DeleteDir(Dir: string): Boolean;
//var
//  fos: TSHFileOpStruct;
//begin
//   Dir := CheckPath(Dir,False) + #0#0;
//   FillChar(fos,sizeOf(fos),0);
//   with fos do
//   begin
//     wFunc  := FO_DELETE;
//     fFlags := FOF_SILENT or FOF_NOCONFIRMATION or FOF_NOERRORUI;
//     pFrom  := PChar(Dir);
//   end;
//   Result := (ShFileOperation(fos) = 0);
//end;
//{$ENDIF}
//
//{=========================================================================}
//function GetFileSize(Name: TFileName): Longint;
//var
//   SearchRec: TSearchRec;
//
//begin
//   try
//      if FindFirst(ExpandFileName(Name), faAnyFile, SearchRec) = 0 then
//         Result := SearchRec.Size
//      else
//         Result := -1;
//   finally
//      FindClose(SearchRec);
//   end;
//end;
//
//{$IFDEF WIN32}
//{ This function is used if the OS doesn't support GetDiskFreeSpaceEx }
//{=========================================================================}
//function BackfillGetDiskFreeSpaceEx(Directory: PChar; var FreeAvailable,
//                                    TotalSpace: Int64;
//                                    TotalFree: PInt64): Bool; stdcall;
//var
//  SectorsPerCluster, BytesPerSector, FreeClusters, TotalClusters: DWORD;
//  Temp: Int64;
//  Dir : PChar;
//begin
//  if Directory <> nil then
//     Dir := PChar(ExtractFileDrive(Directory)+'\')
//  else
//     Dir := nil;
//
//  Result := GetDiskFreeSpace(Dir, SectorsPerCluster, BytesPerSector,
//                             FreeClusters, TotalClusters);
//  Temp := SectorsPerCluster;
//  Temp := Temp * BytesPerSector;
//  FreeAvailable := Temp * FreeClusters;
//  TotalSpace    := Temp * TotalClusters;
//end;
//{$ENDIF}
//
//{=========================================================================}
//function GetDiskStats(const Directory: string; var nFree, nSize: Int64): Boolean;
//{$IFDEF WIN32}
//begin
//   Result := _GetDiskFreeSpaceEx(PChar(ExtractFileDir(Directory)),nFree, nSize, nil);
//   if not Result then
//   begin { avoid errors from unchecked divisions }
//      nFree := 0;
//      nSize := 1;
//   end;
//{$ELSE}
//var
//   iDrive: Byte;
//begin
//   iDrive := Byte(UpCase(Directory[0]))-64;
//   nSize := DiskSize(iDrive);
//   nFree := DiskFree(iDrive);
//   Result := True;
//{$ENDIF}
//end;
//
//{=========================================================================}
//function GetDiskFree(const Directory: string; nBytes: Longint): Boolean;
//var
//   nFree,nSize,n: Int64;
//begin
//   Result := False;
//   if GetDiskStats(Directory,nFree,nSize) then
//   begin
//      n := nBytes;
//      Result := nFree >= n;
//   end;
//end;
//
//const
//     RC_Active     = clWhite; { the resource color for active sements    }
//     RC_Inactive   = clSilver;{ the resource color for inactive segments }
//     RC_Background = clBlack; { the resource color for the background    }
//
//{=========================================================================}
//{ Change the black/white SrcBitmap to a colored DestBitmap                }
//{=========================================================================}
//procedure ChangeColors(Bitmap: TBitmap; DrawInactive: Boolean;
//                       ForeColor, InactiveColor, BackColor: TColor);
//Var
//   aRect: TRect;
//   MaskF, MaskB, MaskI: TBitmap;
//
//   function CreateMask(Bmp: TBitmap; Color: TColor): TBitmap;
//   begin
//      Result := TBitmap.Create;
//      with Result do
//      begin
//         Monochrome  := True;
//         Width       := Bmp.Width;
//         Height      := Bmp.Height;
//         SetBkColor(Bmp.Canvas.Handle,ColorToRGB(Color));
//         Canvas.Draw(0,0,Bmp);
//      end;
//   end;
//
//   procedure PutMask(Bmp: TBitmap; aMask: TBitmap; Color: TColor; Mode: TCopyMode);
//   begin
//      with Bmp do
//      begin
//         Canvas.CopyMode := Mode;
//         SetTextColor(Canvas.Handle,0);
//         SetBkColor(Canvas.Handle,ColorToRGB(Color));
//         Canvas.StretchDraw(Bounds(0,0,Width,Height),aMask);
//      end;
//   end;
//
//begin
//    aRect := Rect(0,0,Bitmap.Width,Bitmap.Height);
//    MaskF := CreateMask(Bitmap,RC_ACTIVE);
//    try
//        MaskB := CreateMask(Bitmap,RC_Background);
//        try
//            MaskI := CreateMask(Bitmap,RC_INACTIVE);
//            try
//                PutMask(Bitmap,MaskF,ForeColor,cmSrcCopy);
//                PutMask(Bitmap,MaskB,BackColor,cmSrcInvert);
//                if DrawInactive then
//                    PutMask(Bitmap,MaskI,InactiveColor,cmSrcInvert)
//                else
//                    PutMask(Bitmap,MaskI,BackColor,cmSrcInvert);
//            finally
//                MaskI.Free;
//            end;
//        finally
//            MaskB.Free;
//        end;
//    finally
//        MaskF.Free;
//    end;
//end;
//
//{=========================================================================}
//procedure GetBitmapSize(Bitmap: HBitmap; var W, H: integer);
//var
//{$IFDEF WIN32}
//   bm: Windows.TBitmap;
//{$ELSE}
//   bm: WinTypes.TBitmap;
//{$ENDIF}
//begin
//   GetObject(Bitmap, SizeOf(bm), @bm);
//   W := bm.bmWidth;
//   H := bm.bmHeight;
//end;
//
//{=========================================================================}
//function GetTransparentColorEx(Bitmap: HBitmap; Point: TPoint): TColorRef;
//var
//   MemDC: HDC;
//   OldBitmap: HBITMAP;
//   W,H: integer;
//begin
//   MemDC := CreateCompatibleDC(0);
//   OldBitmap := SelectObject(MemDC, Bitmap);
//   GetBitmapSize(Bitmap,W,H);
//   Point.X := MinMax(Point.X,0,W-1);
//   Point.Y := MinMax(Point.Y,0,H-1);
//   Result := GetPixel(MemDC,Point.X,Point.Y);
//   SelectObject(MemDC, OldBitmap);
//   DeleteDC(MemDC);
//end;
//
//{=========================================================================}
//function GetTransparentColor(Bitmap: HBitmap): TColorRef;
//begin
//   Result := GetTransparentColorEx(Bitmap,Point(0,MaxInt-1));
//end;
//
//{=========================================================================}
//procedure DrawTransparentBitmapROP(DC: HDC; Bitmap: HBitmap; X, Y: integer;
//                                   Src: TRect; Transparent: TColorRef;
//                                   ROP: DWORD);
//type
//    _TPoint = record
//        X: integer;
//        Y: integer;
//    end;
//var
//   cColor      : TColorRef;
//   bmAndBack,
//   bmAndObject,
//   bmAndMem,
//   bmSave,
//   bmBackOld,
//   bmObjectOld,
//   bmMemOld,
//   bmSaveOld   : HBitmap;
//   hdcMem,
//   hdcBack,
//   hdcObject,
//   hdcTemp,
//   hdcSave     : HDC;
//   bmWidth,
//   bmHeight    : integer;
//
//begin
//   {$IFDEF WIN32}
//   EnterCriticalSection(TransSection);
//   try
//   {$ENDIF}
//      hdcTemp := CreateCompatibleDC(DC);
//      SelectObject(hdcTemp, Bitmap); { select the bitmap }
//
//      bmWidth  := Src.Right-Src.Left;
//      bmHeight := Src.Bottom-Src.Top;
//
//      { create some DCs to hold temporary data }
//      hdcBack   := CreateCompatibleDC(DC);
//      hdcObject := CreateCompatibleDC(DC);
//      hdcMem    := CreateCompatibleDC(DC);
//      hdcSave   := CreateCompatibleDC(DC);
//
//      { create a bitmap for each DC }
//
//      { monochrome DC }
//      bmAndBack   := CreateBitmap(bmWidth, bmHeight, 1, 1, nil);
//      bmAndObject := CreateBitmap(bmWidth, bmHeight, 1, 1, nil);
//
//      bmAndMem    := CreateCompatibleBitmap(DC, bmWidth, bmHeight);
//      bmSave      := CreateCompatibleBitmap(DC, bmWidth, bmHeight);
//
//      { each DC must select a bitmap object to store pixel data }
//      bmBackOld   := SelectObject(hdcBack, bmAndBack);
//      bmObjectOld := SelectObject(hdcObject, bmAndObject);
//      bmMemOld    := SelectObject(hdcMem, bmAndMem);
//      bmSaveOld   := SelectObject(hdcSave, bmSave);
//
//      { set proper mapping mode }
//      SetMapMode(hdcTemp, GetMapMode(DC));
//
//      { save the bitmap sent here, because it will be overwritten }
//      BitBlt(hdcSave, 0, 0, bmWidth, bmHeight, hdcTemp, Src.Left, Src.Top, SRCCOPY);
//
//      { set the background color of the source DC to the color.
//        contained in the parts of the bitmap that should be transparent }
//      cColor := SetBkColor(hdcTemp, ColorToRGB(Transparent));
//
//      { create the object mask for the bitmap by performing a BitBlt()
//        from the source bitmap to a monochrome bitmap }
//      BitBlt(hdcObject, 0, 0, bmWidth, bmHeight, hdcTemp, Src.Left, Src.Top, SRCCOPY);
//
//      { set the background color of the source DC back to the original color }
//      SetBkColor(hdcTemp, cColor);
//
//      { create the inverse of the object mask }
//      BitBlt(hdcBack, 0, 0, bmWidth, bmHeight, hdcObject, 0, 0, NOTSRCCOPY);
//
//      { copy the background of the main DC to the destination }
//      BitBlt(hdcMem, 0, 0, bmWidth, bmHeight, DC, X, Y, SRCCOPY);
//
//      { mask out the places where the bitmap will be placed }
//      BitBlt(hdcMem, 0, 0, bmWidth, bmHeight, hdcObject, 0, 0, SRCAND);
//
//      { mask out the transparent colored pixels on the bitmap }
//      BitBlt(hdcTemp, Src.Left, Src.Top, bmWidth, bmHeight, hdcBack, 0, 0, SRCAND);
//
//      { XOR the bitmap with the background on the destination DC }
//      BitBlt (hdcMem, 0, 0, bmWidth, bmHeight, hdcTemp, Src.Left, Src.Top, ROP);
//
//      { copy the destination to the screen }
//      BitBlt(DC, X, Y, bmWidth, bmHeight, hdcMem, 0, 0, SRCCOPY);
//
//      { place the original bitmap back into the bitmap sent here }
//      BitBlt(hdcTemp, Src.Left, Src.Top, bmWidth, bmHeight, hdcSave, 0, 0, SRCCOPY);
//
//      { delete the memory bitmaps }
//      DeleteObject(SelectObject(hdcBack, bmBackOld));
//      DeleteObject(SelectObject(hdcObject, bmObjectOld));
//      DeleteObject(SelectObject(hdcMem, bmMemOld));
//      DeleteObject(SelectObject(hdcSave, bmSaveOld));
//
//      { delete the memory DCs }
//      DeleteDC(hdcMem);
//      DeleteDC(hdcBack);
//      DeleteDC(hdcObject);
//      DeleteDC(hdcSave);
//      DeleteDC(hdcTemp);
//   {$IFDEF WIN32}
//   finally
//      LeaveCriticalSection(TransSection);
//   end;
//   {$ENDIF}
//end;
//
//{=========================================================================}
//procedure DrawTransparentBitmapEx(DC: HDC; Bitmap: HBitmap; X, Y: integer;
//                                  Src: TRect; Transparent: TColorRef);
//begin
//   DrawTransparentBitmapROP(DC,Bitmap,X,Y,Src,Transparent,SRCPAINT);
//end;
//
//{=========================================================================}
//procedure DrawTransparentBitmap(DC: HDC; Bitmap: HBitmap; X, Y: integer;
//                                Transparent: TColorRef);
//var
//   Src: TRect;
//
//begin
//   Src.TopLeft := Point(0,0);
//   { convert bitmap dimensions from device to logical points }
//   GetBitmapSize(Bitmap, Src.Right, Src.Bottom);
//   DrawTransparentBitmapEx(DC, Bitmap, X, Y,
//                           Src, Transparent);
//end;
//
//{=========================================================================}
//procedure StretchDrawTransparentBitmap(DC: HDC; Bitmap: HBitmap; X, Y, DestWidth, DestHeight: integer; Transparent: TColorRef);
//var
//   crOldBack,crOldText: TColorRef;
//   hdcImage,hdcTrans,
//   hdcStretch,hdcSrc  : HDC;
//   hBmpStretch,
//   hBmpTrans,
//   hOldSrcBmp,
//   hOldBmpStretch,
//   hOldBmpImage,
//   hOldBmpTrans       : HBITMAP;
//   bmpInfo            : Windows.TBITMAP;
//
//begin
//   {$IFDEF WIN32}
//   EnterCriticalSection(TransSection);
//   try
//   {$ENDIF}
//      crOldBack := SetBkColor(DC, RGB(255,255,255));
//      crOldText := SetTextColor(DC, RGB(0,0,0));
//
//      // Create two memory dcs for the image and the mask
//      hdcImage := CreateCompatibleDC(DC);
//      hdcTrans := CreateCompatibleDC(DC);
//
//      // Get Bmp source info
//      GetObject(Bitmap, sizeof(bmpInfo), @bmpInfo);
//
//      // If we Stretch, we must create a compatible DC & bitmap then draw
//      // the stretched source image into the compatible DC.  Then, the bitmap
//      // of the compatible DC will be used as source bitmap to hdcImage.
//      // Else, associate directly bmp source to hdcImage.
//      if (DestWidth <> bmpInfo.bmWidth)  or (DestHeight <> bmpInfo.bmHeight) then
//      begin
//         hdcSrc := CreateCompatibleDC(DC);
//         hOldSrcBmp := SelectObject(hdcSrc, Bitmap);
//
//         hdcStretch := CreateCompatibleDC(DC);
//         hBmpStretch := CreateCompatibleBitmap(DC, DestWidth, DestHeight);
//
//         hOldBmpStretch := SelectObject(hdcStretch, hBmpStretch);
//         StretchBlt(hdcStretch, 0, 0, DestWidth, DestHeight, hdcSrc, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY);
//         SelectObject(hdcStretch, hOldBmpStretch);
//
//         // Select the image into the appropriate dc
//         hOldBmpImage := SelectObject(hdcImage, hBmpStretch);
//      end
//      else
//      begin
//         // Select the image into the appropriate dc
//         hOldBmpImage := SelectObject(hdcImage, Bitmap);
//         hdcSrc     := 0;
//         hdcStretch := 0;
//         hOldSrcBmp := 0;
//         hBmpStretch:= 0;
//      end;
//
//      // Create the mask bitmap
//      hBmpTrans := CreateBitmap(DestWidth, DestHeight, 1, 1, nil);
//
//      // Select the mask bitmap into the appropriate dc
//      hOldBmpTrans := SelectObject(hdcTrans, hBmpTrans);
//
//      // Build mask based on transparent colour
//      SetBkColor(hdcImage, Transparent);
//      BitBlt(hdcTrans, 0, 0, DestWidth, DestHeight, hdcImage, 0, 0, SRCCOPY);
//
//      // Do the work - True Mask method - cool if not actual display
//      BitBlt(DC, x, y, DestWidth, DestHeight, hdcImage, 0, 0, SRCINVERT);
//      BitBlt(DC, x, y, DestWidth, DestHeight, hdcTrans, 0, 0, SRCAND);
//      BitBlt(DC, x, y, DestWidth, DestHeight, hdcImage, 0, 0, SRCINVERT);
//
//      if (DestWidth <> bmpInfo.bmWidth) or (DestHeight <> bmpInfo.bmHeight) then
//      begin
//         SelectObject(hdcSrc, hOldSrcBmp);
//         DeleteObject(hBmpStretch);
//         DeleteDC(hdcSrc);
//         DeleteDC(hdcStretch);
//      end;
//
//      // Restore settings
//      SelectObject(hdcImage, hOldBmpImage);
//      DeleteDC(hdcImage);
//
//      SelectObject(hdcTrans, hOldBmpTrans);
//      DeleteDC(hdcTrans);
//
//      DeleteObject(hBmpTrans);
//
//      SetBkColor(DC, crOldBack);
//      SetTextColor(DC, crOldText);
//   {$IFDEF WIN32}
//   finally
//      LeaveCriticalSection(TransSection);
//   end;
//   {$ENDIF}
//end;
//
//{=========================================================================}
//procedure TileBlt(DC: HDC; Bitmap: HBitmap; const aRect: TRect; ROP: Longint; Direction: integer);
//{ This procedure tiles the given Bitmap aBitmap on DC. }
//{ aRect specifies the dimensions                       }
//var
//   aWidth,aHeight,W,H: integer;
//   TempDC: HDC;
//   oldBitmap: HBitmap;
//   i,j : integer;
//
//begin
//   {$IFDEF WIN32}
//   EnterCriticalSection(TransSection);
//   try
//   {$ENDIF}
//      OldBitmap := 0;
//      TempDC := CreateCompatibleDC(DC);
//      try
//         OldBitmap := SelectObject(TempDC, Bitmap); { select the bitmap }
//
//         GetBitmapSize(Bitmap,aWidth,aHeight);
//
//         i := 0;
//         H := aRect.Bottom-aRect.Top;
//         while H > 0 do
//         begin
//            j := 0;
//            W := aRect.Right-aRect.Left;
//            while W > 0 do
//            begin
//               if (Direction = 1) then
//                   BitBlt(DC, aRect.Left+j*aWidth, aRect.Top+i*aHeight,
//                          Min(aWidth,W), Min(aHeight,H),
//                          TempDC,0,0,ROP)
//               else
//                   BitBlt(DC, aRect.Left+j*aWidth, Max(aRect.Bottom-(i+1)*aHeight,0),
//                          Min(aWidth,W), Min(aHeight,H),
//                          TempDC,0,-Min(aRect.Bottom-(i+1)*aHeight,0),ROP);
//
//               dec(W,aWidth);
//               inc(j);
//            end;
//            dec(H,aHeight);
//            inc(i);
//         end;
//
//      finally
//         SelectObject(TempDC, OldBitmap);
//         DeleteDC(TempDC);
//      end;
//   {$IFDEF WIN32}
//   finally
//      LeaveCriticalSection(TransSection);
//   end;
//   {$ENDIF}
//end;
//
//{=========================================================================}
//procedure FillGradient(DC: HDC; BeginColor, EndColor: TColor;
//                       nColors: integer; const aRect: TRect);
//var
//   BeginRGBValue : array[0..2] of Byte;
//   RGBDifference : array[0..2] of integer;
//   ColorBand     : TRect;
//   i             : Integer;
//   Red,Green,Blue: Byte;
//   Brush,OldBrush: HBrush;
//
//begin
//   { Extract the begin RGB values, set the Red, Green and Blue colors }
//   BeginRGBValue[0] := GetRValue(ColorToRGB(BeginColor));
//   BeginRGBValue[1] := GetGValue(ColorToRGB(BeginColor));
//   BeginRGBValue[2] := GetBValue(ColorToRGB(BeginColor));
//
//   { Calculate the difference between begin and end RGB values }
//   RGBDifference[0] := GetRValue(ColorToRGB(EndColor))-BeginRGBValue[0];
//   RGBDifference[1] := GetGValue(ColorToRGB(EndColor))-BeginRGBValue[1];
//   RGBDifference[2] := GetBValue(ColorToRGB(EndColor))-BeginRGBValue[2];
//
//   { Calculate the color band's top and bottom coordinates, for Left To Right fills }
//   ColorBand.Top := aRect.Top;
//   ColorBand.Bottom := aRect.Bottom;
//
//   { Perform the fill }
//   for i := 0 to nColors-1 do
//   begin
//      { Calculate the color band's left and right coordinates }
//      ColorBand.Left  := aRect.Left+ MulDiv(i, aRect.Right-aRect.Left, nColors);
//      ColorBand.Right := aRect.Left+ MulDiv(i+1, aRect.Right-aRect.Left, nColors);
//      { Calculate the color band's color }
//      if (nColors > 1) then
//      begin
//         Red   := BeginRGBValue[0] + MulDiv(i, RGBDifference[0],nColors-1);
//         Green := BeginRGBValue[1] + MulDiv(i, RGBDifference[1],nColors-1);
//         Blue  := BeginRGBValue[2] + MulDiv(i, RGBDifference[2],nColors-1);
//      end
//      else
//      begin
//         { Set to the Begin Color if set to only one color }
//         Red   := BeginRGBValue[0];
//         Green := BeginRGBValue[1];
//         Blue  := BeginRGBValue[2];
//      end;
//
//      { Create a brush with the appropriate color for this band }
//      Brush := CreateSolidBrush(RGB(Red,Green,Blue));
//      { Select that brush into the temporary DC. }
//      OldBrush := SelectObject(DC, Brush);
//      try
//         { Fill the rectangle using the selected brush -- PatBlt is faster than FillRect }
//         PatBlt(DC, ColorBand.Left, ColorBand.Top, ColorBand.Right-ColorBand.Left, ColorBand.Bottom-ColorBand.Top, PATCOPY);
//      finally
//         { Clean up the brush }
//         SelectObject(DC, OldBrush);
//         DeleteObject(Brush);
//      end;
//   end;
//end;
//
//{=========================================================================}
//procedure FillSolid(DC: HDC; Color: TColor; const aRect: TRect);
//var
//  Brush, OldBrush: HBrush;
//
//begin
//   Brush := CreateSolidBrush(Color);
//   OldBrush := SelectObject(DC, Brush);
//   try
//      PatBlt(DC, aRect.Left, aRect.Top,
//                 aRect.Right-aRect.Left,
//                 aRect.Bottom-aRect.Top, PATCOPY);
//   finally
//      Brush := SelectObject(DC, OldBrush);
//      DeleteObject(Brush);
//   end;
//end;
//
//{=========================================================================}
//function WinExecAndWaitElevated(FileName: TFileName; TimeOut: DWORD; Elevated: Boolean): Boolean;
//var
//   {$IFDEF WIN32}
//   idx           : integer;
//   Params,FName,S: string;
//   ExCode,Res    : DWORD;
//   shExecInfo    : TSHELLEXECUTEINFO;
//   {$ELSE}
//   hAppInstance  : THandle;
//   Msg           : TMsg;
//   aBuf          : array[0..255] of Char;
//   {$ENDIF}
//
//begin
//   Result := False;
//   {$IFNDEF WIN32}
//   hAppInstance := WinExec(StrPCopy(aBuf, FileName), SW_NORMAL);
//   if (hAppInstance < HINSTANCE_ERROR) then exit
//   else
//   repeat
//      while PeekMessage(Msg, 0, 0, 0, pm_Remove) do
//      begin
//        TranslateMessage(Msg);
//        DispatchMessage(Msg);
//      end;
//   until (GetModuleUsage(hAppInstance) = 0);
//   Result := True;
//   {$ELSE}
//
//   FillChar(shExecInfo, SizeOf(shExecInfo), 0);
//   with shExecInfo do
//   begin
//      cbSize       := sizeof(shExecInfo);
//
//      fMask        := SEE_MASK_NOCLOSEPROCESS;
//      wnd          := 0;
//      if _WinVistaUp_ and Elevated then
//         lpVerb    := 'runas'
//      else
//         lpVerb    := nil;
//
//      FName := LowerCase(FileName);
//
//      S := '.exe ';
//
//      idx := Pos(S, FName);
//      if (idx <= 0) then
//      begin
//         S := ' ';
//         idx := Pos(S, FName);
//      end;
//
//      if (idx > 0) then
//      begin
//         Params    := Trim(Copy(FileName, idx+Length(S), Length(FileName)));
//         FileName  := Trim(Copy(FileName, 1, idx+Max(Length(S)-1,0)-1));
//      end
//      else
//         Params    := '';
//
//      lpFile       := PChar(FileName);
//      lpParameters := PChar(Params);
//      lpDirectory  := nil;
//      nShow        := SW_NORMAL;
//      hInstApp     := 0;
//
//      if ShellExecuteEx(@shExecInfo) then
//      begin
//         Res := WaitforSingleObject(hProcess, TIMEOUT);
//         if (Res = WAIT_TIMEOUT) then
//         begin
//            TerminateProcess(hProcess,0);
//            CloseHandle(hProcess);
//            Result := False;
//         end
//         else
//         begin
//            GetExitCodeProcess(hProcess, ExCode);
//            CloseHandle(hProcess);
//            Result := (ExCode = 0);
//         end;
//      end;
//   end;
//{$ENDIF}
//end;
//
//{=========================================================================}
//function WinExecAndWaitEx(FileName: TFileName; TimeOut: DWORD): Boolean;
//begin
//   Result := WinExecAndWaitElevated(FileName,INFINITE,False);
//end;
//
//{=========================================================================}
//function WinExecAndWait(FileName: TFileName): Boolean;
//begin
//   Result := WinExecAndWaitEx(FileName,INFINITE);
//end;
//
//{=========================================================================}
//procedure TimeDecode(Time: Longint; var Hour, Min, Sec, MSec: Word);
//Var
//   MinCount, MSecCount: Word;
//
//begin
//   if Time > 0 then
//   begin
//     DivMod32(Time, 60000, MinCount, MSecCount);
//     DivMod32(MinCount, 60, Hour, Min);
//     DivMod32(MSecCount, 1000, Sec, MSec);
//   end
//   else
//   begin
//      Hour := 0;
//      Min := 0;
//      Sec := 0;
//      MSec := 0;
//   end;
//end;
//
//{=========================================================================}
//function TimeToMask(Time: Longint): string;
//begin
//   Result := Format('%2.2d%2.2d%5.5d',
//                    [Time div 3600000,
//                     Time mod 3600000 div 60000,
//                     Time mod 60000]);
//end;
//
//{=========================================================================}
//function MaskToTime(Mask: string): Longint;
//begin
//   Result := StrToIntDef(Mask, 0);
//
//   Result := (Result div 10000000)*3600000+
//             ((Result mod 10000000) mod 100000) +
//             ((Result mod 10000000) div 100000) * 60000;
//end;
//
//{$IFDEF WIN32}
//{=========================================================================}
//function TimeToString64Ex(Time: int64; MSec: Boolean): string;
//begin
//   if MSec then
//   begin
//      if Time >= 86400000 then
//         Result := Format('%d:%2.2d:%2.2d:%2.2d.%3.3d',[int64Div32(Time,86400000),
//                                                        int64Div32(int64Mod32(Time,86400000),3600000),
//                                                        int64Div32(int64Mod32(Time,3600000),60000),
//                                                        int64Div32(int64Mod32(Time,60000),1000),
//                                                        int64Mod32(Time,1000)])
//      else if Time >= 3600000 then
//         Result := Format('%d:%2.2d:%2.2d.%3.3d',[int64Div32(Time,3600000),
//                                                  int64Div32(int64Mod32(Time,3600000),60000),
//                                                  int64Div32(int64Mod32(Time,60000),1000),
//                                                  int64Mod32(Time,1000)])
//      else
//         Result := Format('%d:%2.2d.%3.3d',[int64Div32(Time,60000),
//                                            int64Div32(int64Mod32(Time,60000),1000),
//                                            int64Mod32(Time,1000)]);
//   end
//   else
//   begin
//      if Time >= 86400000 then
//         Result := Format('%d:%2.2d:%2.2d:%2.2d',[int64Div32(Time,86400000),
//                                                  int64Div32(int64Mod32(Time,86400000),3600000),
//                                                  int64Div32(int64Mod32(Time,3600000),60000),
//                                                  int64Div32(int64Mod32(Time,60000),1000)])
//      else if Time >= 3600000 then
//         Result := Format('%d:%2.2d:%2.2d',[int64Div32(Time,3600000),
//                                            int64Div32(int64Mod32(Time,3600000),60000),
//                                            int64Div32(int64Mod32(Time,60000),1000)])
//      else
//         Result := Format('%d:%2.2d',[int64Div32(Time,60000),
//                                      int64Div32(int64Mod32(Time,60000),1000)]);
//   end;
//end;
//
//{=========================================================================}
//function TimeToString64(LowTime,HighTime: Cardinal; MSec: Boolean): string;
//var
//   Time: int64;
//begin
//   asm
//      mov  dword ptr Time[0], eax
//      mov  dword ptr Time[4], edx
//   end;
//   Result := TimeToString64Ex(Time, MSec);
//end;
//{$ENDIF}
//
//{=========================================================================}
//function TimeToStringEx(Time: MM_int64; MSec: Boolean): string;
//begin
//   if MSec then
//   begin
//      {$IFDEF DELPHI4}
//      if Time >= 86400000 then
//         Result := Format('%d:%2.2d:%2.2d:%2.2d.%3.3d',[Time div 86400000,
//                                                       (Time mod 86400000) div 3600000,
//                                                       (Time mod 3600000) div 60000,
//                                                       (Time mod 60000) div 1000,
//                                                       Time mod 1000])
//      else
//      {$ENDIF}
//      if Time >= 3600000 then
//         Result := Format('%d:%2.2d:%2.2d.%3.3d',[Time div 3600000,
//                                                 (Time mod 3600000) div 60000,
//                                                 (Time mod 60000) div 1000,
//                                                 Time mod 1000])
//      else
//         Result := Format('%d:%2.2d.%3.3d',[Time div 60000,
//                                           (Time mod 60000) div 1000,
//                                           Time mod 1000]);
//   end
//   else
//   begin
//      {$IFDEF DELPHI4}
//      if Time >= 86400000 then
//         Result := Format('%d:%2.2d:%2.2d:%2.2d',[Time div 86400000,
//                                                  (Time mod 86400000) div 3600000,
//                                                  (Time mod 3600000) div 60000,
//                                                  (Time mod 60000) div 1000])
//      else
//      {$ENDIF}
//      if Time >= 3600000 then
//         Result := Format('%d:%2.2d:%2.2d',[Time div 3600000,
//                                           (Time mod 3600000) div 60000,
//                                           (Time mod 60000) div 1000])
//      else
//         Result := Format('%d:%2.2d',[Time div 60000,
//                                     (Time mod 60000) div 1000]);
//   end;
//end;
//
//{=========================================================================}
//function TimeToString(Time: MM_int64): string;
//begin
//   Result := TimeToStringEx(Time,True);
//end;
//
//{=========================================================================}
//function CheckFloatEx(const S: string; DecimalSep: Char): string;
//var
//   i: integer;
//begin
//   Result := S;
//   for i := 1 to Length(Result) do
//   begin
//      if (Result[i] in ['.',',',';']) and
//         (Result[i] <> DecimalSep) then
//          Result[i] := DecimalSep;
//   end;
//end;
//
//{=========================================================================}
//function CheckFloat(const S: string): string;
//begin
//   Result := CheckFloatEx(S,DecimalSeparator);
//end;
//
//{=========================================================================}
//function StrToFloatEx(S: string): Extended;
//begin
//   Result:= StrToFloat(CheckFloat(S));
//end;
//
//{=========================================================================}
//function FloatToStrEx(V: Extended; DecimalSep: char): string;
//begin
//   Result := CheckFloatEx(FloatToStr(V),DecimalSep);
//end;
//
//{=========================================================================}
//function WideStrLen(CharsP: PWideChar): Integer;
//var
//   EndCharP: PWideChar;
//begin
//   EndCharP := CharsP;
//   while EndCharP^ <> WideChar(#0) do Inc(EndCharP);
//   Result := EndCharP - CharsP;
//end;
//
//{=========================================================================}
//function DBToLin(DB: Float): Float;
//begin
//   Result := pow(10,DB/20);
//end;
//
//{=========================================================================}
//function LinToDB(lin: Float): Float;
//begin
//   if lin < 1.0e-6 then Result := -120
//   else Result := log10(abs(lin))*20;
//end;
//
//{=========================================================================}
//function DBToVolume(DB: Float; Base: Longint): Longint;
//begin
//   { if (DB = Base) then
//       Result := Base
//   else
//   }
//       Result := Round(Base/pow(10,-DB/20));
//end;
//
//{=========================================================================}
//function VolumeToDB(Volume, Base: Longint): Float;
//begin
//   if (Volume = 0) then Result := -110.0
//   else
//   begin
//      Result := Log10(abs(Volume)/Max(Base,1))*20;
//   end;
//end;
//
//{=========================================================================}
//function VolumeToStringShort(Volume, Base: Longint; Precision: integer): string;
//var
//   Value: Float;
//
//begin
//   if (Volume = 0) then Result := '-Inf'
//   else
//   begin
//      Value := Log10(abs(Volume)/Max(Base,1))*20;
//      Result := Format('%2.*f',[Precision,Value]);
//   end;
//end;
//
//{=========================================================================}
//function VolumeToString(Volume, Base: Longint; Precision: integer): string;
//begin
//   Result := VolumeToStringShort(Volume, Base, Precision) + ' dB';
//end;
//
//{=========================================================================}
//function PanningToString(Panning, Range: Longint): string;
//begin
//   Result := Format('%d:%d',[(Range-Panning)*50 div Range,
//                             (Panning+Range)*50 div Range]);
//end;
//
//{=========================================================================}
//procedure CalcVolume(Base,Volume,Panning: Longint; var Left, Right: Longint);
//begin
//   if Panning > 0 then
//   begin
//      Left  := MulDiv((Base-Panning),Volume,Base);
//      Right := Volume;
//   end
//   else
//   begin
//      Left := Volume;
//      Right := MulDiv((Base+Panning),Volume,Base);
//   end;
//end;
//
//{=========================================================================}
//function CombineVolume(Vol1,Vol2,Base: Longint): Longint;
//begin
//   Result := Min(MulDiv(Vol1,Vol2,Base),Base);
//end;
//
//{=========================================================================}
//function FormatBigNumber(dw: Longint): String;
//begin
//   { this is ugly... }
//   if (dw >= 1000000000) then
//   begin
//      FmtStr(Result, '%d.%3.3d.%3.3d.%3.3d',
//                     [(dw div 1000000000),
//                      (dw mod 1000000000) div 1000000,
//                      (dw mod 1000000) div 1000,
//                      (dw mod 1000)]);
//   end
//   else if (dw >= 1000000) then
//   begin
//      FmtStr(Result, '%d.%3.3d.%3.3d',
//                     [(dw div 1000000),
//                      (dw mod 1000000) div 1000,
//                      (dw mod 1000)]);
//    end
//    else if (dw >= 1000) then
//    begin
//       FmtStr(Result, '%d.%3.3d',
//                      [(dw div 1000),
//                       (dw mod 1000)]);
//    end
//    else
//    begin
//       FmtStr(Result, '%d', [dw]);
//    end;
//end;
//
//{=========================================================================}
//function BytesToString(Bytes: Comp): string;
//var
//   OldSep: Char;
//begin
//   OldSep := DecimalSeparator;
//   DecimalSeparator := '.';
//
//   if (Bytes >= 1024*1024*1024) then
//       Result := Format('%.1f Gb',[Bytes/(1024*1024*1024)])
//   else if (Bytes >= 1000*1024) then
//       Result := Format('%.1f Mb',[Bytes/(1024*1024)])
//   else
//       Result := Format('%.1f Kb',[Bytes/1024]);
//   DecimalSeparator := OldSep;
//end;
//
//{=========================================================================}
//procedure DrawRubberband(Sender: TObject; aRect: TRect);
//var
//  DC: HDC;
//  PtA, PtB: TPoint;
//
//begin
//   if Sender is TControl then
//   with (Sender as TControl) do
//   begin
//      DC := GetDC(0);
//
//      if (aRect.Left <> 0) or (aRect.Top <> 0) or
//         (aRect.Right <> 0) or (aRect.Bottom <> 0) then
//      begin
//         PtA := ClientToScreen(Point(aRect.Left, aRect.Top));
//         PtB := ClientToScreen(Point(aRect.Right, aRect.Bottom));
//         {$IFDEF WIN32}
//         if PtA.X > PtB.X then SwapLong(PtA.X,PtB.X);
//         if PtA.Y > PtB.Y then SwapLong(PtA.Y,PtB.Y);
//         {$ELSE}
//         if PtA.X > PtB.X then SwapInt(PtA.X,PtB.X);
//         if PtA.Y > PtB.Y then SwapInt(PtA.Y,PtB.Y);
//         {$ENDIF}
//         DrawFocusRect(DC, Rect(PtA.X, PtA.Y, PtB.X, PtB.Y));
//      end;
//      ReleaseDC(0,DC);
//   end;
//end;
//
//{=========================================================================}
//procedure DrawRubberLineEx(Sender: TObject; aRect: TRect; Pen: HPEN; ROP: DWORD);
//var
//  DC: HDC;
//  PtA, PtB: TPoint;
//
//begin
//   if Sender is TControl then
//   with (Sender as TControl) do
//   begin
//      DC := GetDC(0);
//      Pen := SelectObject(DC,Pen);
//      SetRop2(DC,ROP);
//      if (aRect.Left <> 0) or (aRect.Top <> 0) or
//         (aRect.Right <> 0) or (aRect.Bottom <> 0) then
//      begin
//         PtA := ClientToScreen(Point(aRect.Left, aRect.Top));
//         PtB := ClientToScreen(Point(aRect.Right, aRect.Bottom));
//         {$IFDEF WIN32}
//         MoveToEx(DC,PtA.X,PtA.Y,nil);
//         {$ELSE}
//         MoveToEx(DC,PtA.X,PtA.Y,nil);
//         {$ENDIF}
//         LineTo(DC,PtB.X,PtB.Y);
//      end;
//      SelectObject(DC,Pen);
//      ReleaseDC(0,DC);
//   end;
//end;
//
//{=========================================================================}
//procedure DrawRubberLine(Sender: TObject; aRect: TRect);
//begin
//   DrawRubberLineEx(Sender,aRect,GetStockObject(WHITE_PEN),R2_XORPEN);
//end;
//
//{=========================================================================}
//{ Align: 0: Left, 1: Right: 2: Vertikal                                   }
//procedure TextOutAligned(Canvas: TCanvas; X, Y: integer; Text: String;
//                         FontName: PChar; FontSize: integer; Align: Byte);
//var
//   DC: THandle;
//   Font, OldFont: HFont;
//   Extent: TSize;
//   Orientation: Word;
//
//begin
//   DC := Canvas.Handle;
//
//   if Align = 2 then
//      Orientation := 90
//   else
//      Orientation := 360;
//
//   if _Win2K_ or _Win2K3_ or _WinXP_ or _WinVistaUp_ then
//      FontSize := -(FontSize-1);
//
//   Font := CreateFont(FontSize,0,Orientation*10,0,fw_normal,0,0,0,1,4,$10,2,4,FontName);
//   OldFont := SelectObject(DC, Font);
//   GetTextExtentPoint(DC, PChar(Text), Length(Text), Extent);
//   case Align of
//       0: begin { left aligned }
//             dec(Y, Extent.cY div 2);
//          end;
//       1: begin { right aligned }
//             dec(X, Extent.cX);
//             dec(Y, Extent.cY div 2);
//          end;
//       2: begin { vertikal aligned }
//             dec(X, Extent.cY div 2);
//             inc(Y, Extent.cX);
//          end;
//   end;
//   Text := Text + #0;
//   TextOut(DC, X, Y, PChar(Text), Length(Text)-1);
//   SelectObject(DC, OldFont);
//   DeleteObject(Font);
//end;
//
//{=========================================================================}
//function GlobalAllocMem(Size: Longint): Pointer;
//begin
//   Result := GlobalAllocPtr(GPTR, Size);
//   if (Result = nil) then OutOfMemoryError;
//end;
//
//{=========================================================================}
//procedure GlobalReAllocMem(var p: Pointer; Size: Longint);
//begin
//   GlobalFreeMem(p);
//   p := GlobalAllocMem(Size);
//end;
//
//{=========================================================================}
//procedure GlobalFreeMem(var p: Pointer);
//begin
//   if (p <> nil) then
//   begin
//      GlobalFreePtr(p);
//      p := nil;
//   end;
//end;
//
//{=========================================================================}
//function GlobalMemSize(const p: Pointer): Longint;
//begin
//   if (p <> nil) then
//   begin
//      {$IFDEF WIN32}
//      Result := GlobalSize(GlobalHandle(p));
//      {$ELSE}
//      Result := GlobalSize(GlobalHandle(SELECTOROF(p)));
//      {$ENDIF}
//   end
//   else Result := 0;
//end;
//
//{$IFDEF WIN32}
//
/////////////////////////////////////////////////////////////////////////////////
////
////  MakeCdeclCallback (build thunk to use cdecl methods as static callback)
////
//
//{=========================================================================}
//function MakeCdeclCallback(const Method: TMethod; StackSize: Shortint): Pointer;
//type
//   PCallbackData = ^TCallbackData;
//   TCallbackData = packed record
//     // jmp  $8
//     JmpParmOps: array[0..1] of Byte;
//     MethodData: TMethod;
//   end;
//   PCallbackPush = ^TCallbackPush;
//   TCallbackPush = packed record
//     // push dword ptr [esp+x]
//     PushParmOps: array [0..2] of Byte;
//     PushParmVal: Shortint;
//   end;
//   PCallbackCall = ^TCallbackCall;
//   TCallbackCall = packed record
//     // push dword ptr [offset]
//     PushDataOps: array [0..1] of Byte;
//     PushDataVal: Pointer;
//     // call [offset]
//     CallCodeOps: array [0..1] of Byte;
//     CallCodeVal: Pointer;
//     // add esp,x
//     AddEspXXOps: array [0..1] of Byte;
//     AddEspXXVal: Shortint;
//     // ret
//     Return     : Byte;
//   end;
//var
//   Size: ShortInt;
//   Loop: integer;
//   Buff: Pointer;
//begin
//   // check for invalid parameter and Shortint overflow
//   if (StackSize < 0) or (StackSize > High(Shortint) + 1 - 2 * SizeOf(DWORD)) then
//   begin
//      Result := nil;
//      Exit;
//   end;
//   Result := VirtualAlloc(nil, $100, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
//   if Assigned(Result) then
//   try
//      Buff := Result;
//
//      with PCallbackData(Buff)^ do
//      begin
//         JmpParmOps[0] := $EB;
//         JmpParmOps[1] := $08;
//         MethodData    := Method;
//      end;
//      inc(PCallbackData(Buff));
//
//      if StackSize <= 0 then
//         Size := 0
//      else
//      begin
//         // Copy parameters (used Longwords)
//         Size := ((StackSize - 1) div SizeOf(DWORD) + 1) * SizeOf(DWORD);
//         for Loop := 1 to Size div SizeOf(DWORD) do
//         begin
//            with PCallbackPush(Buff)^ do
//            begin
//               PushParmOps[0] := $FF;
//               PushParmOps[1] := $74;
//               PushParmOps[2] := $24;
//               PushParmVal := Size;
//            end;
//            Inc(PCallbackPush(Buff));
//         end;
//      end;
//      with PCallbackCall(Buff)^ do
//      begin
//         // Push Self
//         PushDataOps[0] := $FF;
//         PushDataOps[1] := $35;
//         PushDataVal    := Addr(PCallbackData(Result).MethodData.Data);
//         // Call Method
//         CallCodeOps[0] := $FF;
//         CallCodeOps[1] := $15;
//         CallCodeVal    := Addr(PCallbackData(Result).MethodData.Code);
//         // Fix Stack
//         AddEspXXOps[0] := $83;
//         AddEspXXOps[1] := $C4;
//         AddEspXXVal    := Size + SizeOf(DWORD);
//         // Return
//         Return := $C3;
//      end;
//   except
//      VirtualFree(Result, 0, MEM_RELEASE);
//      Result := nil;
//   end;
//end;
//////////////////////////////////////////////////////////////////////////////////
////
////  MakeStdcallCallback (thunk to use stdcall method as static callback)
////  (works too for pascal and safecall, but NOT for cdecl and register!)
//
//{=========================================================================}
//function MakeStdcallCallback(const Method: TMethod): Pointer;
//type
//   PCallbackData = ^TCallbackData;
//   TCallbackData = packed record
//     // jmp  $8
//     JmpParmOps: array[0..1] of Byte;
//     MethodData: TMethod;
//   end;
//   PCallbackCode = ^TCallbackCode;
//   TCallbackCode = packed record
//     Ops1: array [0..2] of DWORD;
//     Val1: Pointer;
//     Ops2: array [0..1] of DWORD;
//     Val2: Pointer;
//   end;
//
//var
//   Buff: Pointer;
//begin
//   Result := VirtualAlloc(nil, $100, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
//   if Assigned(Result) then
//   try
//      Buff := Result;
//
//      with PCallbackData(Buff)^ do
//      begin
//         JmpParmOps[0] := $EB;
//         JmpParmOps[1] := $08;
//         MethodData    := Method;
//      end;
//      inc(PCallbackData(Buff));
//
//      with PCallbackCode(Buff)^ do
//      begin
//        // ; do not change registers!
//        // push    eax                         ; stack space (Self)
//        // push    eax                         ; backup accumulator
//        // mov     eax, [esp+8]                ; get return address
//        // mov     [esp+4], eax                ; save at lower addr
//        // mov     eax, [x].TMethod.Data       ; get x.Self pointer
//        // mov     [esp+8], eax                ; save it into space
//        // pop     eax                         ; get eax from stack
//        // nop                                 ; think about it *g*
//        // jmp     dword ptr [x].TMethod.Code  ; now jump to method
//        // ; no need to cleanup stack
//        Ops1[0] := $448B5050;
//        Ops1[1] := $44890824;
//        Ops1[2] := $058B0424;
//        Val1    := Addr(PCallbackData(Result).MethodData.Data);
//        Ops2[0] := $08244489;
//        Ops2[1] := $25FF9058;
//        Val2    := Addr(PCallbackData(Result).MethodData.Code);
//      end;
//   except
//      VirtualFree(Result, 0, MEM_RELEASE);
//      Result := nil;
//   end;
//end;
//
//{=========================================================================}
//procedure FreeCallback(Callback: Pointer);
//begin
//  if Assigned(Callback) then
//     VirtualFree(Callback, 0, MEM_RELEASE);
//end;
//{$ENDIF}
//
//{=========================================================================}
//function SearchParamStr(Switch: string): Boolean;
//var
//   i,idx: integer;
//   S: string;
//begin
//   for i := 1 to ParamCount do
//   begin
//      S := ParamStr(i);
//
//      idx := Pos(':',S);
//      if (idx > 0) then
//          S := Copy(S,1,idx-1);
//
//      if (S <> '') and (S[1] in ['-', '/']) and
//         (CompareText(Copy(S, 2, Length(Switch)), Switch) = 0) and
//         (Length(Switch) = Length(S)-1) then
//      begin
//         Result := True;
//         Exit;
//      end;
//   end;
//   Result := False;
//end;
//
//{=========================================================================}
//function GetVersionNumber(FileName: string): string;
//var
//   Size: DWORD;
//   Buf,lpVersion: PAnsiChar;
//   VerPointer: PByteArray;
//   Lang_Charset_String: string;
//   HexNumber: Longint;
//
//begin
//   Result := '';
//   Buf := nil;
//
//   Size := GetFileVersionInfoSize(PChar(FileName),Size);
//   if (Size > 0) then
//   try
//      GetMem(Buf,Size+1);
//      if GetFileVersionInfo(PChar(FileName),0,Size,Buf) then
//      begin
//         if VerQueryValue(Buf,'\VarFileInfo\Translation',Pointer(VerPointer), Size) then
//         begin
//            // VerPointer is a pointer to four 4 bytes of Hex number,
//            // first two bytes are language id, and last two bytes are code
//            // page. However, Lang_Charset_String needs a  string of
//            // 4 hex digits, the first two characters correspond to the
//            // language id and last two the last two character correspond
//            // to the code page id.
//            HexNumber := VerPointer[2] + VerPointer[3] * $100 + VerPointer[0] *
//                         $10000 + VerPointer[1] * $1000000;
//            Lang_Charset_String := IntToHex(HexNumber,8);
//
//            // now we change the order of the language id and code page
//            // and convert it into a string representation.
//            // For example, it may look like 040904E4
//            // Or to pull it all apart:
//            // 04------        = SUBLANG_ENGLISH_USA
//            // --09----        = LANG_ENGLISH
//            // ----04E4 = 1252 = Codepage for Windows: Multilingual
//            if VerQueryValue(Buf,PChar('\StringFileInfo\'+Lang_Charset_String+'\FileVersion'),
//                             Pointer(lpVersion),
//                             Size) then
//            begin
//               Result := StrPas(lpVersion);
//            end;
//         end;
//      end;
//
//   finally
//      FreeMem(Buf);
//   end;
//end;
//
//{=========================================================================}
//function GetWindowsLanguage: integer;
//var
//   Size: DWORD;
//   EXE: string;
//   Buf: PChar;
//   VerPointer: PByteArray;
//   Lang_Charset_String: string;
//   WinDir: array[0..MAX_PATH] of Char;
//
//begin
//   Result := 0;
//   Buf := nil;
//
//   GetWindowsDirectory(WinDir,sizeof(WinDir));
//                                         // Explorer.exe
//   EXE := CheckPath(WinDir,True)+'Explorer.exe';
//
//   Size := GetFileVersionInfoSize(PChar(EXE),Size);
//   if (Size > 0) then
//   try
//      GetMem(Buf,Size+1);
//      if GetFileVersionInfo(PChar(EXE),0,Size,Buf) then
//      begin
//         if VerQueryValue(Buf,'\VarFileInfo\Translation',Pointer(VerPointer), Size) then
//         begin
//            // VerPointer is a pointer to four 4 bytes of Hex number,
//            // first two bytes are language id, and last two bytes are code
//            // page. However, Lang_Charset_String needs a  string of
//            // 4 hex digits, the first two characters correspond to the
//            // language id and last two the last two character correspond
//            // to the code page id.
//            Result := VerPointer[2] + VerPointer[3] * $100 + VerPointer[0] *
//                      $10000 + VerPointer[1] * $1000000;
//            Lang_Charset_String := IntToHex(Result,8);
//
//            // now we change the order of the language id and code page
//            // and convert it into a string representation.
//            // For example, it may look like 040904E4
//            // Or to pull it all apart:
//            // 04------        = SUBLANG_ENGLISH_USA
//            // --09----        = LANG_ENGLISH
//            // ----04E4 = 1252 = Codepage for Windows: Multilingual
//            (*if VerQueryValue(Buf,PChar('\StringFileInfo\'+Lang_Charset_String+'\FileVersion'),
//                             Pointer(lpVersion),
//                             Size) then
//            begin
//               Result := StrPas(lpVersion);
//            end;*)
//         end;
//      end;
//
//   finally
//      FreeMem(Buf);
//   end;
//end;
//
//{=========================================================================}
//function GetCountryCode: string;
//var
//   LCID: DWORD;
//   Buf: array[0..255] of Char;
//begin
//   LCID := GetSystemDefaultLCID;
//
//   if (GetLocaleInfo(LCID, LOCALE_ICOUNTRY, Buf, sizeof(Buf)) <> 0) then
//       Result := StrPas(Buf)
//   else
//       Result := '';
//end;
//
//{=========================================================================}
//function VersionToInt(sVersion: string): integer;
//var
//   i,j,mul,start: integer;
//begin
//   Result := 0;
//
//   if (sVersion = '') then exit;
//
//   Mul   := 1;
//
//   start := 0;
//
//   if (sVersion[Length(sVersion)] = ')') then
//   begin
//      for i := Length(sVersion) downto 1 do
//      begin
//         inc(start);
//         if (sVersion[i] = '(') then
//             break;
//      end;
//   end;
//
//   j := Length(sVersion)-start;
//
//   for i := j downto 1 do
//   begin
//      if (sVersion[i] <> '.') and (sVersion[i] <> ' ') then
//      begin
//         Result := Result + (StrToIntDef(sVersion[j],0)*Mul);
//         Mul := Mul*10
//      end;
//      dec(j);
//   end;
//end;
//
//{=========================================================================}
//function GetHarddiskID(HarddiskID: Byte): string;
//type
//    TIDERegs = packed record
//      bFeaturesReg     : BYTE; // Used for specifying SMART "commands".
//      bSectorCountReg  : BYTE; // IDE sector count register
//      bSectorNumberReg : BYTE; // IDE sector number register
//      bCylLowReg       : BYTE; // IDE low order cylinder value
//      bCylHighReg      : BYTE; // IDE high order cylinder value
//      bDriveHeadReg    : BYTE; // IDE drive/head register
//      bCommandReg      : BYTE; // Actual IDE command.
//      bReserved        : BYTE; // reserved for future use.  Must be zero.
//    end;
//    TSendCmdInParams = packed record
//      cBufferSize  : DWORD;                // Buffer size in bytes
//      irDriveRegs  : TIDERegs;             // Structure with drive register values.
//      bDriveNumber : BYTE;                 // Physical drive number to send command to (0,1,2,3).
//      bReserved    : array[0..2] of Byte;  // Reserved for future expansion.
//      dwReserved   : array[0..3] of DWORD; // For future use.
//      bBuffer      : array[0..0] of Byte;  // Input buffer.
//    end;
//    TDriverStatus = packed record
//      bDriverError : Byte;
//      bIDEStatus   : Byte;
//      bReserved    : array[0..1] of Byte;
//      dwReserved   : array[0..1] of DWORD;
//    end;
//    TSendCmdOutParams = packed record
//      cBufferSize  : DWORD;
//      DriverStatus : TDriverStatus;
//      bBuffer      : array[0..0] of BYTE;
//    end;
//    TIdSector = packed record
//      all: array[0..254] of AnsiChar;
//    end;
//
//    STORAGE_PROPERTY_QUERY = packed record
//      PropertyId: DWORD;
//      QueryType: DWORD;
//      AdditionalParameters: array[0..3] of Byte;
//    end;
//
//    STORAGE_DEVICE_DESCRIPTOR = packed record
//      Version: ULONG;
//      Size: ULONG;
//      DeviceType: Byte;
//      DeviceTypeModifier: Byte;
//      RemovableMedia: Boolean;
//      CommandQueueing: Boolean;
//      VendorIdOffset: ULONG;
//      ProductIdOffset: ULONG;
//      ProductRevisionOffset: ULONG;
//      SerialNumberOffset: ULONG;
//      STORAGE_BUS_TYPE: DWORD;
//      RawPropertiesLength: ULONG;
//      RawDeviceProperties: array[0..511] of Byte;
//    end;
//
//    PAnsiCharArray = ^TAnsiCharArray;
//    TAnsiCharArray = array[0..32767] of AnsiChar;
//
//const
//    DFP_RECEIVE_DRIVE_DATA       = $0007c088;
//    IOCTL_STORAGE_QUERY_PROPERTY = $2D1400;
//    IDENTIFY_BUFFER_SIZE         = 512;
//    IDE_ID_FUNCTION              = $EC;
//    CAP_IDE_ID_FUNCTION          = 1;
//    BufferSize = SizeOf(TSendCmdOutParams)+IDENTIFY_BUFFER_SIZE-1;
//var
//    SCIP : TSendCmdInParams;
//    Buffer : array [0..BufferSize-1] of Byte;
//    SCOP : TSendCmdOutParams absolute Buffer;
//    dwBytesReturned : DWORD;
//    Res,GotSerial: Boolean;
//    hdevice: THandle;
//    IdSectorSize: Integer;
//    idsector: TIdSector;
//    i: Integer;
//    Ch: Char;
//
//    PropQuery: STORAGE_PROPERTY_QUERY;
//    DeviceDescriptor: STORAGE_DEVICE_DESCRIPTOR;
//
//   //  function to decode the serial numbers of IDE hard drives
//   //  using the IOCTL_STORAGE_QUERY_PROPERTY command
//   function flipAndCodeBytes(str: PAnsiChar): string;
//   var
//      i,j,k,num,sum: integer;
//      sub: array[0..1] of AnsiChar;
//      flipped: array[0..999] of AnsiChar;
//   begin
//      num := strlen(str);
//
//      FillChar(flipped, sizeof(flipped),0);
//
//      i := 0;
//      while (i < num) do
//      begin
//         j := 1;
//         while (j >= 0) do
//         begin
//            sum := 0;
//            k := 0;
//            while (k < 2) do
//            begin
//               sum := sum * 16;
//               case (str [i + j * 2 + k]) of
//                  '0': inc(sum,0);
//                  '1': inc(sum,1);
//                  '2': inc(sum,2);
//                  '3': inc(sum,3);
//                  '4': inc(sum,4);
//                  '5': inc(sum,5);
//                  '6': inc(sum,6);
//                  '7': inc(sum,7);
//                  '8': inc(sum,8);
//                  '9': inc(sum,9);
//                  'a': inc(sum,10);
//                  'b': inc(sum,11);
//                  'c': inc(sum,12);
//                  'd': inc(sum,13);
//                  'e': inc(sum,14);
//                  'f': inc(sum,15);
//                  'A': inc(sum,10);
//                  'B': inc(sum,11);
//                  'C': inc(sum,12);
//                  'D': inc(sum,13);
//                  'E': inc(sum,14);
//                  'F': inc(sum,15);
//               end;
//               inc(k);
//            end;
//
//            if (sum > 0) then
//            begin
//               sub[0]  := AnsiChar(sum);
//               sub [1] := #0;
//               strcat (flipped, sub);
//            end;
//            dec(j);
//         end;
//         inc(i,4);
//      end;
//
//      Result := flipped;
//   end;
//
//begin
//   Result := '';
//
//   GotSerial := False;
//
//   FillChar(idSector, sizeof(idsector), #0);
//   FillChar(SCIP,SizeOf(TSendCmdInParams)-1,#0);
//   FillChar(Buffer,BufferSize,#0);
//   dwBytesReturned := 0;
//   // Set up data structures for IDENTIFY command.
//   with SCIP do
//   begin
//      cBufferSize  := IDENTIFY_BUFFER_SIZE;
//      bDriveNumber := 0;
//      with irDriveRegs do
//      begin
//         bFeaturesReg     := 0;
//
//         bSectorCountReg  := 1;
//         bSectorNumberReg := 1;
//         bCylLowReg       := 0;
//         bCylHighReg      := 0;
//         bDriveHeadReg := $A0 or ((0 and 1) shl 4);
//         bCommandReg      := IDE_ID_FUNCTION;	// The command can either be IDE identify or ATAPI identify.
//      end;
//   end;
//
//   hDevice := CreateFile( PChar('\\.\PhysicalDrive' + IntToStr(HarddiskID)), GENERIC_READ or GENERIC_WRITE, FILE_SHARE_READ or FILE_SHARE_WRITE, nil, OPEN_EXISTING, 0, 0 );
//   if (hDevice <> INVALID_HANDLE_VALUE) then
//   try
//      Res := DeviceIoControl(hDevice,
//                             DFP_RECEIVE_DRIVE_DATA,
//                             @SCIP, SizeOf(TSendCmdInParams)-1,
//                             @SCOP, BufferSize, dwBytesReturned, nil);
//      if Res then
//      begin
//         IDSectorSize := sizeof(IDSector);
//         if IdSectorSize > 0 then
//            System.Move(SCOP.bBuffer,IdSector,IdSectorSize);
//
//         for i := 0 to 19 do
//             Result := Result + idSector.all[i + 20];
//
//         for i := 20 downto 1 do
//         if i mod 2 = 0 then
//         begin
//            ch := Result[i];
//            Result[i] := Result[i-1];
//            Result[i-1] := ch;
//         end;
//         Result := Trim(Result);
//
//         GotSerial := (Result <> '');
//      end;
//   finally
//      CloseHandle(hDevice);
//   end;
//
//   if not GotSerial then
//   try
//      hDevice := CreateFile( PChar('\\.\PhysicalDrive' + IntToStr(HarddiskID)), 0, FILE_SHARE_READ or FILE_SHARE_WRITE, nil, OPEN_EXISTING, 0, 0 );
//      if (hDevice <> INVALID_HANDLE_VALUE) then
//      begin
//         ZeroMemory(@PropQuery, SizeOf(PropQuery));
//         ZeroMemory(@DeviceDescriptor, SizeOf(DeviceDescriptor));
//
//         DeviceDescriptor.Size := SizeOf(DeviceDescriptor);
//
//         Res := DeviceIoControl(hDevice,
//                                IOCTL_STORAGE_QUERY_PROPERTY,
//                                @PropQuery, SizeOf(PropQuery),
//                                @DeviceDescriptor, DeviceDescriptor.Size,
//                                dwBytesReturned, nil);
//
//         if Res then
//         begin
//            if DeviceDescriptor.SerialNumberOffset <> 0 then
//               Result := Trim(flipAndCodeBytes(@PAnsiCharArray(@DeviceDescriptor)^[DeviceDescriptor.SerialNumberOffset]));
//         end;
//      end;
//   finally
//      CloseHandle(hDevice);
//   end;
//end;
//
//{=========================================================================}
//function GetVolumeID(Drive: Char): string;
//var
//   Serial: DWORD;
//begin
//   if GetVolumeInformation(PChar(Drive+':\'), nil, 0, @Serial, PDWORD(nil)^, PDWORD(nil)^, nil, 0) then
//      Result := IntToStr(Serial)
//   else
//      Result := '';
//end;
//
//{=========================================================================}
//function GetHWID: string;
//begin
//   // liefert eine eindeutige HWId
//   Result := GetHarddiskID(0);
//   if (Result = '') then
//       Result := GetVolumeID('C'); // wenn GetHarddiskID nichts liefert, verwenden wir die logische Serial
//end;
//
//{=========================================================================}
//function GetShellDisplayName(Path: string; IgnoreMediumName: Boolean): string;
//var
//   shinf: TSHFileInfo;
//   idx: integer;
//begin
//   Result := '';
//   if (SHGetFileInfo(PChar(Path), 0, shinf,sizeOf(shinf), SHGFI_DISPLAYNAME ) <> 0) then
//   begin
//      SetString(Result, shinf.szDisplayName, StrLen(shinf.szDisplayName));
//      if IgnoreMediumName and AnsiSameText(ExtractFileDrive(Path),ExcludeTrailingBackslash(Path)) then
//      begin
//         idx := Pos(Format('(%s)',[ExtractFileDrive(Path)]),Result);
//         if (idx > 0) then
//             Result := Copy(Result,1,idx+3);
//      end;
//   end;
//end;
//
//{=========================================================================}
//function GetShellIconIndex(Path: string; Flags: DWORD): integer;
//var
//   shinf: TSHFileInfo;
//begin
//   Result := -1;
//   try
//   if (SHGetFileInfo(PChar(Path), 0, shinf,sizeOf(shinf), SHGFI_SYSICONINDEX or SHGFI_SMALLICON or Flags) <> 0) then
//       Result := shinf.iIcon;
//   except
//      // Corrupt files or broken icon shell extensions can cause raise exceptions that need to be caught
//   end;
//end;
//
//{=========================================================================}
//function GetShellIcon(Path: string; Flags: DWORD): HICON;
//var
//   shinf: TSHFileInfo;
//begin
//   Result := 0;
//   if (SHGetFileInfo(PChar(Path), 0, shinf,sizeOf(shinf), SHGFI_SYSICONINDEX or SHGFI_SMALLICON or SHGFI_ICON or Flags) <> 0) then
//       Result := shinf.hIcon;
//end;
//
//{=========================================================================}
//function GetShellSystemImageList: THandle;
//var
//   shfi: TSHFileInfo;
//begin
//   Result := SHGetFileInfo( 'C:\', 0, shfi,sizeof(shfi), SHGFI_SYSICONINDEX or SHGFI_SMALLICON);
//end;
//
//{=========================================================================}
//function GetVolumeName(Drive: string): string;
//var
//   Buf: array[0..MAX_PATH] of Char;
//begin
//   Drive := IncludeTrailingBackslash(Drive);
//
//   Result := GetShellDisplayName(Drive,True);
//   if (Result = '') then
//   begin
//     if GetVolumeInformation(PChar(Drive), @Buf, sizeof(Buf), nil, PDWORD(nil)^, PDWORD(nil)^, nil, 0) then
//     begin
//        Result := StrPas(Buf) + ' ('+ExtractFileDrive(Drive)+')';
//     end;
//   end;
//end;
//
//{=========================================================================}
//function TextToUniqueInt(Text: string): Cardinal;
//var
//   i,j: integer;
//begin
//   // wandelt den �bergebenen Text in einen eindeutigen integer um
//   Result := StrToIntDef(Text,0);
//   if (Result = 0) then
//   begin
//      j := 0;
//      for i := 1 to Length(Text) do
//      begin
//         Result := Result + (Ord(Text[i]) shl (j*8));
//         inc(j);
//         if (j > 3) then
//             j := 0;
//      end;
//   end;
//end;
//
//{=========================================================================}
//function CreateUniqueID(Files: TStringList): Cardinal;
//var
//   i: integer;
//   Text: string;
//   SList: TStringList;
//begin
//   Text := '';
//   SList := TStringList.Create;
//   try
//      for i := 0 to Files.Count-1 do
//      begin
//         try
//            SList.LoadFromFile(Files[i]);
//            Text := Text + ExtractFileName(Files[i]) + SList.Text;
//         except
//            // no exception here....
//         end;
//      end;
//   finally
//      Result := TextToUniqueInt(Text);
//      SList.Free;
//   end;
//end;
//
//type
//    PPChar = ^PChar;
//
//function SHGetSpecialFolderPath(hwndOwner: HWND; lpszPath: PChar; nFolder: Integer; fCreate: BOOL): BOOL;
//                                stdcall; external 'shell32.dll' name 'SHGetSpecialFolderPath'+{$IFDEF UNICODE}'W'{$ELSE}'A'{$ENDIF};
//
//{=========================================================================}
//function GetSpecialFolder(nFolderId: integer): string;
//var
//   Path: array[0..MAX_PATH] of Char;
//begin
//   if SHGetSpecialFolderPath(0, @Path, nFolderId, False) then
//      Result := StrPas(Path)
//   else
//      Result := '';
//end;
//
//{=========================================================================}
//function ExtractTopDirectory(const Directory: string): string;
//var
//   i: integer;
//begin
//   Result := '';
//   if (Directory <> '') then
//   begin
//      Result := IncludeTrailingPathDelimiter(Directory);
//
//      i := Pos(PathDelim, Result);
//      if (i > 0) then
//          Result := Copy(Result,1,i);
//   end;
//end;
//
//{=========================================================================}
//function ExtractSubDirectory(const Directory: string): string;
//var
//   i: Integer;
//begin
//   Result := ExcludeTrailingPathDelimiter(Directory);
//   i := LastDelimiter(PathDelim, Result);
//   if (i > 0) then
//       Result := Copy(Result, i+1, MaxInt)
//   else
//       Result := '';
//end;
//
//{=========================================================================}
//function ExtractParentDir(const Directory: string): string;
//var
//   i: integer;
//begin
//   Result := '';
//   if (Directory <> '') then
//   begin
//      Result := ExcludeTrailingPathDelimiter(Directory);
//
//      i := LastDelimiter(PathDelim, Result);
//      if (i > 0) then
//          Delete(Result,i,Length(Result));
//
//      Result := IncludeTrailingPathDelimiter(Result);
//   end;
//end;
//
//{=========================================================================}
//procedure CenterFormOverActiveForm(AForm,ActiveForm: TForm);
//var
//   aLeft,aTop: integer;
//begin
//   if assigned(ActiveForm) then
//   begin
//      aLeft := ActiveForm.Left + (ActiveForm.Width div 2) - (AForm.Width div 2);
//      aTop  := ActiveForm.Top  + (ActiveForm.Height div 2) - (AForm.Height div 2);
//
//      // prevent form from being outside screen
//      if aLeft < 0 then
//         aLeft := ActiveForm.Left;
//      if aTop < 0 then
//         aTop := ActiveForm.Top;
//      // prevents form being twice repainted!
//   end
//   else
//   begin
//      aLeft := (Screen.Width - aForm.Width) div 2;
//      aTop  := (Screen.Height - aForm.Height) div 2;
//   end;
//   aForm.SetBounds(aLeft,aTop,aForm.Width,aForm.Height);
//end;
//
//{=========================================================================}
//procedure CenterFormOverActive(AForm: TForm);
//begin
//   CenterFormOverActiveForm(AForm,Screen.ActiveForm);
//end;
//
//{=========================================================================}
//procedure WinYield(Wnd: THandle);
//var
//   msg: TMsg;
//begin
//   while PeekMessage(Msg, Wnd, 0, 0, PM_REMOVE) do
//   begin
//      TranslateMessage(Msg);
//      DispatchMessage(Msg);
//   end;
//end;
//
//{=========================================================================}
//procedure ConvertTo32BitImageList(const ImageList: TImageList);
//const
//  Mask: array[Boolean] of Longint = (0, ILC_MASK);
//var
//  TempList: TImageList;
//begin
//  if Assigned(ImageList) then
//  begin
//    TempList := TImageList.Create(nil);
//    try
//      TempList.Assign(ImageList);
//      with ImageList do
//      begin
//        Handle := ImageList_Create(Width, Height, ILC_COLOR32 or Mask[Masked],  0, AllocBy);
//      end;
//
//      Imagelist.AddImages(TempList);
//
//    finally
//      FreeAndNil(TempList);
//    end;
//  end;
//end;
//
//{=========================================================================}
//function GetTaskbarHeight: integer;
//var
//   SysTray: Windows.HWND;
//   Rect: TRect;
//begin
//   Result := -1;
//   SysTray := FindWindow('Shell_TrayWnd', nil);
//   if SysTray <> INVALID_HANDLE_VALUE then
//   begin
//     if GetWindowRect(SysTray, Rect) then
//        Result := Screen.Height - Rect.Top;
//   end;
//end;
//
//{=========================================================================}
//function GetTaskbarWidth: integer;
//var
//   SysTray: Windows.HWND;
//   Rect: TRect;
//begin
//   Result := -1;
//   SysTray := FindWindow('Shell_TrayWnd', nil);
//   if SysTray <> INVALID_HANDLE_VALUE then
//   begin
//      if GetWindowRect(SysTray, Rect) then
//         Result := Rect.Right - Rect.Left;
//   end;
//end;
//
//{=========================================================================}
//function GetWorkAreaRect: TRect;
//begin
//  SystemParametersInfo(SPI_GETWORKAREA, 0, @Result, 0);
//end;
//
//{=========================================================================}
//procedure SetFontSmoothing(aFont: TFont);
//var
//   LogFont: TLogFont;
//begin
//   GetObject(aFont.Handle,sizeof(TLogFont),@LogFont);
//   LogFont.lfQuality := ANTIALIASED_QUALITY;
//   aFont.Handle := CreateFontIndirect(Logfont);
//end;
//
//{=========================================================================}
//procedure AssignStrings(Dest, Source: TStrings);
//begin
//   Dest.BeginUpdate;
//   try
//      Dest.Clear;
//      Dest.Capacity := Source.Capacity;
//      Dest.AddStrings(Source);
//   finally
//      Dest.EndUpdate;
//   end;
//end;
//
//{=========================================================================}
//procedure GrowStrings(Strings: TStrings);
//var
//   Delta: integer;
//begin
//   with Strings do
//   if (Count = 0) then
//   begin
//      if (Capacity < 1024) then
//          Capacity := 1024;
//   end
//   else if (Count = Capacity) then
//   begin
//      if Capacity > 32768 then
//         Delta := 8192 else
//      if Capacity > 16384 then
//         Delta := 4096 else
//      if Capacity > 4096 then
//         Delta := 1024 else
//      if Capacity > 512 then
//         Delta := 512 
//      else
//         Delta := 64;
//
//      Capacity := Capacity + Delta;
//   end;
//end;
//
//{=========================================================================}
//function DesignMode: Boolean;
//var
//   ExeName: array[0..260] of Char;
//begin
//   { in DesignMode? }
//   GetModuleFileName(0, ExeName, sizeOf(ExeName));
//
//   StrUpper(ExeName);
//
//   if (StrPos(ExeName, 'DELPHI32') <> nil) or
//      (StrPos(ExeName, 'BCB') <> nil) or
//      (StrPos(ExeName, 'BDS') <> nil) or
//      (StrPos(ExeName, '.DCP') <> nil) or
//      (StrPos(ExeName, '.BPL') <> nil) or
//      (StrPos(ExeName, '.DCL') <> nil) or
//      (StrPos(ExeName, '.CCL') <> nil) then
//       Result := True
//   else
//       Result := False;
//end;
//
//{$IFDEF CHECK_REGISTERED}
//
//{$IFDEF BUILD_ACTIVEX}
//   {$I MMREGAX.INC}
//{$ENDIF}
//
//{$ENDIF}
//
//{=========================================================================}
//procedure RegisterPackage(const Pack: string);
//begin
//   {$IFDEF BUILD_ACTIVEX} {$IFDEF CHECK_REGISTERED}
//   _RegisterPackage(Pack);
//   {$ENDIF} {$ENDIF}
//end;
//
//{=========================================================================}
//procedure RegisterComponent(Code: Longint; Control: TComponent; Text: string);
//begin
//   { only a dummy call to write portable code }
//end;
//
//{=========================================================================}
//function ComponentRegistered(Code: Longint; Control: TComponent; Text: string): Longint;
//begin
//   Result := 0;
//   {$IFDEF BUILD_ACTIVEX} {$IFDEF CHECK_REGISTERED}
//   Result := _CheckComponent(Code,Control,Text);
//   {$ENDIF} {$ENDIF}
//end;
//
//{=========================================================================}
//function PackageRegistered(Pack: string): integer;
//begin
//   Result := 0;
//   {$IFDEF BUILD_ACTIVEX} {$IFDEF CHECK_REGISTERED}
//   Result := _CheckPackage(Pack);
//   {$ENDIF} {$ENDIF}
//end;
//
//const
//     FailCount : Longint = 0;
//     AboutCount: Longint = 0;
//     hAboutSem : THandle = 0;
//
//{=========================================================================}
//procedure RegisterFailed(Code: Longint; Control: TComponent; Text: string);
//{$IFDEF BUILD_ACTIVEX}
//var
//   SemCount: Longint;
//
//   function EnumWindowsProc(hwnd: HWND; lParam: LPARAM): Boolean; stdcall;
//   var
//      CaptionText: array[0..80] of Char;
//   begin
//      GetWindowText(hwnd, CaptionText, sizeOf(CaptionText)-1);
//      if (StrPos(CaptionText, 'Delphi') <> nil) or
//         (StrPos(CaptionText, 'C++ Builder') <> nil) or
//         (StrPos(CaptionText, 'RAD Studio') <> nil) or
//         (StrPos(CaptionText, 'Microsoft Visual Basic') <> nil) or
//         (StrPos(CaptionText, 'Microsoft Developer Studio') <> nil) then
//      begin
//         Boolean(Pointer(lParam)^) := True;
//         Result := False;
//      end
//      else
//          Result := True;
//   end;
//
//   function FindValidIDE: Boolean;
//   var
//      IDEFound: Boolean;
//   begin
//      IDEFound := False;
//      Result := EnumWindows(@EnumWindowsProc,LPARAM(@IDEFound));
//   end;
//{$ENDIF}
//
//begin
//   {$IFDEF BUILD_ACTIVEX}
//
//   if (FailCount = 0) then
//   begin
//      //it should be 0.
//      hAboutSem := OpenSemaphore(EVENT_ALL_ACCESS, False, '_MMToolsX_');
//      if (hAboutSem = 0) then
//          hAboutSem := CreateSemaphore(nil, 0, MaxInt, '_MMToolsX_');
//
//      if (hAboutSem <> 0) then
//      begin
//         ReleaseSemaphore(hAboutSem,1,@SemCount);
//         if not FindValidIDE or (SemCount mod 10 = 0) then
//            Show_EvalAboutBox(1);
//      end;
//   end;
//
//   inc(FailCount);
//
//   {$ELSE}
//   if (FailCount = 0) then
//       Application.MessageBox('Initialization Error',
//                              'Multimedia Tools', MB_OK);
//   if DesignMode then
//      inc(FailCount)
//   else
//      Halt;
//   {$ENDIF}
//end;
//
//
//{$IFDEF WIN32}
//{$IFNDEF DELPHI3}
//{-----------------------------------------------------------------------------}
//function SysErrorMessage(ErrorCode: Integer): string;
//var
//   Len     : Integer;
//   Buffer  : array[0..255] of Char;
//begin
//   Len := FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM or
//                        FORMAT_MESSAGE_ARGUMENT_ARRAY, nil, ErrorCode,
//                        GetThreadLocale, Buffer, SizeOf(Buffer), nil);
//   while (Len > 0) and (Buffer[Len - 1] in [#0..#32, '.']) do Dec(Len);
//   SetString(Result, Buffer, Len);
//end;
//
//{ TODO: resource ids }
//const
//    SWin32Error = 'Win32 Error. Code: %d.'#10'%s';
//    SUnkWin32Error = 'A Win32 API function failed';
//
//{-----------------------------------------------------------------------------}
//procedure RaiseLastWin32Error;
//var
//   LastError: DWORD;
//   Error    : EWin32Error;
//begin
//   LastError := GetLastError;
//   if LastError <> ERROR_SUCCESS then
//      Error := EWin32Error.CreateFmt(SWin32Error, [LastError,SysErrorMessage(LastError)])
//   else
//      Error := EWin32Error.Create(SUnkWin32Error);
//   Error.ErrorCode := LastError;
//   raise Error;
//end;
//
//{-----------------------------------------------------------------------------}
//function Win32Check(RetVal: BOOL): BOOL;
//begin
//   if not RetVal then
//      RaiseLastWin32Error;
//   Result := RetVal;
//end;
//{$ENDIF}
//{$ENDIF}
//
//{$IFNDEF USEDLL}
//   {$I MMUTILS.INC}
//
//{$ELSE}
//
//var
//   ErrorMode      : Cardinal = 0;
//   GetDeviceID    : function: Longint;
//   GetDeviceStatus: function(Device: Longint): Longint;
//{$ENDIF}
//
//{------------------------------------------------------------------------}
//procedure NewExitProc; Far;
//begin
//   if MMUTILDLLHandle <> 0 then
//      FreeLibrary(MMUTILDLLHandle);
//   if (SBuf <> nil) then GlobalFreePtr(SBuf);
//   {$IFDEF WIN32}
//   DeleteCriticalSection(TransSection);
//   {$ENDIF}
//end;
//
//{=========================================================================}
//function FindIDERunning: Boolean;
//var
//  IDEHWnd : THandle;
//  CaptionText: array[0..80] of Char;
//  {$IFDEF TRIAL}
//  h: THandle;
//  {$ENDIF}
//
//begin
//   Result := False;
//
//   {$IFDEF TRIAL}
//   (*
//   h := LoadLibrary(MMUtilDLLKeyName);
//   if (h <> 0) then
//   begin
//      {$IFDEF WIN32}
//      {$IFDEF TRIAL}
//      {$DEFINE _HACK3}
//      {$I MMHACK.INC}
//      {$ENDIF}
//      {$ENDIF}
//
//      FreeLibrary(h);
//      Result := True;
//   end
//   else
//   *)
//   {$ENDIF}
//   begin
//      { Delphi or C++Builder running? }
//      IDEHWnd:= FindWindow('TAppBuilder', Nil);
//      if (IDEHWnd <> 0) then
//      begin
//         GetWindowText(IDEHWnd, CaptionText, sizeOf(CaptionText)-1);
//         StrUpper(CaptionText);
//         if (StrPos(CaptionText, 'DELPHI') <> nil) or
//            (StrPos(CaptionText, 'C++BUILDER') <> nil) or
//            (StrPos(CaptionText, 'RAD STUDIO') <> nil) then
//             Result := True;
//      end;
//   end;
//end;
//
//{$IFDEF WIN32}
//{========================================================================}
//procedure InitDriveSpacePtr;
//var
//  Kernel: THandle;
//begin
//  Kernel := GetModuleHandle(Windows.Kernel32);
//  if Kernel <> 0 then
//     @_GetDiskFreeSpaceEx := GetProcAddress(Kernel, 'GetDiskFreeSpaceEx'+{$IFDEF UNICODE}'W'{$ELSE}'A'{$ENDIF});
//
//  if not Assigned(_GetDiskFreeSpaceEx) then
//     _GetDiskFreeSpaceEx := @BackfillGetDiskFreeSpaceEx;
//end;
//{$ENDIF}
//
//{========================================================================}
//procedure InitMMUtils;
//{$IFDEF USEDLL}
//var
//   P: Pointer;
//{$ENDIF}
//
//begin
//   {$IFDEF USEDLL}
//   ErrorMode := SetErrorMode(SEM_NoOpenFileErrorBox);
//   try
//      GetDeviceID:= nil;
//
//      if (GetModuleHandle(MMUTILDLLName) = 0) then
//      begin
//         (*MMUTILDLLHandle := LoadLibrary(MMUTILDLLKeyName);
//         P := GetProcAddress(MMUTILDLLHandle,'_GetDeviceID_');
//         if (P = nil) and (MMUTILDLLHandle <> 0) then
//         begin
//            FreeLibrary(MMUTILDLLHandle);
//            MMUTILDLLHandle := 0;
//         end;
//
//         if MMUTILDLLHandle < HINSTANCE_ERROR then
//         *)   MMUTILDLLHandle := LoadLibrary(MMUTILDLLName);
//      end;
//
//      if MMUTILDLLHandle >= HINSTANCE_ERROR then
//      begin
//         {$IFNDEF WIN32}
//         AddExitProc(NewExitProc);
//         {$ENDIF}
//
//         @GetDeviceID        := GetProcAddress(MMUTILDLLHandle,'_GetDeviceID');
//         @GetDeviceStatus    := GetProcAddress(MMUTILDLLHandle,'_GetDeviceStatus');
//
//         @IDERunning         := GetProcAddress(MMUTILDLLHandle,'_IDERunning');
//         @CheckTime          := GetProcAddress(MMUTILDLLHandle,'_CheckTime');
//
//         @SwapSmall          := GetProcAddress(MMUTILDLLHandle,'_SwapSmall');
//         @SwapInt            := GetProcAddress(MMUTILDLLHandle,'_SwapInt');
//         @SwapLong           := GetProcAddress(MMUTILDLLHandle,'_SwapLong');
//         @Min                := GetProcAddress(MMUTILDLLHandle,'_Min');
//         @Max                := GetProcAddress(MMUTILDLLHandle,'_Max');
//         @MinMax             := GetProcAddress(MMUTILDLLHandle,'_MinMax');
//         @Limit              := GetProcAddress(MMUTILDLLHandle,'_Limit');
//         @InMinMax           := GetProcAddress(MMUTILDLLHandle,'_InMinMax');
//         @InRange            := GetProcAddress(MMUTILDLLHandle,'_InRange');
//
//         @incHuge            := GetProcAddress(MMUTILDLLHandle,'_incHuge');
//         @GlobalFillMem      := GetProcAddress(MMUTILDLLHandle,'_GlobalFillMem');
//         @GlobalFillLong     := GetProcAddress(MMUTILDLLHandle,'_GlobalFillLong');
//         @GlobalMoveMem      := GetProcAddress(MMUTILDLLHandle,'_GlobalMoveMem');
//         @GlobalCmpMem       := GetProcAddress(MMUTILDLLHandle,'_GlobalCmpMem');
//
//         {$IFDEF WIN32}
//         CheckParam1 := @OpenSemaphore;
//         CheckParam2 := @GetVolumeInformation;
//         {$ENDIF}
//      end
//      else
//      begin
//         MessageDlg('Unable to load '+StrPas(MMUtilDLLName), mtError, [mbOK],0);
//         Halt;
//      end;
//
//   finally
//      SetErrorMode(ErrorMode);
//   end;
//   {$ELSE}
//   SwapSmall          := _SwapSmall;
//   SwapInt            := _SwapInt;
//   SwapLong           := _SwapLong;
//   Min                := _Min;
//   Max                := _Max;
//   MinMax             := _MinMax;
//   Limit              := _Limit;
//   InMinMax           := _InMinMax;
//   InRange            := _InRange;
//
//   incHuge            := _incHuge;
//   GlobalFillMem      := _GlobalFillMem;
//   GlobalFillLong     := _GlobalFillLong;
//   GlobalMoveMem      := _GlobalMoveMem;
//   GlobalCmpMem       := _GlobalCmpMem;
//   {$ENDIF}
//end;
//
//{$IFDEF TRIAL}
//var
//   aBuf: array[0..256] of Char;
//{$ENDIF}
//
//{========================================================================}
//initialization
//
//     {$IFDEF WIN32}
//     InitializeCriticalSection(TransSection);
//     {$ENDIF}
//
//     {$IFDEF TRIAL}
//     if not FindIDERunning then
//     begin
//        Application.MessageBox(StrPCopy(aBuf,'IDE not found. Please register !'),
//                                             'Multimedia Tools', MB_OK);
//        Halt;
//     end;
//     {$ENDIF}
//
//     InitMMUtils;
//
//     {$IFDEF TRIAL}
//     if assigned(GetDeviceID) then InitCode := GetDeviceID;
//     if (InitCode = 0) then
//         raise Exception.Create('Initialization Error');
//
//     GetDeviceStatus(InitCode);
//
//     Randomize;
//
//     {$ENDIF}
//
//     SBuf := GlobalAllocMem(50000);
//     FillChar(SBuf^,50000,$FF);
//
//     _Win95_      := HaveWin95;
//     _Win98_      := HaveWin98;
//     _WinME_      := HaveWinME;
//     _WinNT3_     := HaveWinNT;
//     _WinNT4_     := HaveWinNT4;
//     _Win2K_      := HaveWin2K;
//     _Win2K3_     := HaveWin2K3;
//     _WinXP_      := HaveWinXP;
//     _WinVista_   := HaveWinVista;
//     _Windows7_   := HaveWindows7 or HaveAfterWin7;
//
//     _Win9x_      := _Win95_ or _Win98_ or _WinME_;
//     _WinNT_      := _WinNT3_ or _WinNT4_ or _Win2K_ or _Win2K3_ or _WinXP_ or _WinVista_ or _Windows7_;
//     _WinNT_NEW_  := _WinNT4_ or _Win2K_ or _Win2K3_ or _WinXP_ or _WinVista_ or _Windows7_;
//     _WinNT_WDM_  := _Win2K_ or _Win2K3_ or _WinXP_ or _WinVista_ or _Windows7_;
//     _WinVistaUp_ := _WinVista_ or _Windows7_;
//
//     {$IFDEF WIN32}
//     _CPU_      := GetCPUType;
//     _MMX_      := (GetCPUFeatures and $800000 <> 0);
//     _USECPUEXT_:= True;
//
//      InitDriveSpacePtr;
//     {$ENDIF}
//
//{$IFDEF WIN32}
//Finalization
//    NewExitProc;
//
//{$ENDIF}
//end.
