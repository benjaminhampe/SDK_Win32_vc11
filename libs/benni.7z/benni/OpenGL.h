////////////////////////////////////////////////////////////

#ifndef BPM_OPENGL_H
#define BPM_OPENGL_H


////////////////////////////////////////////////////////////
/// Headers
////////////////////////////////////////////////////////////
#include "Config.h"

////////////////////////////////////////////////////////////
/// This file just includes the OpenGL (GL and GLU) headers,
/// which have actually different paths on each system
////////////////////////////////////////////////////////////
#if defined(BPM_SYSTEM_WINDOWS)

    // The Visual C++ version of gl.h uses WINGDIAPI and APIENTRY but doesn't define them
    #ifdef _MSC_VER
        #include <windows.h>
    #endif

    #include <GL/gl.h>
    #include <GL/glu.h>

#elif defined(BPM_SYSTEM_LINUX) || defined(BPM_SYSTEM_FREEBSD)

    #include <GL/gl.h>
    #include <GL/glu.h>

#elif defined(BPM_SYSTEM_MACOS)

    #include <OpenGL/gl.h>
    #include <OpenGL/glu.h>

#endif


#endif // BPM_OPENGL_H
