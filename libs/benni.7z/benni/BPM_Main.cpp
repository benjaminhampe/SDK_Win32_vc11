////////////////////////////////////////////////////////////
// Windows specific : defines the WinMain entry function,
// so that developers can use the standard main function
// even in a Win32 Application project, and keep a portable code
////////////////////////////////////////////////////////////

#include <Config.h>

#if defined(BPM_SYSTEM_WINDOWS)

    #include <windows.h>

    extern s32 main( s32 argc, c8** argv );

    int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, INT)
    {
        return main(__argc, __argv);
    }

#endif // BPM_SYSTEM_WINDOWS
