#include "AnalyzeFile.h"

boolByte analysisSilence(const SampleBuffer sampleBuffer, AnalysisFunctionData data);
