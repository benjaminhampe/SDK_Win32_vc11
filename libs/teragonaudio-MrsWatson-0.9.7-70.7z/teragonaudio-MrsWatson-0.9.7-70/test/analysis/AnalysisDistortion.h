#include "AnalyzeFile.h"

boolByte analysisDistortion(const SampleBuffer sampleBuffer, AnalysisFunctionData data);
