#include "AnalyzeFile.h"

boolByte analysisClipping(const SampleBuffer sampleBuffer, AnalysisFunctionData data);
